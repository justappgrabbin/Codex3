// test_dual.mjs — the picture side (seen) and the function side (the shadow you don't see) on dual shells (v64h, Nov 26).
import { readFileSync } from "node:fs"; import { setGateEngineData } from "./gate_engine.js"; import { LivingSwarm } from "./living.js";
import { twoSides, tick, look, COUPLING, PAIR } from "./dual.js"; import { read } from "./tiling.js";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const D4 = ["Movement", "Evolution", "Being", "Design"];
const S = new LivingSwarm({ seed: 4 }); for (let i = 0; i < 64; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: D4[i % 4] }, "item", Math.random(), Math.random());
const flat = D => { D.seen.agents.concat(D.shadow.agents).forEach(g => { for (const l of [1, 2, 3, 4, 5, 6]) g.value[l] = 0.5; }); return D; };

console.log("1 — two sides on dual shells");
for (const dim of ["Being", "Design", "Space"]) { const D = twoSides(S.units, { dimension: dim });
  console.log(`     seen: ${dim} (${D.views.seen}) ${D.seen.agents.length} agents  |  shadow: ${D.shadowDim} (${D.views.shadow}) ${D.shadow.agents.length} agents`);
  ok(`${dim}'s shadow is ${PAIR[dim]} (its paired dimension), and every seen agent has exactly one shadow partner`, D.shadowDim === PAIR[dim] && D.partner.every(j => j != null) && new Set(D.partner).size === D.partner.length); }
const D = twoSides(S.units, { dimension: "Being" });
const nbrs = (side, i) => Object.values(side.agents[i].links).map(k => k.agent).sort().join();
ok("partners sit in the same place: neighbours on the seen side are partners of neighbours on the shadow side", D.seen.agents.every((g, i) => nbrs(D.seen, i) === nbrs(D.shadow, D.partner[i])));
ok("no geometric link between the sides: no port of either shell reaches into the other", D.seen.agents.every(g => Object.values(g.links).every(k => k.agent < D.seen.agents.length)) && D.seen !== D.shadow && D.seen.agents.every(g => !D.shadow.agents.includes(g)));
ok("the two sides are carried by different units", D.seen.agents.every(g => !D.shadow.agents.some(h => h.unit === g.unit)));

console.log("2 — change the function side: its picture partner changes how it looks");
flat(D); const i = 3, j = D.partner[i], before = D.seen.agents.map(look);
D.shadow.agents[j].value[2] = 1; D.shadow.agents[j].value[5] = 1; tick(D); const after = D.seen.agents.map(look);
const changed = after.map((x, k) => JSON.stringify(x) !== JSON.stringify(before[k]));
console.log(`     partner ${i}: ${JSON.stringify(before[i])} -> ${JSON.stringify(after[i])}; other seen agents changed: ${changed.filter((c, k) => c && k !== i).length}`);
ok("the seen partner's look changed in one tick", changed[i]);
ok("no other seen agent changed in that tick (it went to the partner, not through contact)", changed.every((c, k) => !c || k === i));

console.log("3 — and the other way: change the picture side, its shadow changes");
flat(D); const s0 = JSON.stringify(D.shadow.agents[j].value); D.seen.agents[i].value[2] = 0; D.seen.agents[i].value[5] = 0; tick(D);
ok("the shadow partner changed", JSON.stringify(D.shadow.agents[j].value) !== s0);
ok("only through the self faces (2, 5): those moved most", (() => { const v = D.shadow.agents[j].value; return Math.abs(v[2] - 0.5) > Math.abs(v[1] - 0.5) && Math.abs(v[5] - 0.5) > Math.abs(v[6] - 0.5); })());

console.log("4 — cut the shadow off");
COUPLING.rate = 0; flat(D); D.shadow.agents[j].value[2] = 1; const b4 = JSON.stringify(look(D.seen.agents[i])); tick(D); tick(D);
ok("with the coupling at 0 the seen side never feels its shadow", JSON.stringify(look(D.seen.agents[i])) === b4); COUPLING.rate = 0.5;

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
