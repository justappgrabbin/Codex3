// test_dualswarm.mjs — the BHANTUGH dual-swarm doc parts added in v64l. Run plain and: node run_with_arcadia.mjs test_dualswarm.mjs
//   1 the hexagram two ways (trigrams for bonding, bigrams for level) and how they meet   2 the 2-5 pair and the agent's self faces
//   3 register locomotion, hex projection, glyphs   4 the ten-step cycle (FORM -> 52 -> 7)   5 hash-prefix bond
//   6 NATO phase sync   7 type guards and levels   8 the doc's 10D features, sentences along outlines
//   9 cluster -> graph -> JS, generated JS, GLSL, image, audio   10 routing by leading dimension
//   11 switches off = v64k unchanged; switches on = they act   12 purity
import { readFileSync, existsSync } from "node:fs";
import * as D from "./dualswarm.js"; import { LivingSwarm, SETTINGS } from "./living.js"; import { AFTER_LEARN } from "./morphogenesis.js";
import { describe } from "./hexagram.js"; import { maskFromKingWen } from "./kingwen.js"; import { AGENT, agentShape, setOrientation, ORIENTATIONS } from "./tiling.js";
import * as OPS from "./bhantugh_ops.js"; import { features } from "./formation.js";
import { baseline, differences } from "./regression.mjs";
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
console.log(`Arcadia ${AFTER_LEARN.some(h => h.name === "arcadia") ? "installed" : "absent"}`);
const DIMS = ["Movement", "Evolution", "Being", "Design"];
const swarm = (n = 48, seed = 3) => { const L = new LivingSwarm({ seed });
  for (let i = 0; i < n; i++) L.add({ gate: 1 + (i * 7) % 64, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: DIMS[i % 4], degree: (i * 37) % 360, house: 1 + (i * 5) % 12 }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  return L; };

console.log("1 — the hexagram read two ways");
const all = Array.from({ length: 64 }, (_, k) => D.readings(k + 1));
ok("trigram reading matches hexagram.js on all 64 gates", all.every(r => { const d = describe(r.mask); return r.trigrams.lower === d.lowerName && r.trigrams.upper === d.upperName && r.lines.join() === d.lines.join(); }));
ok("bigram reading: each level is its own two lines, on all 64", all.every(r => Object.values(r.bigrams).every(b => b.value === (r.lines[b.lines[0] - 1] | (r.lines[b.lines[1] - 1] << 1)))));
const M = D.howTheyMeet(); console.log(`     ${JSON.stringify(M)}`);
ok("every line sits in exactly one harmony pair and one bigram", M.everyLineInOnePairAndOneBigram);
ok("the trigram cut (between 3 and 4) splits only the human bigram", M.trigramCutSplitsOnlyTheHumanBigram.join() === "human");
ok("each harmony pair bridges two different levels, one bridge per pair of levels (1-4 earth-human, 2-5 earth-heaven, 3-6 human-heaven)",
  M.everyPairOfLevelsHasExactlyOneBridge && M.eachHarmonyPairBridgesTwoLevels.join() === "earth-human,earth-heaven,human-heaven");
const r1 = D.readings(1), r2 = D.readings(2); console.log(`     gate 1: ${r1.trigrams.lower}/${r1.trigrams.upper} bigrams ${Object.values(r1.bigrams).map(b => b.bits).join(" ")};  gate 2: ${r2.trigrams.lower}/${r2.trigrams.upper}`);
const db = D.depthBits({ gate: 44, line: 3, color: 2, tone: 5, base: 1 });
ok(`depth: the hexagram is 6 bits (three bigrams), the full gate-to-base address ${db.total} bits; no Mind/Heart count invented`, db.hexagram === 6 && db.bigrams === 3 && db.total > 6 && !("mind" in db) && !("heart" in db));

console.log("2 — the 2-5 pair and the agent's self faces");
for (const name of Object.keys(ORIENTATIONS)) { setOrientation(name); const S = agentShape(), F = AGENT.faces;
  const shared = (a, b) => F[a].filter(x => F[b].includes(x)).sort().join("-");
  ok(`${name}: each face's mirror across the equator is its line-harmony partner (1-4, 2-5, 3-6)`, [1, 2, 3, 4, 5, 6].every(l => S.mirror[l] === (l <= 3 ? l + 3 : l - 3)));
  ok(`${name}: the self faces 2 and 5 are each other's harmony partner and share the seam ${shared(2, 5)} (${AGENT.corners.E2}-${AGENT.corners.E3})`, AGENT.self.join() === "2,5" && S.mirror[2] === 5 && shared(2, 5) === "E2-E3"); }
setOrientation("turned");
ok("so the self pair is the earth-heaven bridge; the ports pair as earth-human (1-4) and human-heaven (3-6)", D.HARMONY_PAIRS[1].join() === AGENT.self.join() && AGENT.ports.join() === "1,3,4,6");

console.log("3 — register locomotion, hex projection, glyphs");
let reg = D.registerOf([1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1]); const r0 = reg; for (let k = 0; k < 32; k++) reg = D.rotl(reg);
ok("rotating the register 32 times gives it back (no bit lost)", reg === r0 && D.rotr(D.rotl(r0)) === r0);
const sh = D.shiftStep(r0, true); ok("<< while rising, >> while falling; heading = low nibble in 16ths of a turn", sh.op === "<<1" && D.shiftStep(r0, false).op === ">>1" && Math.abs(sh.heading - (sh.reg & 15) * Math.PI / 8) < 1e-12);
const hx = D.hexOf("0x3F8A1C"); ok("0x3F8A1C -> 3F / 8A / 1C -> XYZ sectors and RGB", hx.bytes.join() === "63,138,28" && hx.rgb.join() === "63,138,28" && hx.sector.join() === "3,8,1" && Math.abs(hx.xyz[0] - 63 / 255) < 1e-12);
ok("glyphs: ▲ for three-fold, ■ four, arrows follow heading", D.shapeGlyph(3) === "▲" && D.shapeGlyph(4) === "■" && D.arrowGlyph(0) === "→" && D.arrowGlyph(Math.PI / 2) === "↑" && D.arrowGlyph(Math.PI) === "←");

console.log("4 — the ten-step cycle");
const F = D.cycleWord("FORM"); console.log(`     FORM -> ${F.gematria} -> ${F.root} -> ${F.fold}-fold; ${F.nato.join(" ")}`);
ok("FORM -> 52 -> 7 -> sevenfold polygon, Foxtrot Oscar Romeo Mike", F.gematria === 52 && F.root === 7 && (F.svg.match(/points="([^"]+)"/)[1].split(" ").length === 7) && F.nato.join() === "Foxtrot,Oscar,Romeo,Mike");
const L0 = swarm(); L0.step(); const [ua, ub] = L0.units.flatMap(u => u.bonds).filter(e => e.visible).map(e => [L0.units[e.a], L0.units[e.b]])[0];
const C = D.cycle(ua, ub), C2 = D.cycle(ua, ub), Ci = D.cycle(ua, ub, { input: 0 });
console.log(`     two units: ${C.hash.slice(0, 12)}… -> ${C.hex} -> ${C.instructions.length} instructions -> gematria ${C.gematria} -> ${C.fold}-fold ${C.glyph}; valid ${C.valid}; child gate ${C.next.gate}.${C.next.line}`);
ok("a validated pair runs all ten steps: hash, hex, instructions, gematria, fold, glyph, contract, NATO, SVG, next state", C.valid && C.nato.length > 0 && /<svg/.test(C.svg) && D.isOntologicalAddress(C.next));
ok("same pair, same result; a user change to one bit (step 9) gives a different state", JSON.stringify(C) === JSON.stringify(C2) && Ci.hash !== C.hash);

console.log("5 — hash-prefix bond");
const A = Array.from({ length: 64 }, (_, k) => ({ bits: Array.from({ length: 6 }, (_, i) => (maskFromKingWen(k + 1) >> (5 - i)) & 1) }));
let n00 = 0, sym = true; for (let i = 0; i < 64; i++) for (let j = i + 1; j < 64; j++) { const h = D.hashBond(A[i].bits, A[j].bits); n00 += h.pass; sym &&= h.hash === D.hashBond(A[j].bits, A[i].bits).hash; }
ok(`the same either way round; "00" passes ${n00} of 2016 gate pairs (about 1 in 256 expected)`, sym && n00 > 0 && n00 < 30);

console.log("6 — NATO phase sync");
const Lsync = swarm(48, 5), Lfree = swarm(48, 5); Lsync.step(); Lfree.step(); const o0 = D.localOrder(Lsync.units, SETTINGS.CYCLE_PERIOD);
for (let k = 0; k < 40; k++) D.syncPhases(Lsync.units, SETTINGS.CYCLE_PERIOD, 0.3);
const lone = Lsync.units.filter(u => !u.bonds.some(e => e.visible)).map(u => u.id), o1 = D.localOrder(Lsync.units, SETTINGS.CYCLE_PERIOD), g1 = D.order(Lsync.units, SETTINGS.CYCLE_PERIOD);
console.log(`     neighbours in step before ${o0.toFixed(3)}, after 40 rounds ${o1.toFixed(3)} (whole swarm ${g1.toFixed(3)}: clusters keep their own beat); ${lone.length} units hear no one`);
ok("units that hear each other fall into step", o1 > o0 + 0.1 && o1 > 0.9);
ok("a unit with no validated bond keeps its own clock", lone.every(id => Lsync.units[id].phase === Lfree.units[id].phase));

console.log("7 — type guards and levels");
ok("isOntologicalAddress: rejects gate 65, line 7, base 6, a sixth dimension; accepts partial depth", !D.isOntologicalAddress({ gate: 65 }) && !D.isOntologicalAddress({ gate: 3, line: 7 }) &&
  !D.isOntologicalAddress({ gate: 3, base: 6 }) && !D.isOntologicalAddress({ gate: 3, dimension: "Mood" }) && D.isOntologicalAddress({ gate: 3 }) && D.isOntologicalAddress({ gate: 44, line: 3, dimension: "Space", house: 8 }));
ok("isClusterNode: only units with a good address and a visible bond", L0.units.some(D.isClusterNode) && L0.units.every(u => D.isClusterNode(u) === u.bonds.some(e => e.visible)));
ok("levels by governing coordinates: level 3 shows base, tone+color, line+gate", D.shownAt(3).map(L => L.governs.join("+")).join(" | ") === "base | tone+color | line+gate" && D.LEVEL_TABLE.length === 5);

console.log("8 — the doc's 10D features, sentences along outlines");
const U = L0.units.filter(u => !u.broken), fT = features(U, 0.12), fD = D.featuresDoc(U, 0.12);
ok("doc 10D = thesis 10D with the repeated degree dropped and cumulative gematria added", fD.every((v, k) => v.length === 10 && v[4] === fT[k][4] && v[5] === fT[k][6] && v[8] === fT[k][9] && v[9] === D.gematriaOf(U[k].letters) / 100));
const svg = D.sentencesSVG(L0); ok("clusters at level 3 or more write their sentences along their own outline (SVG textPath)", (svg.match(/<textPath/g) ?? []).length > 0 && svg.includes("Gate "));

console.log("9 — cluster -> computational graph");
const big = L0.clusters().sort((a, b) => b.length - a.length)[0], G = D.compileGraph(big);
console.log(`     cluster of ${big.length}: ${G.nodes.length} nodes, ${G.edges.length} edges, outputs ${G.outputs.join(",")}; activations ${[...new Set(G.nodes.map(n => n.act))].join(" ")}`);
ok("edges only run from lower id to higher (always a DAG); sources read x, y or r by their line's level", G.edges.every(e => e.from < e.to) && G.nodes.filter(n => n.source).every(n => ["x", "y", "r"].includes(n.input)));
const gen = new Function("return " + G.jsSource)(); let same = true;
for (let i = -1; i <= 1; i += 0.25) for (let j = -1; j <= 1; j += 0.25) { const a = G.evaluate(i, j), b = gen(i, j); same &&= a.length === b.length && a.every((v, k) => Math.abs(v - b[k]) < 1e-9); }
ok("the generated JavaScript gives the same numbers as the graph itself", same);
ok("the GLSL shader has every node and writes gl_FragColor (not run here: no GPU)", G.nodes.every(n => G.glsl.includes(`n${n.id} =`)) && G.glsl.includes("gl_FragColor"));
const img = D.image(G, 24, 24), au = D.audio(G);
ok("CPPN image: 24x24 RGBA, not flat", img.data.length === 24 * 24 * 4 && new Set(img.data.filter((_, i) => i % 4 === 0)).size > 3);
ok("audio: 16 notes in pitch and loudness, and samples you can play", au.notes.length === 16 && au.notes.every(n => n.hz > 100 && n.hz < 500) && au.samples(4000).length === 8000);
ok("deterministic: the same cluster compiles to the same graph", D.compileGraph(big).jsSource === G.jsSource);

console.log("10 — routing by leading dimension");
const out = Object.fromEntries(["Movement", "Evolution", "Being", "Design", "Space"].map(d => [d, D.route(d, G)]));
ok("Movement -> keyframes; Evolution -> recurrent history; Being -> image + shader; Design -> HTML; Space -> 3D points + panned audio",
  out.Movement.keyframes.length === 8 && out.Evolution.history.length === 4 && out.Being.image.data.length > 0 && /^precision/.test(out.Being.shader) &&
  /<section/.test(out.Design.html) && /<button/.test(out.Design.html) && out.Space.points[0].length === 3 && "pan" in out.Space.audio[0]);
ok("Space still never leads by itself (it results from the four); its route runs only when pinned", OPS.leadingDimension(L0.units, L0.units.flatMap(u => u.bonds)).leader !== "Space");

console.log("11 — the switches in the living swarm");
const v64k = baseline("v64k");
if (v64k) { const K = await import(v64k); const a = swarm(40, 9), b = new K.LivingSwarm({ seed: 9 });
  for (let i = 0; i < 40; i++) b.add({ gate: 1 + (i * 7) % 64, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: DIMS[i % 4], degree: (i * 37) % 360, house: 1 + (i * 5) % 12 }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  for (let k = 0; k < 25; k++) { a.step(); b.step(); }
  const diff = differences(a, b); if (diff.length) console.log("     " + diff.slice(0, 5).join("; "));
  ok("all switches off: the swarm is v64k's, step for step (positions, health, addresses, bonds, acquired, learned, programs)", !diff.length); }
else ok("v64k baseline present for comparison (regression-baselines/ or SYNTHIA_BASELINES)", false);
const keep = { ...SETTINGS };
SETTINGS.HASH_BOND = "0"; const Lh = swarm(48, 11); Lh.step(); const opened = Lh.units.flatMap(u => u.bonds).filter(e => e.via?.hashPrefix);
ok(`hash bond on (prefix "0" for the test): ${opened.length} bonds opened by hash that resonance alone would not have`, opened.length > 0 && opened.every(e => !e.spec.connectionCount && !e.count));
Object.assign(SETTINGS, keep); SETTINGS.SHIFT_LOCOMOTION = true; SETTINGS.PHASE_SYNC = 0.3;
const Ls = swarm(48, 13), r00 = Ls.units.map(u => u.reg); for (let k = 0; k < 20; k++) Ls.step();
ok("register locomotion on: registers turn, headings and arrows follow", Ls.units.some((u, i) => u.reg !== r00[i]) && Ls.units.every(u => u.glyph.arrow === D.arrowGlyph(u.heading)));
ok(`phase sync on: neighbours' rhythm is measured each step (${Ls.rhythm.toFixed(3)})`, Ls.rhythm > 0.5 && Ls.rhythm <= 1);
Object.assign(SETTINGS, keep);
ok("a unit's state hash gives its hex, XYZ and RGB on demand", /^#[0-9A-F]{6}$/.test(Ls.units[0].state.hex) && Ls.units[0].state.xyz.length === 3);

console.log("12 — purity");
const src = readFileSync(new URL("./dualswarm.js", import.meta.url), "utf8").replace(/^\s*\/\/.*$/gm, "");
ok("dualswarm.js: no randomness, no network, no model, no training", !/Math\.random|fetch\(|tensorflow|onnx|torch|\.train\(|backprop/i.test(src));

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
