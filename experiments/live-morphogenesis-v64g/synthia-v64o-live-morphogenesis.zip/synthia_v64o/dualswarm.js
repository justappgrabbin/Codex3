// dualswarm.js — the parts of Celestial's "BHANTUGH — Adaptive Generative Dual-Swarm Architecture" doc that v64k did not
// have yet (v64l, Nov 26). Most of the doc was already built from their Nov 20 BHANTUGH spec and is reused, not redone:
//   bhantugh_ops.js (opcodes §5, NATO §7, contracts §8, bond rule §19, levels §20, leading dimension §23, Sobel picture §21),
//   encoding.js (8 layers per character, sha256, transliteration §1), living.js (XOR attract/repel §3, box glyphs §6,
//   hash combine §9, gematria mass §10, SVG §12), formation.js (10D features + gossip §17, thesis version),
//   relational.js (NAND on every bond: Swarm A's Boolean side §15).
// What this file adds, each pure and with no model or training (the doc's "neural network / tensor graph" targets in §22
// are left out on purpose; the CPPN, shader, audio, motion, recurrent, layout and 3D paths are procedural):
//   §3 bit-shift locomotion   §4 hex -> XYZ / RGB   §6 shape + arrow glyphs   §7 NATO clock-phase sync
//   §8 isClusterNode type guard   §9 hash-prefix bond   §10/§13 digital root -> n-fold polygon, the whole ten-step cycle
//   §17 the doc's own 10D variant (10th = cumulative gematria)   §20 levels by governing coordinates
//   §21 sentences along contours (SVG textPath)   §22/§24 cluster -> computational graph (JS, generated JS, GLSL, image, audio)
//   §23 leading-dimension output routing   §18 the hexagram read two ways (trigrams for bonding, bigrams for level)
// Every pick of mine is marked MY PICK and is a setting or a table you can change.
import { sha256Hex } from "./encoding.js";
import { maskFromKingWen } from "./kingwen.js";
import { TRIGRAMS } from "./hexagram.js";
import * as OPS from "./bhantugh_ops.js";
import { features } from "./formation.js";

const enc = s => new TextEncoder().encode(s);
export const digitalRoot = n => (n > 0 ? 1 + ((n - 1) % 9) : 0);                       // §10: 52 -> 7
export const gematriaOf = text => [...String(text).toUpperCase()].reduce((s, c) => s + (c >= "A" && c <= "Z" ? c.charCodeAt(0) - 64 : 0), 0);

// ---------------------------------------------------------------- §18 the hexagram read two ways
// Bottom line = line 1 = bit 0 of the King Wen mask (hexagram.js convention).
export const HARMONY_PAIRS = [[1, 4], [2, 5], [3, 6]];                                  // doc §19: opposite-trigram harmony
export const BIGRAMS = { earth: [1, 2], human: [3, 4], heaven: [5, 6] };               // the traditional three powers (levels)
const levelOfLine = l => (l <= 2 ? "earth" : l <= 4 ? "human" : "heaven");
/** Both readings of one gate, and how they sit together. */
export function readings(gate) {
  const mask = maskFromKingWen(gate), line = l => (mask >> (l - 1)) & 1;
  const lines = [1, 2, 3, 4, 5, 6].map(line);
  const lower = mask & 7, upper = (mask >> 3) & 7;
  const bigrams = Object.fromEntries(Object.entries(BIGRAMS).map(([k, [a, b]]) => [k, { lines: [a, b], value: line(a) | (line(b) << 1), bits: `${line(b)}${line(a)}` }]));
  const pairs = HARMONY_PAIRS.map(([a, b]) => ({ lines: [a, b], same: line(a) === line(b), joins: [levelOfLine(a), levelOfLine(b)] }));
  return { gate, mask, lines, trigrams: { lower: TRIGRAMS[lower], upper: TRIGRAMS[upper] }, bigrams, pairs,
    resonance: pairs.filter(p => p.same).length };                                       // how many of its own line pairs agree
}
/** The structural facts that tie the two readings (true for every gate; the test checks them on all 64). */
export function howTheyMeet() {
  const bridges = HARMONY_PAIRS.map(([a, b]) => [levelOfLine(a), levelOfLine(b)].join("-"));
  return { everyLineInOnePairAndOneBigram: [1, 2, 3, 4, 5, 6].every(l => HARMONY_PAIRS.filter(p => p.includes(l)).length === 1 && Object.values(BIGRAMS).filter(b => b.includes(l)).length === 1),
    trigramCutSplitsOnlyTheHumanBigram: Object.entries(BIGRAMS).filter(([, [a, b]]) => (a <= 3) !== (b <= 3)).map(([k]) => k),
    eachHarmonyPairBridgesTwoLevels: bridges,                                              // earth-human, earth-heaven, human-heaven
    everyPairOfLevelsHasExactlyOneBridge: new Set(bridges).size === 3 && bridges.every(b => b.split("-")[0] !== b.split("-")[1]) };
}
/** How many bits an address carries at each depth. The six-bit hexagram is one depth; line, color, tone and base add more
 *  (log2 of their ranges). The doc gives no per-field counts for Mind or Heart, so none are invented here. */
export function depthBits(a) {
  const add = (k, n) => (a[k] != null ? Math.log2(n) : 0);
  const hex = a.gate ? 6 : 0;
  return { hexagram: hex, bigrams: hex ? 3 : 0, line: add("line", 6), color: add("color", 6), tone: add("tone", 6), base: add("base", 5),
    total: +(hex + add("line", 6) + add("color", 6) + add("tone", 6) + add("base", 5)).toFixed(3) };
}

// ---------------------------------------------------------------- §3 register + bit-shift locomotion
/** The unit's 32-bit register: its address bits folded into one integer (XOR of 32-bit chunks). */
export function registerOf(bits) { let r = 0; for (let i = 0; i < bits.length; i += 32) { let w = 0; for (let k = 0; k < 32 && i + k < bits.length; k++) w = (w << 1) | bits[i + k]; r ^= w; } return r >>> 0; }
// MY PICK: rotate instead of plain shift, so no bit of the address is ever lost (a plain << 1 empties the register in 32 steps).
export const rotl = r => ((r << 1) | (r >>> 31)) >>> 0;
export const rotr = r => ((r >>> 1) | ((r & 1) << 31)) >>> 0;
/** One locomotion beat: << while the unit's cycle rises, >> while it falls (MY PICK). Low nibble = heading in 16ths of a turn. */
export function shiftStep(reg, rising) { const r = rising ? rotl(reg) : rotr(reg); return { reg: r, heading: (r & 15) * (2 * Math.PI / 16), op: rising ? "<<1" : ">>1" }; }

// ---------------------------------------------------------------- §4 hex -> XYZ sectors + RGB
/** Six hex digits -> three bytes -> X, Y, Z sectors (0..1) and RGB. 0x3F8A1C -> 3F / 8A / 1C. */
export function hexOf(hex) {
  const h = String(hex).replace(/^0x/i, "").slice(0, 6).padEnd(6, "0"), b = [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16));
  return { hex: "#" + h.toUpperCase(), bytes: b, xyz: b.map(v => v / 255), rgb: b, sector: b.map(v => v >> 4) };    // sector = high nibble, 16 per axis
}
/** A unit's state hash (sha256 of its bit string) and its projection. */
export function stateOf(bits) { const hash = sha256Hex(enc(bits.join(""))); return { hash, ...hexOf(hash) }; }

// ---------------------------------------------------------------- §6 shape + arrow glyphs
const SHAPE = { 1: "●", 2: "●", 3: "▲", 4: "■", 5: "⬟", 6: "⬢" };                 // ⬟ ⬢ are outside U+25A0-25FF (no five or six-sided
const ARROWS = ["→", "↗", "↑", "↖", "←", "↙", "↓", "↘"];                                  //   shape exists in that block); 7-9 have no glyph
export const shapeGlyph = n => SHAPE[n] ?? "●";                                           //   anywhere, so they draw as the SVG polygon
export const arrowGlyph = heading => ARROWS[((Math.round(heading / (Math.PI / 4)) % 8) + 8) % 8];

// ---------------------------------------------------------------- §10 / §13 n-fold polygon and the ten-step cycle
export function polygonPoints(n, cx = 0, cy = 0, r = 1, turn = -Math.PI / 2) {
  if (n < 3) return [[cx, cy]]; return Array.from({ length: n }, (_, k) => [cx + r * Math.cos(turn + 2 * Math.PI * k / n), cy + r * Math.sin(turn + 2 * Math.PI * k / n)]); }
export function polygonSVG(n, { size = 120, fill = "none", stroke = "currentColor" } = {}) {
  const c = size / 2, p = polygonPoints(n, c, c, c * 0.8);
  const shape = n < 3 ? `<circle cx="${c}" cy="${c}" r="${(c * 0.8).toFixed(1)}" fill="${fill}" stroke="${stroke}"/>` : `<polygon points="${p.map(q => q.map(v => v.toFixed(1)).join(",")).join(" ")}" fill="${fill}" stroke="${stroke}"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" data-fold="${n}">${shape}</svg>`;
}
const NATO_DOC = OPS.voice;                                                               // ICAO spelling (Alfa, Juliett), as v64k
/** §13 on a word: FORM -> 52 -> 7 -> sevenfold polygon, Foxtrot Oscar Romeo Mike. */
export function cycleWord(word) { const g = gematriaOf(word), n = digitalRoot(g);
  return { word, gematria: g, root: n, fold: n, glyph: shapeGlyph(n), nato: NATO_DOC(word), svg: polygonSVG(n), program: OPS.program(word) }; }
/** §13 on two units, all ten steps. a, b: { address, bits }. input: optional user change (step 9) = bit index to flip on a. */
export function cycle(a, b, { input = null, prefix = "00" } = {}) {
  const A = input == null ? a.bits : a.bits.map((x, i) => (i === input ? x ^ 1 : x));
  const hb = hashBond(A, b.bits, prefix);                                                // 1 binary + hash
  const bytes = hb.hash.match(/../g).map(x => parseInt(x, 16));
  const chars = bytes.map(v => String.fromCharCode(v & 0x7f));                            // 2 hex -> ASCII
  const instructions = chars.map(c => OPS.opcodeName(c.charCodeAt(0))).filter(Boolean);
  const g = gematriaOf(chars.join("")), n = digitalRoot(g);                               // 3 gematria
  const geometry = { fold: n, points: polygonPoints(n) };                                 // 4 geometry
  const glyph = shapeGlyph(n);                                                            // 5 unicode
  const spec = OPS.evaluateSwarmBond(a.address, b.address);                               // 6 contracts + bond rule
  const valid = !spec.rejected && (spec.isVisible || hb.pass);
  const nato = valid ? NATO_DOC(chars.filter(c => /[A-Za-z]/.test(c)).join("")) : [];    // 7 only validated clusters broadcast
  const svg = valid ? polygonSVG(n) : null;                                               // 8 html
  const child = { gate: bytes[0] % 64 + 1, line: bytes[1] % 6 + 1, color: bytes[2] % 6 + 1, tone: bytes[3] % 6 + 1, base: bytes[4] % 5 + 1, dimension: a.address.dimension };
  return { hash: hb.hash, hashBond: hb.pass, ...hexOf(hb.hash), instructions, gematria: g, fold: n, geometry, glyph, spec, valid, nato, svg,
    input, next: child };                                                                 // 9-10: the child state goes round again
}

// ---------------------------------------------------------------- §9 hash-prefix bond
/** hash(stateA + stateB).startsWith(prefix). MY PICK: the two bit strings are put in a fixed order (smaller first) so the
 *  answer does not depend on which unit asks. "00" passes about 1 in 256 pairs. */
export function hashBond(aBits, bBits, prefix = "00") {
  const x = aBits.join(""), y = bBits.join(""), s = x <= y ? x + "|" + y : y + "|" + x, hash = sha256Hex(enc(s));
  return { hash, pass: prefix ? hash.startsWith(prefix) : false, prefix };
}

// ---------------------------------------------------------------- §7 NATO clock-phase sync
/** Neighbours that hear each other (validated bonds only, §13 step 7) pull their clock phases together (Kuramoto rule).
 *  phase is in steps of a period P; K = coupling. A unit's NATO beats set how loudly it is heard (more syllables, stronger). */
export function syncPhases(units, P, K) {
  if (!K) return 0; const d = new Map();
  for (const u of units) { if (u.broken) continue; let s = 0, n = 0;
    for (const e of u.bonds) { if (!e.visible) continue; const o = units[e.a === u.id ? e.b : e.a]; if (!o || o.broken) continue;
      const w = (o.opcode?.beats ?? 1); s += w * Math.sin(2 * Math.PI * (o.phase - u.phase) / P); n += w; }
    if (n) d.set(u, K * s / n * P / (2 * Math.PI)); }
  for (const [u, x] of d) u.phase = ((u.phase + x) % P + P) % P;
  return localOrder(units, P);
}
/** How in step neighbours are: mean cos of the phase gap across validated bonds (1 = each pair beats together). */
export function localOrder(units, P) { let s = 0, n = 0; for (const u of units) for (const e of u.bonds) { if (!e.visible || e.a !== u.id) continue; const o = units[e.b]; if (u.broken || o.broken) continue; s += Math.cos(2 * Math.PI * (o.phase - u.phase) / P); n++; } return n ? s / n : 0; }
/** How in step the whole swarm is: 1 = one rhythm, 0 = scattered (separate clusters can each keep their own). */
export function order(units, P) { let c = 0, s = 0, n = 0; for (const u of units) { if (u.broken) continue; c += Math.cos(2 * Math.PI * u.phase / P); s += Math.sin(2 * Math.PI * u.phase / P); n++; } return n ? Math.hypot(c, s) / n : 0; }

// ---------------------------------------------------------------- §8 type guards
const DIMS = ["Movement", "Evolution", "Being", "Design", "Space"];
const RANGES = { gate: [1, 64], line: [1, 6], color: [1, 6], tone: [1, 6], base: [1, 5], degree: [0, 359], minute: [0, 59], second: [0, 59], house: [1, 12] };
/** Is this a well-formed ontological address? Fields may be missing (variable depth); a field that is present must be in range. */
export function isOntologicalAddress(a) {
  if (!a || typeof a !== "object" || !OPS.CONTRACTS.bondable(a)) return false;
  if (a.dimension != null && !DIMS.includes(a.dimension)) return false;
  return Object.entries(RANGES).every(([k, [lo, hi]]) => a[k] == null || (Number.isFinite(+a[k]) && +a[k] >= lo && +a[k] <= hi));
}
/** isClusterNode(agent): a living unit with a good address and at least one visible bond. */
export const isClusterNode = u => !!u && !u.broken && isOntologicalAddress(u.address) && (u.bonds ?? []).some(e => e.visible);

// ---------------------------------------------------------------- §20 levels by governing coordinates
export const LEVEL_TABLE = [
  { level: 1, name: "Root Vector", governs: ["base"], shows: "anchor points, image-edge positions" },
  { level: 2, name: "Sensory Field", governs: ["tone", "color"], shows: "colour, spacing, curve tension" },
  { level: 3, name: "Structural Line", governs: ["line", "gate"], shows: "Unicode connectors, sentences" },
  { level: 4, name: "Dimensional Manifold", governs: ["dimension", "planetary"], shows: "sentence grouping, contour alignment" },
  { level: 5, name: "Macro Interface", governs: ["zodiac", "house", "arc"], shows: "interactive HTML/SVG" },
];
/** What an edge of a given level shows: everything at or below its level. Level comes from the count (§19), as before. */
export const shownAt = level => LEVEL_TABLE.filter(L => L.level <= level);

// ---------------------------------------------------------------- §17 the doc's 10D variant
/** The doc lists 5 distance + 5 structural features; the thesis vector (formation.js) repeats degree and has no gematria.
 *  Doc order: mean, min, max, sd, degree | unconnected pairs, connected pairs, two-hop, hub, cumulative gematria.
 *  The 10th is the unit's own gematria (scaled by 1/100, as mass is); gossip rounds then accumulate it over the neighbourhood. */
export function featuresDoc(units, r) {
  return features(units, r).map((f, k) => [f[0], f[1], f[2], f[3], f[4], f[6], f[7], f[8], f[9], gematriaOf(units[k].letters ?? units[k].sentence ?? "") / 100]);
}

// ---------------------------------------------------------------- §21 sentences along contours
/** A closed contour through points (ordered by angle round their centre), as an SVG path. */
export function contourPath(points) {
  if (!points.length) return ""; const cx = points.reduce((s, p) => s + p[0], 0) / points.length, cy = points.reduce((s, p) => s + p[1], 0) / points.length;
  const P = points.slice().sort((p, q) => Math.atan2(p[1] - cy, p[0] - cx) - Math.atan2(q[1] - cy, q[0] - cx));
  return "M" + P.map(p => p.map(v => v.toFixed(1)).join(" ")).join(" L") + " Z";
}
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
/** Every cluster that has reached level 3 writes its members' sentences along its own outline (SVG textPath). */
export function sentencesSVG(swarm, size = 400) {
  const out = []; let k = 0;
  for (const g of swarm.clusters()) { const lv = Math.max(0, ...g.flatMap(u => u.bonds.map(e => e.level ?? 0))); if (g.length < 2 || lv < 3) continue;
    const d = contourPath(g.map(u => [u.x * size, u.y * size])), id = `c${k++}`, text = g.map(u => u.letters).join("  ·  ");
    out.push(`<path id="${id}" d="${d}" fill="none" stroke="currentColor" stroke-opacity="0.2"/><text font-size="7"><textPath href="#${id}">${esc(text)}</textPath></text>`); }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${out.join("")}</svg>`;
}

// ---------------------------------------------------------------- §22 / §24 cluster -> computational graph
// Node: gate -> activation (chosen by the gate's lower trigram), color -> scale, base -> bias. Edge: sender's tone -> weight.
// MY PICK of which trigram takes which function (a table; change it freely). These are the usual CPPN functions.
export const ACTIVATIONS = [
  { trigram: "Kun ☷", name: "gauss", js: "Math.exp(-(v)*(v))", glsl: "exp(-(v)*(v))", f: v => Math.exp(-v * v) },
  { trigram: "Zhen ☳", name: "step", js: "((v)>0?1:-1)", glsl: "sign(v)", f: v => (v > 0 ? 1 : -1) },
  { trigram: "Kan ☵", name: "sin", js: "Math.sin(v)", glsl: "sin(v)", f: Math.sin },
  { trigram: "Dui ☱", name: "sigmoid", js: "1/(1+Math.exp(-(v)))", glsl: "1.0/(1.0+exp(-(v)))", f: v => 1 / (1 + Math.exp(-v)) },
  { trigram: "Gen ☶", name: "clamp", js: "Math.max(-1,Math.min(1,v))", glsl: "clamp(v,-1.0,1.0)", f: v => Math.max(-1, Math.min(1, v)) },
  { trigram: "Li ☲", name: "abs", js: "Math.abs(v)", glsl: "abs(v)", f: Math.abs },
  { trigram: "Xun ☴", name: "tanh", js: "Math.tanh(v)", glsl: "tanh(v)", f: Math.tanh },
  { trigram: "Qian ☰", name: "linear", js: "(v)", glsl: "(v)", f: v => v },
];
// Source nodes read the input chosen by their line's level (the bigram reading): earth lines read x, human y, heaven the radius.
const INPUT_OF_LEVEL = { earth: "x", human: "y", heaven: "r" };
/** Build the graph of one cluster: nodes in id order, edges only from lower id to higher (so it is always a DAG). */
export function compileGraph(cluster) {
  const U = cluster.filter(u => !u.broken && OPS.CONTRACTS.bondable(u.address)).slice().sort((p, q) => p.id - q.id), ids = new Set(U.map(u => u.id));
  const nodes = U.map(u => { const a = u.address, act = ACTIVATIONS[maskFromKingWen(a.gate) & 7];
    return { id: u.id, gate: a.gate, act: act.name, scale: (a.color ?? 1) / 2, bias: ((a.base ?? 3) - 3) / 2, input: INPUT_OF_LEVEL[levelOfLine(a.line ?? 1)], dimension: a.dimension }; });
  const at = new Map(nodes.map((n, i) => [n.id, i])), seen = new Set(), edges = [];
  for (const u of U) for (const e of u.bonds) { if (!ids.has(e.a) || !ids.has(e.b) || !e.connectionCount) continue;
    const from = Math.min(e.a, e.b), to = Math.max(e.a, e.b), k = from + ">" + to; if (seen.has(k)) continue; seen.add(k);
    const t = cluster.find(v => v.id === from).address.tone ?? 3;
    edges.push({ from, to, weight: +((t - 3.5) / 1.25).toFixed(3), level: e.level ?? e.connectionCount }); }
  const hasIn = new Set(edges.map(e => e.to)), hasOut = new Set(edges.map(e => e.from));
  for (const n of nodes) { n.source = !hasIn.has(n.id); n.sink = !hasOut.has(n.id); }
  const outputs = nodes.filter(n => n.sink).map(n => n.id).slice(0, 3);
  const G = { nodes, edges, outputs, index: at };
  G.evaluate = (x, y, extra = 0) => evaluate(G, x, y, extra);
  G.jsSource = jsSource(G); G.glsl = glslSource(G);
  return G;
}
function evaluate(G, x, y, extra = 0) {
  const r = Math.hypot(x, y), inp = { x, y, r }, val = new Map();
  for (const n of G.nodes) { let s = n.bias + extra + (n.source ? inp[n.input] : 0);
    for (const e of G.edges) if (e.to === n.id) s += e.weight * val.get(e.from);
    val.set(n.id, ACTIVATIONS.find(a => a.name === n.act).f(n.scale * s)); }
  const o = G.outputs.map(id => val.get(id)); return o.length ? o : [0];
}
function jsSource(G) {
  const A = Object.fromEntries(ACTIVATIONS.map(a => [a.name, a.js])), body = G.nodes.map(n => {
    const terms = [String(n.bias), "e", ...(n.source ? [n.input] : []), ...G.edges.filter(e => e.to === n.id).map(e => `${e.weight}*n${e.from}`)];
    return `const n${n.id}=(()=>{const v=${n.scale}*(${terms.join("+")});return ${A[n.act]};})();`; }).join("\n");
  return `(x,y,e=0)=>{const r=Math.hypot(x,y);\n${body}\nreturn [${G.outputs.map(i => "n" + i).join(",") || "0"}];}`;
}
function glslSource(G) {
  const A = Object.fromEntries(ACTIVATIONS.map(a => [a.name, a.glsl])), f = x => (Number.isInteger(x) ? x.toFixed(1) : String(x));
  const body = G.nodes.map(n => { const terms = [f(n.bias), ...(n.source ? [n.input] : []), ...G.edges.filter(e => e.to === n.id).map(e => `${f(e.weight)}*n${e.from}`)];
    return `  float n${n.id}; { float v = ${f(n.scale)}*(${terms.join("+")}); n${n.id} = ${A[n.act]}; }`; }).join("\n");
  const o = G.outputs.map(i => `n${i}`), rgb = o.length >= 3 ? `vec3(${o.slice(0, 3).join(",")})` : `vec3(${o[0] ?? "0.0"})`;
  return `precision mediump float;\nuniform vec2 u_res;\nvoid main(){\n  vec2 p = gl_FragCoord.xy/u_res*2.0-1.0; float x=p.x, y=p.y, r=length(p);\n${body}\n  gl_FragColor = vec4(${rgb}*0.5+0.5, 1.0);\n}`;
}
/** CPPN image: w*h RGBA bytes (one output = grey, three = RGB). Coordinates run -1..1. */
export function image(G, w, h, extra = 0) {
  const px = new Uint8ClampedArray(w * h * 4);
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const o = G.evaluate(i / (w - 1) * 2 - 1, j / (h - 1) * 2 - 1, extra), c = o.length >= 3 ? o : [o[0], o[0], o[0]], k = (j * w + i) * 4;
    for (let q = 0; q < 3; q++) px[k + q] = Math.round((Math.tanh(c[q]) * 0.5 + 0.5) * 255); px[k + 3] = 255; }
  return { w, h, data: px };
}
/** Audio: the graph read along time (x = t, y = 0). Pitch from the first output, loudness from the second (if any). */
export function audio(G, { steps = 16, seconds = 2, root = 220 } = {}) {
  const notes = Array.from({ length: steps }, (_, k) => { const t = k / (steps - 1), o = G.evaluate(t * 2 - 1, 0);
    return { t: +(t * seconds).toFixed(3), hz: +(root * 2 ** Math.tanh(o[0])).toFixed(2), amp: +((Math.tanh(o[1] ?? o[0]) * 0.5 + 0.5) * 0.2).toFixed(3) }; });
  const samples = (rate = 8000) => { const n = Math.round(seconds * rate), out = new Float32Array(n); let ph = 0;
    for (let i = 0; i < n; i++) { const s = notes[Math.min(steps - 1, Math.floor(i / n * steps))]; ph += 2 * Math.PI * s.hz / rate; out[i] = s.amp * Math.sin(ph); } return out; };
  return { notes, samples };
}

// ---------------------------------------------------------------- §23 leading-dimension output routing
export const ROUTES = {
  Movement: "motion keyframes", Evolution: "recurrent refinement", Being: "image (CPPN) + shader", Design: "layout (HTML)", Space: "3D points + spatial audio",
};
/** Route a graph by the leading dimension. Space never leads on its own (it results from the four); it runs only if pinned. */
export function route(leader, G, { frames = 8, w = 16, h = 16, iterations = 4 } = {}) {
  switch (leader) {
    case "Movement": return { leader, pipeline: ROUTES.Movement, keyframes: Array.from({ length: frames }, (_, k) => { const t = k / (frames - 1) * 2 - 1, o = G.evaluate(t, Math.sin(Math.PI * t));
      return { t: +t.toFixed(3), x: +Math.tanh(o[0]).toFixed(4), y: +Math.tanh(o[1] ?? o[0]).toFixed(4) }; }) };
    case "Evolution": { let extra = 0; const history = [];                               // its own last output comes back in
      for (let k = 0; k < iterations; k++) { const img = image(G, w, h, extra); const m = img.data.reduce((s, v, i) => s + (i % 4 === 3 ? 0 : v), 0) / (w * h * 3) / 255;
        history.push(+m.toFixed(4)); extra = (m - 0.5) * 2; }
      return { leader, pipeline: ROUTES.Evolution, history, last: image(G, w, h, extra) }; }
    case "Being": return { leader, pipeline: ROUTES.Being, image: image(G, w, h), shader: G.glsl };
    case "Design": { const kids = n => G.edges.filter(e => e.from === n.id).map(e => G.nodes[G.index.get(e.to)]);
      const html = n => `<section data-node="${n.id}" data-gate="${n.gate}">${kids(n).map(html).join("")}${n.sink ? `<button data-node="${n.id}">${n.act}</button>` : ""}</section>`;
      return { leader, pipeline: ROUTES.Design, html: G.nodes.filter(n => n.source).map(html).join("") }; }
    case "Space": { const pts = []; for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const x = i / (w - 1) * 2 - 1, y = j / (h - 1) * 2 - 1; pts.push([+x.toFixed(3), +y.toFixed(3), +Math.tanh(G.evaluate(x, y)[0]).toFixed(4)]); }
      return { leader, pipeline: ROUTES.Space, points: pts, audio: audio(G).notes.map(n => ({ ...n, pan: +Math.tanh(G.evaluate(0, n.t)[0]).toFixed(3) })) }; }
    default: return { leader, pipeline: null };
  }
}
