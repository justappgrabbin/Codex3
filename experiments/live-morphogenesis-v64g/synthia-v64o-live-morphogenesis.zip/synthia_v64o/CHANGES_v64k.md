# v64k (Nov 26) — the agent turned: Movement and Being on the vertical axis

Celestial said yes to the turn and gave the readings: "being moves across and counts up moving down movement moves upward and
reads across but everything is in line even the duals". Built on v64j; v64j kept as it is.

- tiling.js   AGENT corners now B Movement, T Being, E1 Space, E2 Design, E3 Evolution. The v64h orientation is kept by name
              (ORIENTATIONS.v64h, setOrientation("v64h") puts it back). Faces, ports, self faces (2, 5) unchanged, so the
              governor, the two sides and every earlier test read the same.
- axis.js     the two readings, derived from the agent's shape: Movement from the bottom tip upward (faces 1..6, the I Ching
              count), Being from the top tip downward (4 5 6 then 1 2 3), both across the same way round. One size up, a shell's
              rings from the corner it grew from: Being reads them top to bottom, Movement bottom to top, each ring the same walk.
              Space, Evolution and Design get no reading (not described).
- In line:    the agent's two lines (tip-to-tip axis, and the seam the self faces share) now each hold one dual pair; across the
              two sides every agent sits on the same ring as its shadow partner.
- test_axis.mjs  14 checks, with and without Arcadia; run_all.sh runs it. Whole suite green.
- My picks:   a shell's top is the corner it grew from; "across" in a ring = start at the lowest agent, step to the lowest neighbour.
- Note:       the crystal pairing candidate (Space+Evolution, Being+Design, Movement alone) would not keep the duals on these
              lines; it is still not wired.
