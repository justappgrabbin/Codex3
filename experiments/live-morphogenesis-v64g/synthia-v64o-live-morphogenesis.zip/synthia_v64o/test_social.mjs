// test_social.mjs — the social laws (social.js, v64m). Run plain and: node run_with_arcadia.mjs test_social.mjs
//   1 crowding brakes   2 the mood law, exactly   3 re-weighing every 5th message, ties break below 1   4 multiply by mood
//   5 inheritance by chance   6 dissolve by mood and by age; persons stay   7 messages need sight; new ties only with units in touch
//   8 a whole run repeats exactly   9 no Society attached = v64l unchanged   10 purity
import { readFileSync, existsSync } from "node:fs";
import { LivingSwarm, SETTINGS, PRIMARIES } from "./living.js";
import { Society, SOCIAL, brakes, meaningOf, dominantList } from "./social.js";
import { baseline, differences } from "./regression.mjs";
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const DIMS = ["Movement", "Evolution", "Being", "Design"];
const addr = i => ({ gate: 1 + (i * 7) % 64, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: DIMS[i % 4], degree: (i * 37) % 360, house: 1 + (i * 5) % 12 });
const swarm = (n, kind = "mover", seed = 3, spread = 0.06) => { const L = new LivingSwarm({ seed });
  for (let i = 0; i < n; i++) L.add(addr(i), kind, 0.2 + (i % 10) * spread, 0.2 + Math.floor(i / 10) * 0.1); return L; };
const pair = (meaningSign, kind = "mover", far = false) => {           // two units, chosen so their first-contact meaning has the asked sign
  for (let i = 0; i < 64; i++) for (let j = i + 1; j < 64; j++) { const L = new LivingSwarm({ seed: 1 });
    const a = L.add(addr(i), kind, 0.5, 0.5), b = L.add(addr(j), kind, far ? 0.95 : 0.52, far ? 0.95 : 0.5); const m = meaningOf(b, a);
    if (Math.sign(m) === meaningSign) return { L, a, b, m }; } };

console.log("1 — crowding brakes (Center.Controlli)");
ok("under 100: divisor 2, max age 60, start weight 3", JSON.stringify(brakes(50)) === JSON.stringify({ crowd: "low", divisor: 2, maxAge: 60, startWeight: 3 }));
ok("100 to 10000: divisor 3, max age 50, start weight 2.5", brakes(100).divisor === 3 && brakes(10000).maxAge === 50 && brakes(500).startWeight === 2.5);
ok("over 10000: divisor 4, max age 30, start weight 2", brakes(10001).divisor === 4 && brakes(10001).maxAge === 30 && brakes(10001).startWeight === 2);
ok("the game's starting numbers: mood 50, birth at 100 costs 50, 3 children, 60% get a chance at a new tie, weights 1 to 5",
  SOCIAL.START_MOOD === 50 && SOCIAL.BIRTH_AT === 100 && SOCIAL.BIRTH_COST === 50 && SOCIAL.CHILDREN === 3 && SOCIAL.NEW_TIE_SHARE === 0.6 && SOCIAL.MIN_WEIGHT === 1 && SOCIAL.MAX_WEIGHT === 5);

console.log("2 — the mood law: mood += interpretation x relationship weight / divisor");
{ const { L, a, b, m } = pair(1); const So = new Society(L, { seed: 2 }); So.tie(a, b);
  const r = So.hear(b, a, "Q"); const w = So.brake.startWeight, d = So.brake.divisor;
  console.log(`     first meaning ${m} (from the resonance of first contact), weight ${w}, divisor ${d}: ${r.before} -> ${r.after}`);
  ok("a word heard the first time takes its meaning from the resonance count (2c - 5, so -5..5)", r.meaning === m && m >= -5 && m <= 5 && b.soc.vocab.get("Q") === m);
  ok("mood moves by exactly meaning x weight / divisor", r.after === 50 + m * w / d);
  b.soc.vocab.set("Z", -4); const r2 = So.hear(b, a, "Z");
  ok("a word already in the vocabulary keeps its meaning (the same word can mean different things to different units)", r2.meaning === -4 && r2.after === r.after - 4 * w / d);
  ok("no tie, no hearing", So.hear(a, { id: 999 }, "Q") === null); }

console.log("3 — re-weighing every 5th message; the tie breaks below 1");
{ const { L, a, b, m } = pair(-1); const So = new Society(L, { seed: 2 }); So.tie(a, b); const w0 = b.soc.ties.get(a.id).weight;
  for (let k = 0; k < 4; k++) So.hear(b, a, "Q"); const w4 = b.soc.ties.get(a.id).weight; So.hear(b, a, "Q"); const w5 = b.soc.ties.get(a.id).weight;
  console.log(`     meaning ${m}: weight ${w0} after 4 messages ${w4}, after the 5th ${w5}`);
  ok("weight holds for 4 messages, then moves by the mean of the last 5 / 5", w4 === w0 && Math.abs(w5 - (w0 + m / 5)) < 1e-12);
  const t = b.soc.ties.get(a.id); t.weight = 1.01; t.heard = [m, m, m, m]; a.soc.ties.get(b.id).heard = [];
  So.tick();
  ok("a tie whose weight falls below 1 breaks, on both sides", !b.soc.ties.has(a.id) && !a.soc.ties.has(b.id) && So.events.some(e => e.type === "untie" && e.why === "weight below 1"));
  const p = pair(1); const S2 = new Society(p.L, { seed: 2 }); S2.tie(p.a, p.b); const t2 = p.b.soc.ties.get(p.a.id); t2.weight = 4.99;
  for (let k = 0; k < 5; k++) S2.hear(p.b, p.a, "Q");
  ok("weight never goes above 5", t2.weight === 5); }

console.log("4 — multiply by mood");
{ const { L, a, b } = pair(1, "person", true); const So = new Society(L, { seed: 2 }); So.tie(a, b); b.soc.ties.get(a.id).weight = 5; a.soc.ties.get(b.id).weight = 2;
  a.soc.vocab.set("hello", 4); a.soc.mood = 100; const n0 = L.units.length; So.tick(); const c = L.units[n0];
  ok("mood 100: one child, mood drops by 50, children counted", L.units.length === n0 + 1 && a.soc.mood === 50 && a.soc.children === 1 && c.parent === a.id);
  ok("a person's child is a mover; it is born beside the parent", c.kind === "mover" && Math.hypot(c.x - a.x, c.y - a.y) < 0.021);
  ok("the child copies the parent's vocabulary", c.soc.vocab.get("hello") === 4);
  const ev = So.events.find(e => e.type === "birth");
  ok("its address is the hash of the parent with its strongest tie (a new gate-to-base address, not a copy)", ev.mate === b.id && c.address.gate >= 1 && c.address.gate <= 64 && c.address.base >= 1 && c.address.base <= 5 &&
    ["gate", "line", "color", "tone", "base"].some(k => c.address[k] !== a.address[k]));
  ok("the child gets a fresh mood and its own day of death", c.soc.mood === 50 && c.soc.deathAge >= So.brake.maxAge && c.soc.deathAge < So.brake.maxAge + SOCIAL.AGE_SPREAD);
  a.soc.mood = 100; a.soc.children = 3; const n1 = L.units.length; So.tick();
  ok("after 3 children, mood 100 still costs 50 but makes no child", L.units.length === n1 && a.soc.mood === 50 && a.soc.children === 3); }

console.log("5 — inheritance by chance");
{ const Lst = dominantList("Being");
  ok("the draw list is the four primaries plus one more copy of the parent's (4/4 = 1), never Space", Lst.length === 5 && Lst.filter(d => d === "Being").length === 2 && !Lst.includes("Space") && PRIMARIES.every(d => Lst.includes(d)));
  const So = new Society(swarm(2), { seed: 7 }); let same = 0; const N = 20000;
  for (let k = 0; k < N; k++) if (Lst[So.int(Lst.length)] === "Being") same++;
  console.log(`     parent's dimension drawn ${(same / N).toFixed(3)} of the time (2 in 5 = 0.400)`);
  ok("so the parent's dimension comes back about 2 times in 5", Math.abs(same / N - 0.4) < 0.015); }

console.log("6 — dissolve by mood and by age; persons stay");
{ const L = swarm(4, "mover", 3, 0.3); const So = new Society(L, { seed: 2 }); const [u, v] = L.units;
  u.soc.mood = -1; v.soc.born = -1000; const loose0 = L.loose.length; So.tick();
  ok("mood at or below 0: the unit dissolves and its address goes back to the loose pool", u.broken && L.loose.length >= loose0 + 1 && So.events.some(e => e.type === "dissolve" && e.unit === u.id && e.cause === "mood"));
  ok("past its day of death: it dissolves by age", v.broken && So.events.some(e => e.type === "dissolve" && e.unit === v.id && e.cause === "age"));
  ok("a dissolved unit leaves no ties behind", u.soc.ties.size === 0 && L.units.every(o => !o.soc?.ties.has(u.id)));
  const P = swarm(2, "person", 3, 0.3); const SP = new Society(P, { seed: 2 }); P.units[0].soc.mood = -5; P.units[1].soc.born = -1000; SP.tick();
  ok("a person's own unit never dissolves", !P.units[0].broken && !P.units[1].broken); }

console.log("7 — messages need sight; new ties only with units in touch");
{ const { L, a, b } = pair(1, "mover", true); const So = new Society(L, { seed: 2 }); So.tie(a, b);
  ok("the two are farther apart than sight", Math.hypot(a.x - b.x, a.y - b.y) > SETTINGS.SIGHT);
  for (let k = 0; k < 5; k++) So.tick();
  ok("a tie out of sight carries no messages", b.soc.ties.get(a.id).heard.length === 0 && a.soc.ties.get(b.id).heard.length === 0);
  const F = swarm(10, "mover", 3, 0.09); for (const u of F.units) u.bonds = []; const SF = new Society(F, { seed: 2 }); for (let k = 0; k < 20; k++) SF.tick();
  ok("with no bonds, no new ties form", !SF.events.some(e => e.type === "tie")); }

console.log("8 — a run repeats exactly");
const run = seed => { const L = swarm(40, "mover", 3); const So = new Society(L, { seed }); for (let k = 0; k < 25; k++) L.step(); return So; };
{ const A = run(5), B = run(5), C = run(6); const kinds = {}; for (const e of A.events) kinds[e.type] = (kinds[e.type] ?? 0) + 1;
  console.log(`     40 movers, 25 days: ${JSON.stringify(kinds)}; alive ${A.log.map(l => l.alive).filter((_, i) => i % 5 === 4).join(" ")}`);
  ok("same seeds, same events, same moods", JSON.stringify(A.events) === JSON.stringify(B.events) && A.alive().every((u, i) => u.soc.mood === B.alive()[i].soc.mood));
  ok("a different society seed gives a different history", JSON.stringify(A.events) !== JSON.stringify(C.events));
  ok("the log's crowd matches the brakes for the count alive", A.log.every(l => l.crowd === brakes(l.alive).crowd));
  ok("births and ties happen in a real run (dissolving by mood and by age is checked on its own in section 6)", kinds.birth > 0 && kinds.tie > 0); }

console.log("9 — no Society attached: the swarm is v64l's, step for step");
const v64l = baseline("v64l");
if (v64l) { const K = await import(v64l); const a = swarm(40, "person", 9), b = new K.LivingSwarm({ seed: 9 });
  for (let i = 0; i < 40; i++) b.add(addr(i), "person", 0.2 + (i % 10) * 0.06, 0.2 + Math.floor(i / 10) * 0.1);
  for (let k = 0; k < 25; k++) { a.step(); b.step(); }
  const diff = differences(a, b); if (diff.length) console.log("     " + diff.slice(0, 5).join("; "));
  ok("identical to v64l after 25 steps (positions, health, addresses, bonds, acquired, learned, programs)", !diff.length && !a.society); }
else ok("v64l baseline present for comparison (regression-baselines/ or SYNTHIA_BASELINES)", false);

console.log("10 — purity");
{ const src = readFileSync(new URL("./social.js", import.meta.url), "utf8"); const imports = [...src.matchAll(/from\s+"([^"]+)"/g)].map(m => m[1]);
  ok("social.js imports only the swarm itself (living.js, bhantugh_ops.js)", imports.join() === "./living.js,./bhantugh_ops.js");
  ok("no neural nets, no Math.random (its own seeded draws)", !/tensor|neural|onnx|tfjs|Math\.random/i.test(src)); }

console.log(`${pass} passed, ${fail} failed`); process.exitCode = fail ? 1 : 0;
