// test_governor.mjs — the swarm's own governing engine (v64i, Nov 26). Run plain and with run_with_arcadia.mjs.
//   1 qualities come from the address, not a script     2 kind first: a human vector and a building vector come out distinct
//   3 becoming   4 parts and the whole   5 governed by kind   6 expression   7 inside morphogenesis, with or without Arcadia
import { readFileSync } from "node:fs"; import { setGateEngineData } from "./gate_engine.js";
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js";
import { enter, AFTER_LEARN } from "./morphogenesis.js"; import { appHost } from "./hosts.js";
import { tile, seat, read } from "./tiling.js"; import { twoSides } from "./dual.js";
import { qualities, classify, govern, governShell, governedTick, installGovernor, setDimensionNatures, BASELINE, GOVERN } from "./governor.js";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
setDimensionNatures(J("./five_dimensions.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
let s = 11; const rnd = k => { s = (s + 0x6D2B79F5) >>> 0; let x = Math.imul(s ^ (s >>> 15), 1 | s); x ^= x + Math.imul(x ^ (x >>> 7), 61 | x); return 1 + (((x ^ (x >>> 14)) >>> 0) % k); };
const D4 = ["Movement", "Evolution", "Being", "Design"];
const S = new LivingSwarm({ seed: 5 });
for (let i = 0; i < 1200; i++) S.add({ gate: rnd(64), line: rnd(6), color: rnd(6), tone: rnd(6), base: rnd(5), dimension: D4[i % 4] }, "item", Math.random(), Math.random());

console.log("1 — qualities come from the address");
const a = { gate: 17, line: 3, color: 2, tone: 5, base: 3 };
ok("the same address always gives the same qualities", JSON.stringify(qualities(a)) === JSON.stringify(qualities({ ...a })));
ok("change only the colour and the faces change", JSON.stringify(qualities(a).faces) !== JSON.stringify(qualities({ ...a, color: 6 }).faces));
ok("change only the base and the leading corner changes (base 3 Being, base 4 Design)", qualities(a).lead === "Being" && qualities({ ...a, base: 4 }).lead === "Design");
ok("tone lands only on a self face (2 or 5): tones only inside you", [1, 2, 3, 4, 5, 6].every(t => { const f = qualities({ ...a, tone: t }).faces, g = qualities({ ...a, tone: null }).faces;
  return [1, 3, 4, 6].every(x => f[x] === g[x]) && f[2] + f[5] === g[2] + g[5] + 1; }));
const distinct = new Set(S.units.map(u => JSON.stringify(qualities(u.address)))).size;
ok(`${S.units.length} units with different addresses carry ${distinct} different sets of qualities`, distinct > 0.6 * S.units.length);
const src = readFileSync(new URL("./governor.js", import.meta.url), "utf8").replace(/^\s*\/\/.*$/gm, "");
ok("governor.js holds no per-gate or per-address table and names no gate", !/(\d+\s*,\s*){20,}/.test(src) && !/gate\s*===\s*\d/.test(src));
console.log(`     the line between the sides, worked out over all 82,944 gate/line/colour/tone addresses: ${BASELINE.toFixed(4)}`);

console.log("2 — kind first: human vector or building vector");
const q = u => qualities(u.address);
const person = S.units.filter(u => q(u).lead === "Being" && q(u).inside > BASELINE), builder = S.units.filter(u => q(u).lead === "Design" && q(u).inside < BASELINE);
const Tp = tile(person, { dimension: "Being" }), Tb = tile(builder, { dimension: "Design" }), Sp = seat(Tp), Sb = seat(Tb);
const Gp = governShell(Sp, S.units, { T: Tp }), Gb = governShell(Sb, S.units, { T: Tb });
console.log(`     self-leaning Being units tiled into a ${read(Tp).seen}: ${Gp.kind.name} (inwardness ${Gp.kind.inside})`);
console.log(`     joint-leaning Design units tiled into a ${read(Tb).seen}: ${Gb.kind.name} (inwardness ${Gb.kind.inside})`);
ok("the self-leaning Being formation is a human vector: The Body", Gp.kind.label === "human" && Gp.kind.nature === "The Body");
ok("the joint-leaning Design formation is a building vector: Structure", Gb.kind.label === "building" && Gb.kind.nature === "Structure");
const cosv = (x, y) => { let d = 0, m = 0, n = 0; for (let i = 0; i < x.length; i++) { d += x[i] * y[i]; m += x[i] ** 2; n += y[i] ** 2; } return d / Math.sqrt(m * n); };
const c = cosv(Gp.kind.vector, Gb.kind.vector);
ok(`their kind vectors are far apart (cosine ${c.toFixed(3)})`, c < 0.5);
const Tm = tile(S.units, { dimension: "Being" }), Gm = governShell(seat(Tm), S.units, { T: Tm });
console.log(`     a Being shell the swarm grows from all its units, unsorted: ${Gm.kind.name} (inwardness ${Gm.kind.inside})`);
const sides = { humanity: 0, universe: 0, between: 0 }; for (const u of S.units) sides[classify([u]).side]++;
ok(`across the swarm one unit at a time, both sides occur (humanity ${sides.humanity}, universe ${sides.universe}, between ${sides.between})`, sides.humanity > 0 && sides.universe > 0);
setDimensionNatures(null); const bare = classify(person.slice(0, 20)); setDimensionNatures(J("./five_dimensions.json"));
ok(`without the table loaded, kinds are still told apart (${bare.name})`, bare.label === "human" && bare.nature === "Body");

console.log("3 — becoming");
const Tpart = tile(builder, { dimension: "Design", cap: 5 }), Gpart = governShell(seat(Tpart), S.units, { T: Tpart });
console.log(`     building, part grown (${Tpart.faces.length} agents): ${Gpart.becoming.now} (stage ${Gpart.becoming.stage}); closed (${Tb.faces.length}): ${Gb.becoming.now}, toward ${Gb.becoming.toward}`);
ok("a closed building has come all the way along its chain: Structure ... Art", Gb.becoming.now === "Art" && Gb.becoming.chain.join() === "Structure,Progress,Smell,Life,Art");
ok("a part-grown one is earlier on the same chain", Gpart.becoming.stage < Gb.becoming.stage && Gpart.becoming.chain[0] === "Structure");

console.log("4 — parts and the whole");
ok("in a closed shell every agent is core (all four ports joined inside it)", Gp.core === Tp.faces.length && Gp.edge === 0);
ok(`in a part-grown shell the open ones are edge (${Gpart.core} core, ${Gpart.edge} edge)`, Gpart.edge > 0);
ok(`the voice is one of the members (agent ${Gp.voice?.agent}), and every member leans inner or outer`, Sp.agents.some(g => g.id === Gp.voice?.agent) && Gp.parts.every(p => p.lean === "inner" || p.lean === "outer"));

console.log("5 — governed by kind");
console.log(`     human: ports ${Gp.rates.ports}, coupling to its own unseen side ${Gp.rates.coupling}  |  building: ports ${Gb.rates.ports}, coupling ${Gb.rates.coupling}`);
ok("the human vector keeps more to itself and its shadow; the building carries more through its joints", Gp.rates.coupling > Gb.rates.coupling && Gp.rates.ports < Gb.rates.ports);
const Dd = twoSides(S.units, { dimension: "Being" }), t = governedTick(Dd, S.units);
ok(`both sides of a seen/unseen pair are governed by their own kinds (seen ${t.seen.kind.name}, unseen ${t.shadow.kind.name}), coupled at their mean ${t.coupling}`,
  Math.abs(t.coupling - (t.seen.rates.coupling + t.shadow.rates.coupling) / 2) < 1e-4);

console.log("6 — expression");
const mem = {}, all = Sp.agents.map(g => g.id), run = take => governShell(Sp, S.units, { T: Tp, id: "body", memory: mem, take }).expresses.phase;
const phases = [run(all), run(all), run(all.slice(3)), run(all.slice(1)), run(all)];
console.log(`     whole, whole again, three lost, two back, all back: ${phases.join(" -> ")}`);
ok("forming -> holding -> breaking -> regenerating -> holding", phases.join() === "forming,holding,breaking,regenerating,holding");
ok(`its mode comes from its pooled lines: ${Gp.expresses.mode} (out loud: ${Gp.expresses.outLoud})`, ["semantic", "sound", "picture", "video"].includes(Gp.expresses.mode) && Gp.expresses.outLoud === ["semantic", "sound"].includes(Gp.expresses.mode));

console.log("7 — inside morphogenesis");
installGovernor(AFTER_LEARN);
const swarm = seed => { const L = new LivingSwarm({ seed });
  for (let i = 0; i < 48; i++) L.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D4[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  const O = new OrganismSwarm(L); for (let k = 0; k < 5; k++) O.step(); return O; };
const asserts = (name, n, f) => { const rows = []; for (let k = 0; k < 2 ** n; k++) { const x = Array.from({ length: n }, (_, i) => (k >> (n - 1 - i)) & 1); rows.push(`assert(${name}(${x.join(",")}) === ${f(...x)});`); }
  return [{ path: "t.js", text: `import { ${name} } from './g.js';\n${rows.join("\n")}\n` }]; };
const O = swarm(3), r = enter(O, appHost(asserts("onlyBoth", 2, (x, y) => x & y))), st = r.steps.filter(x => x.step === "govern").at(-1);
const arcadiaHere = AFTER_LEARN.some(h => h.name === "arcadia");
console.log(`     AND built: ${r.ok}; governed as ${st?.kind}, becoming ${st?.becoming}, ${st?.phase}, ${st?.mode}; Arcadia ${arcadiaHere ? "on" : "not installed"}`);
ok("a formation the swarm builds is governed as it forms", r.ok && st && O.lastGovernance?.kind?.name === st.kind);
{ const mem = O.S.units.filter(u => u.becoming?.formation != null), g = O.lastGovernance;
  ok("each unit in the formation knows what it is becoming and how it expresses it (v64m)", mem.length === g.parts.length && mem.every(u => u.becoming.kind === g.kind.name && u.becoming.now === g.becoming.now && u.becoming.phase === g.expresses.phase && ["core", "edge"].includes(u.becoming.sits))
    && mem.filter(u => u.becoming.voice).length === 1); }
GOVERN.on = false; const O2 = swarm(3), r2 = enter(O2, appHost(asserts("onlyBoth", 2, (x, y) => x & y))); GOVERN.on = true;
ok("GOVERN.on = false: no governing step, and AND still built", r2.ok && !r2.steps.some(x => x.step === "govern"));
const arc = readFileSync(new URL("./arcadia.js", import.meta.url), "utf8"), mg = readFileSync(new URL("./morphogenesis.js", import.meta.url), "utf8");
ok("the engine does not depend on Arcadia: governor.js does not import arcadia.js, nor arcadia.js governor.js, nor morphogenesis either",
  !/from\s+["']\.\/arcadia\.js["']/.test(src) && !/governor\.js/.test(arc) && !/governor\.js|arcadia\.js["']/.test(mg));

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
