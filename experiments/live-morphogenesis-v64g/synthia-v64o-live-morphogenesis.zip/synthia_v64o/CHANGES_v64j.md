# v64j (Nov 26) — the person asks the page

Celestial sent a third doc and asked to put it in the app ("Can we put it in the app somewhere"). It lives in the morph page's
own loop. Nothing from v64i was changed or deleted except morph.html's inline script, which moved to morph_app.js (same code,
plus the question branch) so one person's own single-file page can run the very same code.

New
- ask.js        a question typed into the page's one line is read for its dimension (Space who, Movement where, Evolution
                what, Being when, Design why; "how" = expression), answered from that dimension's own chart, from gate cores
                read out of the system's own data, written by a frame per question word; "This fits" / "Not this" teach the
                person's experience brain (a preference table, +/-0.1, kept on the person, never on the mesh).
- morph_app.js  the morph page's script (was inline in morph.html), with the question branch and "Keep my page".
- mint.js       one person's page as one HTML file: modules and graph inside an import map, their addresses and brain inside.
                No birth date, time or place in the file. A minted page can write itself out again with what it learned.
- make_page.mjs makes that file from birth data (node make_page.mjs --date ... --time ... --zone ... --id ...).
- test_ask.mjs  26 checks, with and without Arcadia; run_all.sh runs it.

Not built (not asked): the doc's StellarNet network (purity first), its "+1 open channel", resonance packets, three-body pings,
64 creative ports. Rule O in lexicon.js is unchanged; ask.js treats a lens that doesn't fit as a lower score instead of a halt.
Not yet checked in a real browser (no browser is opened from a shell here).
