// test_cross.mjs — body pairs steer movement (v64m). Run plain and: node run_with_arcadia.mjs test_cross.mjs
//   1 the pairs (glued from the research build) agree with the rule book   2 the cross: fixed pair, relative axes
//   3 each dimension's mark   4 the OPP carries the cross   5 switch off = unchanged   6 switch on = movers go along their arm   7 purity
import { readFileSync, existsSync } from "node:fs";
import { LivingSwarm, SETTINGS } from "./living.js"; import { PAIR, crossOf, steerByCross, DIMENSION_MARK, oppOf } from "./opp.js"; import { BODIES } from "./address.js";
import { baseline, differences } from "./regression.mjs";
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const DIMS = ["Movement", "Evolution", "Being", "Design"], R = JSON.parse(readFileSync(new URL("./bhantugh_rules.json", import.meta.url)));
const addr = i => ({ planetary: BODIES[i % 13], gate: 1 + (i * 7) % 64, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: DIMS[i % 4], degree: (i * 37) % 360, house: 1 + (i * 5) % 12 });
const swarm = (n, seed = 3) => { const L = new LivingSwarm({ seed }); for (let i = 0; i < n; i++) L.add(addr(i), "mover", 0.2 + (i % 10) * 0.06, 0.2 + Math.floor(i / 10) * 0.1); return L; };
const U = (planetary, dimension = "Design", side) => ({ address: { planetary, dimension, gate: 10, line: 3, side } });

console.log("1 — the pairs");
const flat = s => s.replace(/\s+/g, "");
ok("every pair in the rule book (bodyPairs) is a pair in the table, both ways", R.bodyPairs.pairs.every(([a, b]) => PAIR[flat(a)] === flat(b) && PAIR[flat(b)] === flat(a)));
ok("the table has nothing the rule book doesn't: 6 pairs, Pluto unpaired", Object.values(PAIR).filter(Boolean).length === 12 && PAIR.Pluto === null && R.bodyPairs.unpaired.join() === "Pluto");
ok("every body the address uses is in the table", BODIES.every(b => b in PAIR));

console.log("2 — the cross: fixed pair, relative axes");
const up = crossOf(U("Sun"), Math.PI / 2), side = crossOf(U("Sun"), 0);
ok("facing up, the unit's own body is the vertical arm and its partner runs across", up.vertical === "Sun" && up.across === "Earth");
ok("facing sideways, the same pair swaps arms (which is upright depends on the viewer)", side.vertical === "Earth" && side.across === "Sun");
ok("names written with a space (\"North Node\") find their partner", crossOf(U("North Node"), 1.5).partner === "SouthNode");
ok("Pluto has a cross with one arm; no planet, no cross", crossOf(U("Pluto"), 0).across === null && crossOf(U("Pluto"), 0).vertical === "Pluto" && crossOf(U(undefined), 0) === null);
ok("a unit with a side carries the self note (Design × Personality)", /self/.test(crossOf(U("Sun", "Design", "Design"), 0).self));

console.log("3 — each dimension's mark (Movement upward, Being across; the other three not described)");
ok("the marks are only the two Celestial named", DIMENSION_MARK.Movement === "vertical" && DIMENSION_MARK.Being === "across" && DIMENSION_MARK.Design === null && DIMENSION_MARK.Evolution === null && DIMENSION_MARK.Space === null);
const m = steerByCross(U("Sun", "Movement"), 0.003, 0.004), b = steerByCross(U("Sun", "Being"), 0.003, -0.004);
ok("a Movement unit's diagonal step goes up its vertical arm, same length", m.arm === "vertical" && m.dx === 0 && Math.abs(m.dy - 0.005) < 1e-12);
ok("a Being unit's step goes across, same length, even when it was heading mostly down", b.arm === "across" && b.dy === 0 && Math.abs(b.dx - 0.005) < 1e-12);
const d1 = steerByCross(U("Venus", "Design"), 0.001, 0.004), d2 = steerByCross(U("Venus", "Design"), -0.004, 0.001);
ok("a dimension with no mark moves on the arm its own body is on for the way it's going", d1.arm === "vertical" && d2.arm === "across" && d2.dx < 0);
ok("Pluto under Being has no across arm, so it keeps to its one arm", steerByCross(U("Pluto", "Being"), 0.004, 0.001).arm === "vertical");
ok("no step or no planet: nothing to steer", steerByCross(U("Sun"), 0, 0) === null && steerByCross(U(undefined), 0.01, 0) === null);

console.log("4 — the OPP carries the cross");
{ const L = swarm(12); L.step(); L.step(); const o = oppOf(L.units[0], L.units);
  ok("oppOf puts the cross in position", o.position.cross && o.position.cross.body === "Sun" && o.position.cross.partner === "Earth"); }

console.log("5 — switch off: the swarm is v64l's, step for step");
const v64l = baseline("v64l");
if (v64l) { const K = await import(v64l); const a = swarm(40, 9), c = new K.LivingSwarm({ seed: 9 });
  for (let i = 0; i < 40; i++) c.add(addr(i), "mover", 0.2 + (i % 10) * 0.06, 0.2 + Math.floor(i / 10) * 0.1);
  for (let k = 0; k < 25; k++) { a.step(); c.step(); }
  const diff = differences(a, c); if (diff.length) console.log("     " + diff.slice(0, 5).join("; "));
  ok("CROSS_STEER off: identical to v64l after 25 steps (positions, health, addresses, bonds, acquired, learned, programs)", SETTINGS.CROSS_STEER === false && !diff.length); }
else ok("v64l baseline present for comparison (regression-baselines/ or SYNTHIA_BASELINES)", false);

console.log("6 — switch on: every free mover goes along one arm of its cross");
{ SETTINGS.CROSS_STEER = true; const L = swarm(40, 9); let moved = 0, aligned = 0, mv = 0, mvUp = 0, be = 0, beAcross = 0, pl = 0, plUp = 0;
  for (let k = 0; k < 25; k++) { const before = L.units.map(u => [u.x, u.y]); L.step();
    L.units.forEach((u, i) => { if (u.broken || u.target) return; const dx = u.x - before[i][0], dy = u.y - before[i][1]; if (Math.hypot(dx, dy) < 1e-12) return;
      moved++; if (Math.abs(dx) < 1e-12 || Math.abs(dy) < 1e-12) aligned++;
      if (u.address.dimension === "Movement") { mv++; if (Math.abs(dx) < 1e-12) mvUp++; } if (u.address.dimension === "Being") { if (u.address.planetary === "Pluto") { pl++; if (Math.abs(dx) < 1e-12) plUp++; } else { be++; if (Math.abs(dy) < 1e-12) beAcross++; } } }); }
  SETTINGS.CROSS_STEER = false;
  console.log(`     ${moved} moves: ${aligned} along an arm; Movement ${mvUp}/${mv} vertical, Being ${beAcross}/${be} across; Being on Pluto ${plUp}/${pl} on its one arm`);
  ok("every move is along one arm (one of its two components is zero)", moved > 0 && aligned === moved);
  ok("Movement units move on the vertical arm, Being units across (Pluto, with one arm, keeps to it)", mv > 0 && mvUp === mv && be > 0 && beAcross === be && pl > 0 && plUp === pl);
  ok("each moving unit records which arm it used", L.units.some(u => u.arm === "vertical") && L.units.some(u => u.arm === "across")); }

console.log("7 — purity");
{ const src = readFileSync(new URL("./opp.js", import.meta.url), "utf8");
  ok("opp.js stays pure (no neural nets, no random draws)", !/tensor|neural|onnx|tfjs|Math\.random/i.test(src)); }

console.log(`${pass} passed, ${fail} failed`); process.exitCode = fail ? 1 : 0;
