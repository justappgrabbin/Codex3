// test_tiling.mjs — tiny triangle agents (bipyramids) tile into the solids (v64h, Nov 26). Run plain and with run_with_arcadia.mjs.
import { readFileSync } from "node:fs"; import { setGateEngineData } from "./gate_engine.js";
import { LivingSwarm } from "./living.js"; import { tile, read, seat, exchange, spaceOf, agentShape, AGENT } from "./tiling.js";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const D = ["Movement", "Evolution", "Being", "Design"];
const S = new LivingSwarm({ seed: 9 }); for (let i = 0; i < 64; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: D[i % 4] }, "item", Math.random(), Math.random());

console.log("1 — one agent: a triangular bipyramid");
const A = agentShape();
ok(`6 triangular faces, 5 corners, 9 edges`, A.faces === 6 && A.corners === 5 && A.edges === 9);
ok("faces over the same tile edge are mirrors: 1-4, 2-5, 3-6", A.mirror[1] === 4 && A.mirror[2] === 5 && A.mirror[3] === 6);
ok("two faces face only itself (2 and 5, a mirror pair); four are ports (1, 3, 4, 6)", AGENT.self.join() === "2,5" && AGENT.ports.join() === "1,3,4,6");
ok("Space is the corner where the four ports meet, touching neither self face", A.touches.Space.join() === "1,3,4,6");
ok("every face touches three others (its two in the same half and its mirror)", Object.values(A.neighbours).every(n => n.length === 3));
console.log("     corners:", JSON.stringify(A.touches));

console.log("2 — the shells grow out of the tiling rule (no solid is stored)");
const want = { Space: ["tetrahedron", 4], Evolution: ["octahedron", 8], Design: ["cube", 8], Being: ["icosahedron", 20], Movement: ["dodecahedron", 20] };
const shells = {};
for (const [dim, [name, n]] of Object.entries(want)) { const T = tile(S.units, { dimension: dim }), r = read(T); shells[dim] = T;
  console.log(`     ${dim.padEnd(9)} k=${T.k}: ${r.triangles} agents, ${r.corners} corners, ${r.edges} edges; as triangles ${r.asTriangles}, as ${r.fans.polygon}s ${r.asFans}; ${dim} sees a ${r.seen}`);
  ok(`${dim}: closes into ${n} agents and is seen as a ${name}`, r.closed && r.regular && r.triangles === n && r.euler === 2 && r.seen === name); }
ok("Movement and Being are one tiling seen two ways (icosahedron's 12 pentagons = dodecahedron's 12 faces)", read(shells.Movement).fans.count === 12 && read(shells.Being).corners === 12);
ok("each agent is carried by a different unit of the swarm", Object.values(shells).every(T => new Set(T.faces.map(f => f.unit?.id)).size === T.faces.length));
const sheet = read(tile(S.units, { k: 6, cap: 40 }));
ok(`six around a corner never closes: an open sheet of hexagons (${sheet.triangles} agents)`, !sheet.closed && sheet.asFans === "open sheet of hexagons");
const src = readFileSync(new URL("./tiling.js", import.meta.url), "utf8").replace(/^\s*\/\/.*$/gm, "");
ok("tiling.js holds no vertex list, coordinates or face table of any solid", !/\[\s*-?\d+\s*,\s*-?\d+\s*,\s*-?\d+\s*\]\s*,\s*\[\s*-?\d+/.test(src) && !/phi|1\.618|sqrt\(5\)/i.test(src));

console.log("3 — seams and ports");
for (const dim of ["Space", "Design", "Being"]) { const P = seat(shells[dim]);
  ok(`${dim}: every agent has a partner across its seam (${P.pairs.length} pairs, ${P.pairs.length} quads of two triangles) and four joined ports`,
    P.agents.every(g => g.seam != null && P.agents[g.seam].seam === g.id) && P.agents.every(g => Object.keys(g.links).sort().join() === "1,3,4,6"));
  ok(`${dim}: ports join symmetrically, inner to inner and outer to outer`, P.agents.every(g => Object.entries(g.links).every(([l, k]) => {
    const back = P.agents[k.agent].links[k.face]; return back && back.agent === g.id && back.face === +l && ((+l <= 3) === (k.face <= 3)); }))); }

console.log("4 — self faces carry the agent's own state; ports carry exchange");
const P = seat(shells.Being); let reads = [];
for (let t = 0; t < 3; t++) reads.push(...exchange(P));
ok("no agent ever reads another agent's self face (2 or 5)", reads.length > 0 && reads.every(r => !AGENT.self.includes(r.face)));
const Q = seat(shells.Being); Q.agents.forEach(g => { for (const l of [1, 2, 3, 4, 5, 6]) g.value[l] = 0.5; });
const a = Q.agents[0], b = Q.agents[a.links[1].agent]; a.value[2] = 1;   // a nudge on agent 0's own self face
const b0 = JSON.stringify(b.value); exchange(Q); const b1 = JSON.stringify(b.value); exchange(Q); const b2 = JSON.stringify(b.value);
ok("a change on an agent's self face reaches no neighbour in the first tick", b1 === b0);
ok("it reaches the neighbour only after passing through the agent's own port face (second tick)", b2 !== b1);
const lone = seat(tile(S.units.slice(0, 1), { k: 5, cap: 1 })).agents[0]; lone.value = { 1: 0, 2: 1, 3: 0, 4: 0, 5: 1, 6: 0 };
const L = { agents: [lone] }, sum = g => Object.values(g.value).reduce((x, y) => x + y, 0), before = sum(lone); exchange(L); const t1 = { ...lone.value };
for (let t = 0; t < 3; t++) exchange(L);
ok(`an agent alone carries its state forward: nothing leaks (total ${before} -> ${sum(lone).toFixed(6)}), and after a tick its self faces still hold the most`,
  Math.abs(sum(lone) - before) < 1e-9 && Object.keys(lone.links).length === 0 && t1[2] > t1[1] && t1[5] > t1[6]);
ok("Space at an agent is the meeting of its four port faces", Math.abs(spaceOf(a) - (a.value[1] + a.value[3] + a.value[4] + a.value[6]) / 4) < 1e-12);
ok("every bond carries NAND of the two faces' bits", P.agents.every(g => Object.entries(g.bonds ?? {}).every(([, v]) => v === 0 || v === 1)) && P.agents.some(g => g.bonds));

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
