# v64f: recursive foundation (Nov 26, 2026)

Built on synthia_slim_v64.zip. The original zip is kept unchanged next to this build. Nothing was removed or renamed.

## Files added
- **recursion.js**: gate-led clusters at any scale, the upward trigger ladder, regulation per formation, the formation's OPP/POP, learning from the climb, and extract/adopt of what the swarm acquired.
- **test_recursion.mjs**: Celestial's verification list, run on the organism (OrganismSwarm on LivingSwarm units, through morphogenesis.enter).
- **test_recursion.out.txt**: the full output of the last run.
- **CHANGES_v64f.md**: this file.

## Files changed (additions only)
- **morphogenesis.js**: one import, plus one block after a formation is learned. The block builds the cluster record, regulates it, learns from it and reports a `cluster` step. If the formation is one learned formation used whole, the block treats it as that cluster again instead of wrapping a new one.
- **reproduce.js**: planChild takes an optional `acquired` argument and puts it in the genome, so a child can adopt what the parent learned.

## Reused unchanged
- **resonance_rules.js**: contact, baseReach, colourRelation, lineHarmony, lineFacing, canTouch. The ladder checks canTouch when it loads.
- **gate_engine.js**: gateFunction and lineExpression are the five engines (gate = function; line = expression; colour, tone and base sway it). They are read for each formation's leader.
- **opp.js**: oppOf is each member's spatial OPP. popOf is the spatial POP over a formation's members.
- **function_side.js / klein_local.js**: pooled lines are used to find the cluster's core, tool and kind. Lines are read in the formation's frame.

## How it works
**Micro.** A formation is a cluster. The unit that carries the output step is its leading gate (my reading of "the gate whose function governs the operation"). The other carriers are its supporting gates.

**Macro.** A learned formation used as one step of a new formation is a sub-cluster and keeps its own leader. The new formation has its own leader and its scale is one higher. It is learned in turn and can join a further composition.

**Ladder.** This follows the rule book ("Gate > Line > Color > Tone > Base", neighbours only) and the climb Celestial posted on Nov 26. Each unit sits on its base. A trigger climbs base → tone → color → line → gate, one rung at a time, while it resonates with the formation's leader. It lands where resonance runs out, and reaching the gate is a full cascade. Resonance at each rung uses only the existing rules:
- base: baseReach gives "resonance"
- tone: same tone
- colour: same colour
- line: same line

Transference (colour three apart) and line harmony (1-4, 2-5, 3-6) are recorded but do not pass. This is a choice of mine; `LADDER.transferencePasses` and `LADDER.harmonyPasses` change it. `LADDER.bridges` is empty: no rung can be skipped until Celestial says a bridge exists.

**Recursion.** Each formation's members climb against that formation's own leader (`REGULATION.relativeTo = "each-formation"`; the setting "outermost" is the other choice). A trigger that reaches its leader's gate carries on up: that leader climbs against the leader one scale above. At the outermost scale, the leader climbs against the host if the host gives an address. So a trigger lands at a rung and at a scale.

**Downward.** The outer formation's frame (its leader's base, which gives a dimension) is the frame in which members' lines are read. Nothing else is applied downward.

**OPP/POP.** A member's OPP is v64's spatial OPP plus where it stands toward its leader: role, step, scale, frame, facing, the rung where it landed, the rungs it climbed, and contact()'s crossing level. A formation's POP is v64's spatial POP over its members, plus the share of members landing at each rung, at each scale, by role, and by how many scales up their trigger carried.

**Learning.** A member's craft for the step it carried grows by how far its trigger climbed (rungs plus scales). Addresses are never written; the test checks this.

**Extraction and persistence.** `extractSwarm` returns learned formations as data, cluster records and craft, as plain JSON. `adoptSwarm` loads them into another swarm.

## Test results (node test_recursion.mjs): 24 passed, 0 failed
- **0. Ladder:** full cascade; stops at base, tone, colour (blind spot) and line (harmony); no skipping.
- **1. Cluster formation:** AND built from NAND. It is a gate-led cluster (leader gate 7, support gate 3), and its engines come from the gate engine.
- **2. Composition:** all3 is built from the learned AND used twice. It is a scale-2 cluster with its own leader (gate 1). The regulation switch moves the inner members' reference from the AND leader to the all3 leader, and no address changes.
- **3. Reuse:** a new host needing AND recalls it. It took 84 tries the first time and 1 now.
- **4. Adaptation:** the same function name with changed cases. AND no longer fits, so a new formation (NAND) is built, and AND is kept.
- **5. Persistence:** the swarm is extracted to JSON (about 9.5 KB). A fresh swarm with another seed adopts it and meets all3 by recall.
- **6. Reproduction:** planChild carries `acquired` in the genome. A child swarm adopts it and meets AND by recall.
- **7. Extraction:** every host passes its own check with the swarm gone, and no unit still carries a role.
- **8. Swarm against host:** a host given an address is climbed against by the outermost leader (landed at tone in the test).

## Regression
The slim zip has no tests, so the v61 tests were copied in to check these changes.
- test_morphogenesis: 11/11
- test_software: 15/15
- test_finish: 8/8
- test_resonance_rules: 12/12
- test_organism: 14/15. The same failure ("no trained recogniser is attached") happens on the untouched v64. It is not caused by these changes.

## What doesn't work yet, or isn't built
- **Not run in a browser.** It imports only files already in slim, and in the browser it reads `u.opp` instead of recomputing it, but it hasn't been run in the live page. The live page doesn't show cluster or ladder readings yet.
- **"Identify gates" isn't driven by the gate engine.** Units still choose operations by line fingerprint, dimension and craft (unitbuild.js). The gate engine's verbs (create, store, route…) are read and reported but don't steer construction; that would be a new rule.
- **Few triggers cascade across scales in the test swarm.** With 5 bases and 6 tones, colours and lines, a full climb between two different units is rare, and the AND sub-cluster's leader lands at base against the all3 leader. That is the ladder working as specified, not a fault, but it means "scalesUp" is mostly 0.
- **The ladder has only one downward effect.** Only the frame goes down; no other effect is defined.
- **Reproduction is the plan only.** planChild in Node, then adoption into a new swarm. The browser child (child.js) doesn't seed from `genome.acquired` yet.
- **The Design-side base pyramid is still provisional.** This is noted in resonance_rules.js. Units without `side` use Personality.
- **The klein_local.js rename question is still open.** The v64 slim doesn't have the Nov 24 cleanup.

## v64g — two-place test (Celestial's list, item 1, Nov 26)
New, added alongside, nothing removed: places.js (two places), place.js (the conditions the swarm works under in a place), test_two_places.mjs (14/14). test_recursion still 24/24.
- A place shows only there() / can() / health() / apply(). The half-broken app: its files, what each exports and imports/calls, one operation (put a definition in a file), health = share of its test files that run clean. The small world: its edges, grid headings, mark modes and palette colours, one operation (a behaviour), health = its own check after a run.
- place.js names no place, task or answer (checked by the test). Items sit in the swarm's space by a hash of their id; a unit perceives items within its reach, added to its OPP as opp.place. POP over the place = share seen, blind items, gaps (a reference nothing seen provides), health. Blind items pull their nearest unit toward them until all are seen (max 6 rounds).
- Discovery reads the POP: a gap first, else health below full, else rest. Aim = now + 0.5 x (1 - now) (my working value). Building runs through the swarm's own enter() lifecycle on a host the swarm assembles.
What it showed:
- App: health 0.5 -> found gap "both" in gate.js (2 bits) itself -> built nand,nand,define -> health 1, still whole with the swarm gone, rests on return.
- World: health 0 -> no gap -> by health -> one behaviour (fall from top, leave bright on contact) -> health 1.
- Thin swarm (6 units): one item blind at start, one round of moving, all seen, gap "either" found and built.
What doesn't hold yet (honest):
- In the world, "finding what's missing" is trying what can be done until health rises. There's no perception of a lack there, only search guided by health.
- Orientation was barely needed: 0 rounds for the 48-unit swarm; for the thin swarm the blind item wasn't the one holding the gap.
- The gap probe (every row of 0/1 inputs) only works when the call's arguments are literal bits; other argument kinds stop with a stated failure.
- Moving toward blind items changes unit positions (x, y), never addresses. Not run in a browser.

## v64h — lack frame, then Arcadia (Celestial's list, item 2, Nov 26)

Order picked (mine): the lack frame first, because the two-place test showed the world side was the weak spot; Arcadia second.

### Lack frame (place.js, LACK.on)
Taken from the idea in the phone file hypothesisLife (read only, not run). A place's "whole" is everything it shows that one of
its operations could take in and that reports whether it is present. When health is below 1 and some, not all, of that whole is
absent, the place's need is "lack": absent things are offered to the units first and nothing is ruled out. Blind is not absent.
After the build, a lack-hypothesis step records whether the change used any absent thing.
- test_lack.mjs 7/7. Dusk world: 14 of 18 absent, lack chosen, hypothesis supported (4 absent things used), health 1.
  Empty cold world: everything absent, so it falls back to low-health and says absence can't narrow anything.
- 10 random item orders, fresh swarm each: mean 68.9 tries with lack vs 86.1 without; lack was faster in 8, slower in 2; all fixed.
- Caveat: in the dusk world the fix uses only absent things, by my construction; where a fix needs present things too the gain shrinks.

### Arcadia (arcadia.js) — an optional layer, never a dependency
Celestial asked what happens when Arcadia is not allowed. morphogenesis.js does not import arcadia.js; it keeps a list of
after-learn layers (AFTER_LEARN) and Arcadia joins it only through installArcadia(AFTER_LEARN). Plain `node test_x.mjs` runs
without it; `node run_with_arcadia.mjs test_x.mjs` runs with it. With arcadia.js deleted outright, the tests still pass.
Celestial's idea: classify what a formation is being, how its parts sit with the whole, and how it expresses. My build:
- Being: a vector per formation from what the swarm already reads off it (gate ops of its members, their dimensions, where each
  trigger landed on the ladder, scale, coherence). Nearest known kind by cosine similarity (same at >= 0.9, my value); otherwise a
  new kind, named by rule (leading op · leading dimension · leading rung, numbered if taken). No list of kinds anywhere.
- Parts: each member against the whole, core or edge; sub-formations are inner wholes.
- Expression: forming, holding, breaking (coherence down by more than 0.2), regenerating (whole again after breaking).
- Feedback (the mesh by kind): what a formation just taught its units is shared, at 0.25 of the gain, with other units that
  carry the same kind. Addresses are never written.
- extractArcadia / adoptArcadia carry the kinds to another swarm.
- test_arcadia.mjs 15/15. Seven hosts gave four kinds: AND, all3 and AND-again in one family; OR and NOR in another; NAND and XOR
  each their own. A fresh swarm that took up the kinds met AND as a known kind (cosine 0.995). Switch off = no change to enter().
- Weak spots: only one craft share happened in this run (carriers mostly overlap), and breaking/regenerating were only shown by
  the rule on a weakened copy, not by a run that actually broke. OR sat at 0.899, just under "same", so the threshold matters.

### arcadia.ts (Drive, research-only) — what it is
A tRPC backend router that proxies a remote server and stores agents in MySQL; it is not a coordinator. Its centre tables disagree
with v64's address.js (e.g. G lists 49 and lacks 7; Sacral lists 53, 60 and lacks 14, 27, 59; Root lists 61 and lacks 39, 52, 53,
58), it calls a centre defined if any one gate is active, passes channels where centres are expected, and gets the Reflector rule
wrong. Nothing was taken from it.

### Shared learning mesh (mesh.js)
Celestial: "if the research version gets on the mesh, then the other ones can learn from it and not do exactly what it does, but
learn exactly how it works." Built on recursion.extractSwarm/adoptSwarm. On the mesh: each verified formation as its graph of
operations, its typed inputs/output, the operations it needs, and craft pooled per gate. Kept off: unit ids, hosts, files, test
cases, materials, cluster records. A reader takes a method only if its builder knows every operation (same id and version);
otherwise the method is skipped and named.
- Checked against the code: PrimitiveSwarm does promote a verified chain to a reusable primitive and keeps feedback, but only
  inside one swarm; nothing shared across swarms before this.
- test_mesh.mjs 12/12, both with and without Arcadia: a different swarm (other units, gates, seed) on another file solved all3 in
  15 tries from the mesh vs 7,044 learning cold; XOR 14 vs 1,040. A builder missing NAND skips AND and, through it, all3, by name.

### The page is the swarm (pagemorph.js, morph.html)
Checked first: living.html is a hand-built page (fixed panels); nothing formed the page from the swarm's state. pagemorph.js:
- Stated need (the person's words, BM25 against each gate's own text; gematria if no vocabulary) and noticed need (the gates of
  their own chart; only addresses enter, never birth data) are peers.
- Gate -> form by function_side's rule (hexagram line 1 function/picture, line 6 still/moving): semantic, sound, picture, video.
  Regions are carried by the swarm's own units (sentences, sound voices, colour/shape, movement) and placed where those units sit.
- When stated and noticed lead to different forms, the page becomes yes/no questions, one per dimension whose frame shows the gap:
  Space who (who they are now), Movement where, Evolution what (line 1), Being when (line 6), Design why. The answers settle the
  form; Space's answer joins their live state. Switches: PAGE.onDisagree "ask" | "stated" | "noticed".
- Over use the noticed side leans on what they kept choosing, so the questions stop.
- test_pagemorph.mjs 22/22 with and without Arcadia: "teach me the details of the formula" -> a reading page; "explore a world and
  wander through it" -> a moving page; a 1990 test chart -> picture. Disagreement asked 4 questions; all yes -> what they said,
  all no -> what the chart leans to. Asked once, then went straight to the page. Works with no swarm, every unit broken, no
  vocabulary, no chart, no Arcadia/mesh/world.
- Readings to know: "I want to learn how to understand and study ideas" lands on picture (gate 11's hexagram is picture-faced);
  "show me a picture of my design" lands on video. That's the rule, not a bug, but it's the place to check.
- morph.html: a page with one line to tell it what to become and an optional birth line; everything under it comes from
  pagemorph. Not opened in a browser here.

### Evolution on Fagan-Bradley (charts.js)
AYANAMSA.use = "fagan" (default) | "lahiri". Fagan-Bradley anchored at 24.042044 deg on 1950-01-01 (24.7405 deg at J2000), same
50.29"/yr rate; about 0.8875 deg (53') past Lahiri. Over 200 random births 1950-2010: Evolution gate changed for 16.6% of
activations, line 95.3%, colour 32.4%, tone 100%, base 40.9%. Being, Movement and Design unchanged. test_fagan.mjs 7/7.

### Agents as tiny solids that tile into the shapes (tiling.js)
Celestial: agents are "tiny, tiny triangles that make up the other spaces"; "Who said it was flat?"; Movement is a dodecahedron,
Being an icosahedron; "one swarm agent has six faces, two of them only face themselves". My build:
- An agent is a triangular bipyramid: six triangular faces = the six lines (1-2-3 inner half, 4-5-6 outer), mirrors 1-4, 2-5, 3-6.
  Five corners = five dimensions (my picks): Space where the four port faces meet, Movement and Design at the two tips,
  Being and Evolution on the seam. Lines 2 and 5 face only the agent itself (my pick); 1, 3, 4, 6 are ports.
- Shells grow by one rule: serve the open corner with the most agents around it; close it when it has k-1. The only thing a
  dimension sets is k: 3 gives a tetrahedron, 4 an octahedron, 5 an icosahedron; 6 never closes (a flat sheet of hexagons).
  The agents around one corner make a polygon, and read by those polygons the same shell is the dual: the icosahedron's 12
  pentagons are the dodecahedron's 12 faces, the octahedron's 6 squares the cube's. No solid is stored anywhere.
- Dimension -> shape: Being icosahedron, Movement dodecahedron (Celestial's words: one tiling, seen two ways). My picks, to check:
  Evolution octahedron, Design cube, Space tetrahedron.
- Agents pair up across their self-facing seam (two tiny triangles make a quad); ports join inner to inner, outer to outer; every
  bond keeps NAND of its two bits. Which unit takes a new place: the one that bonds best by kernel/bond.js's harmonics.
- test_tiling.mjs 26/26: all five shells close as named, each agent on a different unit, no agent ever reads another's self face,
  a change on a self face reaches a neighbour only after passing through the agent's own port.

### The side you see and the side you don't (dual.js)
Celestial: "the function side is that side that you don't see." The picture swarm is a shell for the leading dimension; the
function swarm is its shadow on the paired dimension (Being-Movement, Evolution-Design, Space-Space). Each seen agent has one
shadow partner in the same place; they share no edge or port. They are coupled only through the self faces (2 and 5): the
faces that "only face themselves" face their own shadow. COUPLING.rate 0.5 (mine); 0 cuts the shadow off.
- test_dual.mjs 11/11: change a function agent and only its picture partner's look changes in that tick; and the other way.

### Candidate, not wired: the five dimensions' macro/micro pairs (from Celestial's screenshots, Nov 26)
Read off the table on p.115 of the text Celestial sent (Macrocosmic / Microcosmic / Keynote):
Movement - Individuality - I Define; Evolution - The Mind - I Remember; Being - The Body - I Am; Design - The Ego - I Design;
Space - Personality - I Think. Celestial: "they're not looking at movement you're looking at individuality". Also in the text
(relayed, not yet read by me in full): Personality Crystal = Space + Evolution, Design Crystal = Being + Design, Monopole =
Movement alone; "Space is a condition resulting from the interaction of the four dimensional fields" (fits Space as the
self-dual tetrahedron and the port corner). If Celestial confirms the crystals are what pairs the sides, dual.js's PAIR would
become Being-Design, Evolution-Space, Movement-itself instead of Being-Movement, Evolution-Design, Space-itself. PAIR is one
table, so the switch is one line; nothing changed yet.

### Not done
consciousness_realm_swarm_world.zip (15.9MB) is over the Drive connector's 10MB download limit, so Swarm World, the cross and
body pairs are still not compared.

### Regression
Without Arcadia: test_recursion 24/24, test_two_places 14/14, test_lack 7/7, test_mesh 12/12, test_pagemorph 22/22,
test_fagan 7/7, test_tiling 26/26, test_dual 11/11. With Arcadia (run_with_arcadia.mjs): the same, plus test_arcadia 16/16. Outputs saved as *.out.txt.

## v64i (Nov 26) — the swarm's own governing engine (governor.js), alongside Arcadia
Celestial said yes to an engine of the swarm's own, not depending on Arcadia, that sorts out what a formed piece is becoming,
how its parts sit with the whole and how it expresses itself; kind comes first: "if it's a human vector or if it's a building
vector". And: "I wanted them to have the different qualities... I didn't know how to express it without like scripting it."
Arcadia is untouched and still optional. Neither imports the other; morphogenesis imports neither (both plug into AFTER_LEARN).
- Qualities from the address only: each of the agent's six faces = its line's bit, +1 on the face the line names, +1 on the face
  the colour names (these touch others), +1 from the tone on a self face (tone 1-3 face 2, 4-6 face 5: "tones only inside
  you"); the base picks the leading corner (canon base table). 1,200 random addresses gave 983 different sets of qualities.
- Kind first: inwardness = share of weight on the two self faces. Measured against the mean over all 82,944 gate/line/colour/tone
  addresses (0.4497, worked out at load, not chosen). Above it = humanity side (a human vector), below = universe side; the
  leading dimension then names it from Celestial's page 115 table (five_dimensions.json): human -> Individuality, The Mind,
  The Body, The Ego, Personality; universe -> Energy, Gravity, Matter, Structure, Form. Universe-side Design (Structure) is
  what I call a building vector; any humanity-side kind is a human vector. Works without the table (names fall back).
- Becoming: the kind's nature chain read as stages (my reading), stage = how far the shell has closed (Structure ... Art).
- Governed by kind: port exchange rate = 1 - inwardness, coupling to its own unseen side = inwardness. Human 0.36 / 0.64,
  building 0.66 / 0.34 in the test. governedTick runs a seen/unseen pair (dual.js) each at its own kind's rates.
- Parts: core (all four ports joined inside) or edge; a voice (closest to the whole); each member leans inner or outer. Empty
  places (no unit standing on them) are counted as empty, not as members.
- Expression: mode from pooled lines (semantic/sound/picture/video; out loud = semantic or sound); phase forming, holding,
  breaking (members lost), regenerating (growing back until whole).
- test_governor.mjs 23/23, with and without Arcadia. Honest limit: the human/building check sorts units by the same inwardness
  rule before tiling them, so it proves the two kinds come out distinct and governed differently, not that a real person's
  chart lands on the human side. An unsorted Being shell grown from all units read human: The Mind.
- Picks to check: line 2 and 5 as the inside faces; tone split 1-3 / 4-6; building = universe-side Design; chain as stages;
  rates straight from inwardness.
