// test_recursion.mjs — Celestial's verification list for the recursive foundation (Nov 26), run on the organism
// (OrganismSwarm on LivingSwarm units, morphogenesis.enter), not a side pipeline:
//   1 cluster formation  2 composition  3 reuse of an emergent function  4 adaptation to changed host conditions
//   5 persistence  6 reproduction  7 extraction   (+ the ladder itself, and the regulation switch)
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js";
import { enter, morphBuilder } from "./morphogenesis.js"; import { appHost } from "./hosts.js"; import { runPlan } from "./unitbuild.js";
import { climb, regulate, REGULATION, LADDER, extractSwarm, adoptSwarm } from "./recursion.js";
import { planChild } from "./reproduce.js"; import { setGateEngineData } from "./gate_engine.js";
import { readFileSync } from "node:fs";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url)));
setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const step = (r, n) => r.steps.filter(s => s.step === n).at(-1), show = r => r.steps.forEach(s => console.log("     ", JSON.stringify(s).slice(0, 260)));
const D = ["Movement", "Evolution", "Being", "Design"];
const swarm = seed => { const S = new LivingSwarm({ seed });
  for (let i = 0; i < 48; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  const O = new OrganismSwarm(S); for (let t = 0; t < 5; t++) O.step(); return O; };
const asserts = (name, n, f) => { const rows = []; for (let k = 0; k < 2 ** n; k++) { const a = Array.from({ length: n }, (_, i) => (k >> (n - 1 - i)) & 1); rows.push(`assert(${name}(${a.join(",")}) === ${f(...a)});`); }
  return [{ path: "t.js", text: `import { ${name} } from './g.js';\n${rows.join("\n")}\n` }]; };

console.log("0 — the ladder (base → tone → color → line → gate, neighbours only, lands where resonance runs out)");
const u = (base, tone, color, line, gate = 1) => ({ gate, line, color, tone, base });
const lead = u(2, 3, 4, 5, 9);
ok("full cascade when every rung resonates", climb(u(2, 3, 4, 5), lead).landed === "gate");
ok("different base: the trigger never leaves the base", climb(u(1, 3, 4, 5), lead).landed === "base");
ok("same base, different tone: lands at tone", climb(u(2, 6, 4, 5), lead).landed === "tone");
const ts = climb(u(2, 3, 1, 5), lead);
ok("colour three apart (transference) is a blind spot and stops the climb at colour", ts.landed === "color" && ts.blindSpot);
ok("line harmony (2 vs 5) is recorded and stops the climb at line", climb(u(2, 3, 4, 2), lead).landed === "line" && climb(u(2, 3, 4, 2), lead).steps.at(-1).kind === "harmony");
ok("no rung is skipped: a match at line alone, with base off, still lands at base", climb(u(1, 1, 1, 5), lead).landed === "base");
ok("no bridges are declared", LADDER.bridges.length === 0);

const O = swarm(3);
console.log("1 — cluster formation (micro: a leading gate coordinates supporting gates for one function)");
const rAnd = enter(O, appHost(asserts("onlyBoth", 2, (a, b) => a & b))); show(rAnd);
const cAnd = step(rAnd, "cluster");
ok(`AND built and learned (${step(rAnd, "act+evaluate").plan.join(" → ")})`, rAnd.ok && !!cAnd);
ok(`it formed a gate-led cluster: leading gate ${cAnd?.leadingGate}, supporting gates ${JSON.stringify(cAnd?.support)}, scale ${cAnd?.scale}`, cAnd && cAnd.leadingGate && cAnd.scale === 1);
const regAnd = O.lastRegulation;
ok("every member climbed against the formation's own leader; the leader cascades", regAnd.members.every(m => m.regulatedBy === regAnd.leadingGate) && regAnd.members.find(m => m.role === "leader").climb.cascade);
ok("the five engines are read from the leader through v64's gate engine", ["gate", "line", "color", "tone", "base"].every(k => regAnd.engines[k]) && !!regAnd.engines.gate.does && !!regAnd.engines.line.mode);
console.log("     engines:", JSON.stringify(regAnd.engines).slice(0, 400));
console.log("     POP:", JSON.stringify(regAnd.pop).slice(0, 400));
const andId = cAnd.id;

console.log("2 — composition (macro: a learned cluster joins a larger formation as one step)");
const rAll = enter(O, appHost(asserts("all3", 3, (a, b, c) => a & b & c))); show(rAll);
const cAll = step(rAll, "cluster"), planAll = step(rAll, "act+evaluate")?.plan ?? [];
ok(`all3 built using the learned AND as a step (${planAll.join(" → ")})`, rAll.ok && planAll.includes(andId));
ok(`it is a scale-${cAll?.scale} cluster with its own leader (gate ${cAll?.leadingGate}) and the AND cluster inside it`, cAll?.scale >= 2 && cAll.subclusters.some(s => s.cluster === andId));
const regAll = O.lastRegulation;
ok("members carry the scale they sit at (both scales present)", new Set(regAll.members.map(m => m.scale)).size >= 2);

console.log("   regulation switch (each-formation vs outermost); unit addresses never written");
const snap = JSON.stringify(O.S.units.map(x => x.address));
const each = regulate(O, O.morphMemory.clusters[cAll.id]);
REGULATION.relativeTo = "outermost"; const outer = regulate(O, O.morphMemory.clusters[cAll.id]); REGULATION.relativeTo = "each-formation";
const innerEach = each.members.filter(m => m.scale < cAll.scale), innerOuter = outer.members.filter(m => m.scale < cAll.scale);
ok(`each-formation: inner members climb against the AND leader (gate ${innerEach[0]?.regulatedBy}); outermost: against the all3 leader (gate ${innerOuter[0]?.regulatedBy})`,
  innerEach.length && innerEach.every(m => m.regulatedBy === O.morphMemory.clusters[andId].leader.gate) && innerOuter.every(m => m.regulatedBy === cAll.leadingGate));
ok("no unit's address changed", JSON.stringify(O.S.units.map(x => x.address)) === snap);

console.log("3 — reuse of an emergent function (a new host needing AND recalls it)");
const execFirst = step(rAnd, "construct").toFirst;
const rAgain = enter(O, appHost(asserts("both", 2, (a, b) => a & b).map(f => ({ ...f, text: f.text.replace(/g\.js/g, "h.js") })))); show(rAgain);
ok(`recalled (${step(rAgain, "construct").recalled}) and cheaper: ${execFirst} tries first time, ${step(rAgain, "construct").toFirst} now`, rAgain.ok && step(rAgain, "construct").recalled && step(rAgain, "construct").toFirst < execFirst);

console.log("4 — adaptation (the same function name, the host's conditions changed)");
const rAdapt = enter(O, appHost(asserts("onlyBoth", 2, (a, b) => (a & b) ? 0 : 1))); show(rAdapt);
ok(`the old AND no longer fits; a new formation was built (${step(rAdapt, "act+evaluate")?.plan.join(" → ")}) and the old one is still kept`, rAdapt.ok && !step(rAdapt, "act+evaluate").plan.includes(andId) && morphBuilder(O).registry.has(andId));

console.log("5 — persistence (extract → JSON → a fresh swarm takes it up → recalls)");
const saved = JSON.stringify(extractSwarm(O)), O2 = swarm(7);
const took = adoptSwarm(O2, JSON.parse(saved), { morphBuilder, runPlan });
ok(`saved ${saved.length} bytes; fresh swarm took ${took.learned} formations, ${took.clusters} cluster records, craft on ${took.craftPlaced} units`, took.learned >= 2 && took.clusters >= 2);
const rP = enter(O2, appHost(asserts("all3", 3, (a, b, c) => a & b & c))); show(rP);
ok("the fresh swarm meets all3 by recall", rP.ok && step(rP, "construct").recalled);

console.log("6 — reproduction (planChild carries what was acquired; the child takes it up)");
const forms = J("./form_particles.json");
const { genome } = planChild({ request: "build another you", forms, units: O.S.units, acquired: extractSwarm(O) });
ok("the genome carries the acquired formations", genome.acquired?.learned?.length >= 2);
const child = swarm(11); adoptSwarm(child, JSON.parse(JSON.stringify(genome.acquired)), { morphBuilder, runPlan });
const rC = enter(child, appHost(asserts("onlyBoth", 2, (a, b) => a & b))); show(rC);
ok("the child meets AND by recall, from its genome", rC.ok && step(rC, "construct").recalled);

console.log("7 — extraction (the swarm leaves; the host works on its own; no unit still carries a role)");
ok("every host above passed its own check with the swarm gone", [rAnd, rAll, rAgain, rAdapt, rP, rC].every(r => step(r, "extract").checkWithSwarmGone === 1 && step(r, "extract").unitsStillCarrying === 0));

console.log("8 — the swarm against its host (one scale up again), when the host gives an address");
const H = appHost(asserts("orr", 2, (a, b) => a | b)); H.address = { ...O.S.units[0].address };
const rH = enter(O, H); show(rH);
ok(`outermost leader climbed against the host: landed at ${step(rH, "cluster")?.host?.landed}`, rH.ok && !!step(rH, "cluster")?.host);

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
