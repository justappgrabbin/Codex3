// test_lack.mjs — v64h: can the swarm SEE what a world lacks (absence against a known whole), instead of only
// searching by health? Fair test: the same world listed in many random orders, a fresh swarm each run, the lack
// frame on vs off. We count how many tries it took to reach the first change that fixes the world.
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js"; import { World } from "./hostworld.js";
import { UnitSystem } from "./morph.js"; import { worldPlace, appPlace } from "./places.js"; import { settle, LACK } from "./place.js";
import { setGateEngineData } from "./gate_engine.js"; import { readFileSync } from "node:fs";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const first = (r, n) => r.steps.find(s => s.step === n), last = (r, n) => r.steps.filter(s => s.step === n).at(-1);
const D = ["Movement", "Evolution", "Being", "Design"];
const swarm = seed => { const S = new LivingSwarm({ seed }); for (let i = 0; i < 48; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  const O = new OrganismSwarm(S); for (let t = 0; t < 5; t++) O.step(); return O; };
const PAL = [[20, 20, 20], [200, 40, 30], [40, 170, 60], [40, 80, 220], [230, 200, 40], [235, 235, 245]];
const bright = c => (c[0] + c[1] + c[2]) / 3 > 200;
const check = { measure: W => { let n = 0; for (let x = 0; x < W.w; x++) if (bright(W.cells[(W.h - 1) * W.w + x])) n++; return W.temperature < 0 ? n / W.w : 1; } };
// a world where something already lives: red sparks drift in from the left and leave a trail (its own life, not a hint)
const dusk = () => { const W = new World({ name: "dusk-valley", temperature: -5 }); W.palette = PAL;
  W.systems.push(new UnitSystem({ appear: "left", move: [1, 0], wander: 1, stopOnContact: 0, leaveColour: "trail", colour: PAL[1] }, ["spark0", "spark1"], { seed: 5 })); W.run(40); return W; };
const cold = () => { const W = new World({ name: "cold-valley", temperature: -5 }); W.palette = PAL; return W; };

console.log("1 — what the swarm perceives in each world");
{ const P = worldPlace(dusk(), check), r = settle(swarm(3), P), o = first(r, "orient"), d = first(r, "discover");
  console.log("     dusk:", JSON.stringify(o.lack), "→", d.kind);
  ok(`dusk world: it sees ${o.lack.absent.length} of ${o.lack.whole} things the world could take in are absent, and holds that what's missing is among them`, d.kind === "lack");
  const h = first(r, "lack-hypothesis"); ok(`the hypothesis was tested: supported=${h?.supported} (the fix used ${h?.usedAbsent} absent things), health ${r.healthAfter}`, r.ok && h && typeof h.supported === "boolean");
  const Pc = worldPlace(cold(), check), rc = settle(swarm(3), Pc), dc = first(rc, "discover");
  ok(`empty cold world: everything is absent, so absence can't narrow anything and it says so (${dc.lack})`, dc.kind === "low-health" && /can't narrow/.test(dc.lack ?? "")); }

console.log("2 — does seeing the lack shorten the search? same world, 10 random listing orders, fresh swarm each run");
const rows = [];
for (let k = 0; k < 10; k++) { const res = {};
  for (const on of [true, false]) { LACK.on = on; const r = settle(swarm(3), worldPlace(dusk(), check, { order: k }));
    res[on ? "lack" : "plain"] = { ok: r.ok, tries: last(r, "construct")?.toFirst ?? null, health: r.healthAfter }; }
  rows.push(res); console.log(`     order ${k}: with lack ${JSON.stringify(res.lack)}  without ${JSON.stringify(res.plain)}`); }
LACK.on = true;
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
const okL = rows.filter(r => r.lack.ok && r.lack.tries !== null), okP = rows.filter(r => r.plain.ok && r.plain.tries !== null);
const mL = +mean(okL.map(r => r.lack.tries)).toFixed(1), mP = +mean(okP.map(r => r.plain.tries)).toFixed(1);
const better = rows.filter(r => r.lack.tries !== null && r.plain.tries !== null && r.lack.tries < r.plain.tries).length, worse = rows.filter(r => r.lack.tries !== null && r.plain.tries !== null && r.lack.tries > r.plain.tries).length;
console.log(`     mean tries to the first fix: with lack ${mL} (${okL.length}/10 fixed), without ${mP} (${okP.length}/10 fixed); lack fewer in ${better}, more in ${worse}`);
ok("both ways fix the world every time (the lack frame rules nothing out)", okL.length === 10 && okP.length === 10);
ok(`seeing the lack shortens the search on average (${mL} vs ${mP} tries)`, mL < mP);

console.log("3 — the app is unchanged: a gap still comes first");
{ const app = appPlace([{ path: "t.js", text: "import { both } from './g.js';\nassert(both(1,1) === 1);\nassert(both(1,0) === 0);\nassert(both(0,1) === 0);\nassert(both(0,0) === 0);\n" }], "app");
  const r = settle(swarm(3), app); ok(`app: ${first(r, "discover").kind}, health ${r.healthAfter}`, first(r, "discover").kind === "gap" && r.healthAfter === 1); }
ok("place.js still names no place, task or answer", !/dusk|cold|snow|bright|spark|both|gate\.js/i.test(readFileSync(new URL("./place.js", import.meta.url), "utf8").replace(/hypothesisLife/g, "")));
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
