// pagemorph.js — the page IS the swarm (v64h, Nov 26). Celestial (Nov 26, voice): the swarm is "supposed to be like a page...
// it could be like between a world... if somebody needs to learn something it becomes what they need to learn", and "if nothing
// else works on my app... I want to be able to tell it what it needs to be so that it can become that". Stated need and the
// need noticed from their birth chart are equally important; when they disagree, "they need to ask questions"; and over time
// it should "present itself as what the person needs after a while".
//
// Nothing here is a screen. The page is formed from rules already in the system:
//   need -> gates      STATED: the person's words, ranked against each gate's own text (vocabulary.json) with research.js's
//                      BM25; if the vocabulary isn't loaded, each word goes to a gate by the system's gematria (living.js).
//                      NOTICED: the gates of the person's own activations (charts.js addresses: all four charts, both sides).
//                      Birth data never enters this file; only the addresses do, so it stays on the device.
//   gate -> form       the gate's hexagram, outer lines, by function_side.js's rule: line 1 function/picture, line 6
//                      still/moving -> semantic · sound · picture · video.
//   gate -> operation  gate_engine.gateFunction: the inner trigram's operation (create, store, trigger, route, ...).
//   form -> region     a region is carried by the swarm's own units whose gates the need named (else units whose gate has
//                      that form); it sits where they are (their centroid), sized by its share, and shows what the units
//                      already are: their sentences (semantic), their sound voices (sound), their colour and Chladni
//                      shape (picture), their movement (video).
// Disagreement (stated vs noticed lead to different forms): PAGE.onDisagree "ask" (default) turns the page into yes/no questions,
// one from each dimension whose frame shows the gap (Space who, Movement where, Evolution what, Being when, Design why), made
// from the two gates that pulled hardest each way; the answers settle the form. "stated" or "noticed" pick a side (switches).
// Converging: every settled form is added to the person's history; the noticed side leans on that history more with each use
// (uses / (uses + PAGE.settle)), so the questions stop once the page has learned what this person comes for.
// Robustness: depends only on kingwen, function_side, gate_engine (works without vocabulary), research.js's BM25 and living.js
// gematria. No Arcadia, no mesh, no world needed. With no units at all, regions still form and are placed by gate number.
import { maskFromKingWen } from "./kingwen.js"; import { kindOf } from "./function_side.js"; import { gateFunction } from "./gate_engine.js";
import { Corpus } from "./research.js"; import { gematria } from "./living.js";

export const PAGE = { onDisagree: "ask", regions: 4, minShare: 0.1, settle: 3, birth: true, stated: true };
export const FORMS = ["semantic", "sound", "picture", "video"];
const lines = g => Array.from({ length: 6 }, (_, i) => (maskFromKingWen(g) >>> i) & 1);
export const formOfGate = g => kindOf(lines(g));

let C = null, CV = null;
function corpusOf(vocab) { if (CV === vocab && C) return C; CV = vocab; C = new Corpus();
  for (const [k, g] of Object.entries(vocab?.gates ?? {})) C.add({ gate: +k, title: `${g.name ?? ""} ${g.iching_name ?? ""}`,
    text: [g.keynote, g.archetype, g.entry_node, g.blue?.keynote, g.blue?.description, ...Object.values(g.lines ?? {}).map(l => l.name)].filter(Boolean).join(" ") });
  return C; }
/** The person's words -> weighted gates. */
export function statedGates(text, vocab = null) {
  const hits = vocab?.gates ? corpusOf(vocab).search(text, 8) : [];
  if (hits.length) return hits.map(h => ({ gate: h.gate, w: h.score, from: "words" }));
  return String(text).split(/\s+/).filter(w => gematria(w) > 0).map(w => ({ gate: 1 + (gematria(w) - 1) % 64, w: 1, from: "gematria" }));
}
/** The person's own activations (any list of addresses) -> gates, one vote each. */
export const birthGates = addresses => (addresses ?? []).filter(a => a?.gate).map(a => ({ gate: a.gate, w: 1, from: "chart" }));
/** Gates -> share of each form. */
export function formsOf(gs) { const s = Object.fromEntries(FORMS.map(f => [f, 0])); let t = 0;
  for (const x of gs) { s[formOfGate(x.gate)] += x.w; t += x.w; } for (const f of FORMS) s[f] = t ? s[f] / t : 0; return s; }
const lead = s => FORMS.slice().sort((a, b) => s[b] - s[a] || FORMS.indexOf(a) - FORMS.indexOf(b))[0];
const blend = (a, b, h) => Object.fromEntries(FORMS.map(f => [f, (a?.[f] ?? 0) * (1 - h) + (b?.[f] ?? 0) * h]));

/** One person's page memory (keep it on their device). */
export const newPerson = () => ({ uses: 0, history: Object.fromEntries(FORMS.map(f => [f, 0])), asked: 0, now: [] });

/** Work out what the page should become. need = { say?: text, addresses?: [...] }. Returns a decision, or questions. */
export function decide(need, person = newPerson(), { vocab = null } = {}) {
  const sg = PAGE.stated && need.say ? statedGates(need.say, vocab) : [], bg = PAGE.birth ? birthGates(need.addresses) : [];
  const S = sg.length ? formsOf(sg) : null, tot = Object.values(person.history).reduce((a, b) => a + b, 0);
  const H = tot ? Object.fromEntries(FORMS.map(f => [f, person.history[f] / tot])) : null, h = person.uses / (person.uses + PAGE.settle);
  const B0 = bg.length ? formsOf(bg) : null, NOW = person.now?.length ? formsOf(person.now.map(g => ({ gate: g, w: 1 }))) : null;
  const B = B0 && NOW ? blend(B0, NOW, 0.5) : (B0 ?? NOW), N = B && H ? blend(B, H, h) : (B ?? H);   // baseline, who they are now, then history
  if (!S && !N) return { form: null, why: "nothing stated and nothing known about the person yet", S, N, gates: [] };
  if (!S || !N || lead(S) === lead(N)) { const f = lead(S ?? N); return { form: f, why: !S ? "noticed" : !N ? "stated" : "stated and noticed agree", S, N, gates: [...sg, ...bg] }; }
  if (PAGE.onDisagree === "stated") return { form: lead(S), why: "they disagree; stated wins (switch)", S, N, gates: sg };
  if (PAGE.onDisagree === "noticed") return { form: lead(N), why: "they disagree; noticed wins (switch)", S, N, gates: bg };
  // ask: the five dimensions each ask one yes/no question in their own frame (Celestial, Nov 26: Space asks who, Movement
  // where, Evolution what, Being when, Design why; AUTOLING-style yes/no). Only a dimension where the two sides differ asks.
  // My reading of each frame, from what a gate already carries:
  //   Evolution / what  line 1 of the hexagram: function (understand it) or picture (see it)  -> one bit of the form
  //   Being / when      line 6: moving (happening now, move through it) or still (keep it, come back to it) -> the other bit
  //   Movement / where  the outer trigram's operation, the field it acts in
  //   Design / why      the gate's keynote (its reason), from the vocabulary when loaded
  //   Space / who       who they are NOW (Celestial, Nov 26): the gate's keynote put to them; the answer joins their live state
  //                     (person.now), which the noticed side leans toward from then on. The birth chart stays the baseline.
  const top = (gs, f) => gs.filter(x => formOfGate(x.gate) === f).sort((a, b) => b.w - a.w)[0]?.gate ?? null;
  const a = { form: lead(S), gate: top(sg, lead(S)) ?? sg[0]?.gate }, b = { form: lead(N), gate: top(bg, lead(N)) ?? bg[0]?.gate };
  const questions = frames(a, b, vocab);
  person.asked++; return { form: null, ask: questions, a, b, why: "stated and noticed disagree", S, N, gates: [...sg, ...bg] };
}

const ASK = {   // dimension -> its question word and how it reads a gate (each returns a value and the words for it)
  Evolution: { asks: "what", read: g => { const l = lines(g)[0]; return { v: l, say: l ? "something to see" : "something to understand" }; } },
  Being: { asks: "when", read: g => { const l = lines(g)[5]; return { v: l, say: l ? "something happening now that you move through" : "something still that you can come back to" }; } },
  Movement: { asks: "where", read: g => { const f = gateFunction(g).field; return { v: f, say: `where things ${f}` }; } },
  Design: { asks: "why", read: (g, V) => { const k = V?.gates?.[g]?.keynote ?? gateFunction(g).does; return { v: k, say: k }; } },
  Space: { asks: "who", read: (g, V) => ({ v: g, say: V?.gates?.[g]?.keynote ?? V?.gates?.[g]?.name ?? gateFunction(g).does }) },
};
const PHRASE = { what: s => `Is what you want ${s}?`, when: s => `Is it ${s}?`, where: s => `Should it work ${s}?`, why: s => `Is the reason for it: ${s}?`,
  who: s => `Is this who you are right now: ${s}?` };
function frames(a, b, vocab) {
  const out = [];
  for (const [dim, q] of Object.entries(ASK)) { if (!a.gate || !b.gate) break; const x = q.read(a.gate, vocab), y = q.read(b.gate, vocab);
    if (x.v == null || y.v == null || x.v === y.v || !x.say) continue;
    out.push({ id: dim, dimension: dim, asks: q.asks, text: PHRASE[q.asks](x.say), yes: { gate: a.gate, v: x.v, say: x.say }, no: { gate: b.gate, v: y.v, say: y.say } }); }
  return out;
}

/** Their answers settle it. answers: { Evolution: "yes" | "no", Being: ..., ... } or { words: "..." } (read like a stated need).
 *  The form's two bits come from what (line 1) and when (line 6); where a side was not asked, the two sides already agree. */
export function answer(decision, answers, person = newPerson(), { vocab = null } = {}) {
  if (!decision.ask) return decision;
  if (answers.words != null) { const s = formsOf(statedGates(answers.words, vocab)); answers = {};
    for (const q of decision.ask) answers[q.id] = (q.id === "Evolution" ? s.picture + s.video >= s.semantic + s.sound === !!q.yes.v
      : q.id === "Being" ? s.sound + s.video >= s.semantic + s.picture === !!q.yes.v : s[decision.a.form] >= s[decision.b.form]) ? "yes" : "no"; }
  const bit = (dim, line) => { const q = decision.ask.find(x => x.id === dim); if (!q) return lines(decision.a.gate)[line];
    return answers[dim] === "yes" ? q.yes.v : answers[dim] === "no" ? q.no.v : null; };
  const l1 = bit("Evolution", 0), l6 = bit("Being", 5); if (l1 == null || l6 == null) return decision;   // still waiting on what / when
  const form = kindOf([l1, 0, 0, 0, 0, l6]), yes = decision.ask.filter(q => answers[q.id] === "yes").length, no = decision.ask.filter(q => answers[q.id] === "no").length;
  const lean = yes >= no ? decision.a : decision.b, where = decision.ask.find(q => q.id === "Movement"), who = decision.ask.find(q => q.id === "Space");
  if (who && answers.Space) { person.now ??= []; person.now.push(answers.Space === "yes" ? who.yes.v : who.no.v); person.now = person.now.slice(-6); }
  return { form, op: where && answers.Movement ? (answers.Movement === "yes" ? where.yes.v : where.no.v) : null,
    why: `asked ${decision.ask.length} question${decision.ask.length > 1 ? "s" : ""} (${decision.ask.map(q => q.asks).join(", ")}); ${yes} yes, ${no} no`, S: decision.S, N: decision.N,
    answers, gates: decision.gates.filter(x => formOfGate(x.gate) === form).concat([{ gate: lean.gate, w: 1, from: "answer" }]) };
}

/** Form the page from the swarm's state for a settled decision. O may be null or broken: regions still form. */
export function compose(O, decision, person = null) {
  if (decision.ask) return { form: "questions", regions: decision.ask.map((q, i) => ({ kind: "question", id: q.id, dimension: q.dimension, asks: q.asks, text: q.text, at: [0.5, (i + 1) / (decision.ask.length + 1)], share: 1 / decision.ask.length })) };
  if (!decision.form) return { form: "empty", regions: [], why: decision.why };
  if (person) { person.uses++; person.history[decision.form]++; }
  const shares = formsOf(decision.gates.length ? decision.gates : [{ gate: 1, w: 1 }]);
  shares[decision.form] = Math.max(shares[decision.form], 0.5);   // the decided form leads the page
  const units = (O?.S?.units ?? []).filter(u => u && !u.broken);
  const regions = FORMS.filter(f => f === decision.form || shares[f] >= PAGE.minShare).sort((a, b) => (b === decision.form) - (a === decision.form) || shares[b] - shares[a])
    .slice(0, PAGE.regions).map(kind => {
      const gates = decision.gates.filter(x => formOfGate(x.gate) === kind).sort((a, b) => b.w - a.w).map(x => x.gate);
      let carriers = units.filter(u => gates.includes(u.address?.gate));   // the units the need named first, then units of the same form
      if (carriers.length < 3) carriers = carriers.concat(units.filter(u => !carriers.includes(u) && u.address?.gate && formOfGate(u.address.gate) === kind));
      carriers = carriers.slice(0, 12);
      const at = carriers.length ? [carriers.reduce((s, u) => s + u.x, 0) / carriers.length, carriers.reduce((s, u) => s + u.y, 0) / carriers.length]
        : [((gates[0] ?? 1) - 1) / 63, 0.5];
      const op = decision.op ?? (gates[0] ? gateFunction(gates[0]).op : null);
      const body = kind === "semantic" ? { lines: carriers.map(u => u.sentence).filter(Boolean).slice(0, 6) }
        : kind === "sound" ? { voices: carriers.flatMap(u => (u.sound?.voices ?? []).slice(0, 2).map(v => +v.freq.toFixed(2))).slice(0, 12) }
        : kind === "picture" ? { marks: carriers.map(u => ({ x: +u.x.toFixed(3), y: +u.y.toFixed(3), color: u.color, shape: (u.shape ?? []).length })) }
        : { paths: carriers.map(u => ({ from: [+u.x.toFixed(3), +u.y.toFixed(3)], heading: u.target ? [u.target.x, u.target.y] : null })) };
      return { kind, op, share: +shares[kind].toFixed(3), gates: gates.slice(0, 6), carriers: carriers.map(u => u.id), at: at.map(v => +v.toFixed(3)), ...body };
    });
  return { form: decision.form, why: decision.why, regions };
}

/** The page as HTML, read straight off the tree: each region's element follows its form; order follows where its units sit. */
export function render(page) {
  const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const order = page.regions.map((r, i) => ({ r, i })).sort((p, q) => p.r.at[1] - q.r.at[1] || p.r.at[0] - q.r.at[0]);
  const el = ({ r }) => { const st = `flex-grow:${Math.max(1, Math.round(r.share * 10))}`, d = `data-kind="${r.kind}" data-op="${esc(r.op)}" data-units="${(r.carriers ?? []).join(",")}" style="${st}"`;
    if (r.kind === "question") return `<fieldset data-kind="question" data-q="${esc(r.id)}" data-asks="${esc(r.asks)}"><legend>${esc(r.text)}</legend><button data-answer="yes">Yes</button><button data-answer="no">No</button></fieldset>`;
    if (r.kind === "semantic") return `<article ${d}>${r.lines.map(l => `<p>${esc(l)}</p>`).join("")}</article>`;
    if (r.kind === "sound") return `<div ${d} data-voices="${r.voices.join(",")}"></div>`;
    if (r.kind === "picture") return `<canvas ${d} data-marks='${esc(JSON.stringify(r.marks))}'></canvas>`;
    return `<canvas ${d} data-moving="1" data-paths='${esc(JSON.stringify(r.paths))}'></canvas>`; };
  return `<main data-form="${esc(page.form)}" style="display:flex;flex-wrap:wrap">${order.map(el).join("")}</main>`;
}
