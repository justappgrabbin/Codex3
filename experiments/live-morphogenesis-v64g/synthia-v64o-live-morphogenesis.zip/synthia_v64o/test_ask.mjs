// test_ask.mjs — the person asks the page (v64j, Nov 26). Run plain (Arcadia absent) and: node run_with_arcadia.mjs test_ask.mjs
//   1 perspective: the five dimension questions, "how", whole words only   2 each dimension reads its own chart
//   3 gate cores come from the system's own data   4 a lens that doesn't fit lowers an answer instead of halting it
//   5 one full round: ask -> answers -> pick -> the brain learns -> ask again   6 same question, same answers
//   7 the experience brain stays on the person, off the mesh   8 statements still make the page become them
//   9 the person's own single-file page: self-contained, no birth data, runs the same loop, keeps what it learned
import { readFileSync, existsSync } from "node:fs"; import { register } from "node:module"; import { setGateEngineData } from "./gate_engine.js";
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js"; import { AFTER_LEARN, enter } from "./morphogenesis.js";
import { appHost } from "./hosts.js"; import { Mesh } from "./mesh.js"; import { newPerson, decide } from "./pagemorph.js"; import { fourCharts } from "./charts.js";
import { ASK, WH, perspective, core, ask, feedback, askPage, renderAsk } from "./ask.js"; import { closure, mint, sourcesOf, remint } from "./mint.js";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); const V = J("./vocabulary.json"); setGateEngineData(V, J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
console.log(`Arcadia ${AFTER_LEARN.some(h => h.name === "arcadia") ? "installed" : "absent"}`);
const BIRTH = { date: "1990-06-15", time: "09:30", zone: "America/Chicago" };
const addresses = Object.values(fourCharts(BIRTH).charts).flatMap(c => c.addresses);   // worked out on the device; only these go on
const src = readFileSync(new URL("./ask.js", import.meta.url), "utf8").replace(/^\s*\/\/.*$/gm, "");

console.log("1 — perspective: which dimension a question asks");
const P = t => perspective(t);
ok("who Space, where Movement, what Evolution, when Being, why Design", ["who", "where", "what", "when", "why"].every(w => P(`${w} is it?`).dimension === WH[w]) &&
  P("who am I right now").dimension === "Space" && P("where should my energy go").dimension === "Movement" && P("when does this end").dimension === "Being");
ok("\"how\" asks for the expression, not a dimension", P("how do I start").wh === "how" && P("how do I start").dimension === null && P("how do I start").mode === "expression");
ok("whole words only: \"the whole thing?\" is not a who question (the doc's parser would have read it as who)", P("is the whole thing working?").wh === "what" && P("is the whole thing working?").defaulted);
ok("a plain statement is not a question (it still goes to the page as before)", P("teach me the details of the formula").kind === "statement");

console.log("2 — each dimension reads its own chart");
const byField = f => addresses.filter(a => a.field === f);
for (const [t, f] of [["where should I put my energy for work", "Movement"], ["why do I keep fighting with people?", "Design"], ["when will this conflict end", "Being"], ["what is my purpose?", "Evolution"]]) {
  const r = ask(t, newPerson(), { vocab: V, addresses }), own = r.offered.filter(o => o.own);
  ok(`"${t}" -> ${r.dimension}, read in the ${f} chart (${own.length} of ${r.offered.length} answers are gates they carry there)`,
    r.chart === f && own.every(o => byField(f).some(a => a.gate === o.gate && a.line === o.line))); }
const who = ask("who am I in my relationships?", newPerson(), { vocab: V, addresses });
ok("Space (who) reads all four charts", who.chart === "all four");

console.log("3 — gate cores come from the system's own data, not a seed pack");
const c6 = core(6, V); console.log(`     gate 6: pressure "${c6.pressure}", process "${c6.process}", links ${JSON.stringify(c6.links)}`);
ok("gate 6's link is its channel partner 59 (the doc's seed pack had it wrong for several gates)", JSON.stringify(c6.links) === "[59]");
ok("ask.js holds no per-gate table and names no gate", !/(\d+\s*,\s*){20,}/.test(src) && !/gate\s*===\s*\d/.test(src));

console.log("4 — a lens that doesn't fit lowers an answer instead of halting it");
const r4 = ask("what is my purpose?", newPerson(), { vocab: V, addresses }), miss = r4.offered.filter(o => o.lensFits === false);
ok(`answers still come when the lens doesn't fit (${miss.length} of ${r4.offered.length} shown here don't), each marked`, r4.offered.length > 0 && miss.length > 0 && /doesn't fit/.test(renderAsk(askPage(r4))));

console.log("5 — one full round: ask, answer, pick, learn, ask again");
const me = newPerson(), Q = "where should I put my energy for work", A = ask(Q, me, { vocab: V, addresses });
console.log(`     asked: "${Q}"  (${A.dimension}, ${A.chart} chart, ${A.considered} answers weighed)`);
A.offered.forEach((o, i) => console.log(`     ${i + 1}. [${o.score}] ${o.text}\n          ${o.chain}`));
const pick = A.offered[1], f1 = feedback(me, A, pick.id, "fits"), n1 = feedback(me, A, A.offered[0].id, "not");
console.log(`     picked 2 ("This fits"): ${f1.key} ${f1.before} -> ${f1.after};  said "Not this" to 1: ${n1.key} ${n1.before} -> ${n1.after}`);
const B = ask(Q, me, { vocab: V, addresses }), sc = id => B.offered.find(o => o.id === id)?.score;
console.log(`     asked again: ${B.offered.map((o, i) => `${i + 1}. ${o.id} [${o.score}]`).join("   ")}`);
const pr = id => B.offered.find(o => o.id === id)?.pref;
ok("the pick raised that answer's preference by one step, \"not this\" lowered the other's by one", pr(pick.id) === ASK.step && pr(A.offered[0].id) === -ASK.step && sc(pick.id) > pick.score);
let rounds = 1, R = B; while (R.offered[0].id !== pick.id && rounds < 20) { feedback(me, R, pick.id, "fits"); R = ask(Q, me, { vocab: V, addresses }); rounds++; }
ok(`after ${rounds} pick${rounds > 1 ? "s" : ""} the answer they keep choosing comes first`, R.offered[0].id === pick.id);
ok("the brain only holds a preference table (keys are dimension|gate.line, values within ±1)", Object.entries(me.brain.prefs).every(([k, v]) => /^\w+\|\d+\.\d$/.test(k) && Math.abs(v) <= 1));

console.log("6 — same question, same answers");
ok("deterministic: a fresh person asking the same thing gets the same answers in the same order", JSON.stringify(ask(Q, newPerson(), { vocab: V, addresses }).offered) === JSON.stringify(A.offered) && !/Math\.random/.test(src));

console.log("7 — the experience brain stays on the person, off the mesh");
const L = new LivingSwarm({ seed: 3 }); const D4 = ["Movement", "Evolution", "Being", "Design"];
for (let i = 0; i < 48; i++) L.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D4[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
const O = new OrganismSwarm(L); for (let k = 0; k < 5; k++) O.step();
const asserts = [{ path: "t.js", text: `import { onlyBoth } from './g.js';\n${[[0, 0], [0, 1], [1, 0], [1, 1]].map(([x, y]) => `assert(onlyBoth(${x},${y}) === ${x & y});`).join("\n")}\n` }];
const built = enter(O, appHost(asserts)); const M = new Mesh(); M.publish(O, { from: "test" }); const meshText = JSON.stringify(M.toJSON());
ok(`a swarm that built AND (${built.ok}) publishes its method; none of the person's brain is in it`, built.ok && M.methods.size > 0 && !Object.keys(me.brain.prefs).some(k => meshText.includes(k)) && !/experience-brain|prefs/.test(meshText));
ok("ask.js does not import the mesh, the swarm or Arcadia", !/mesh\.js|living\.js|organism_swarm|arcadia/.test(src));
ok("the brain is marked quarantined and survives being saved on the device (JSON)", me.brain.quarantined === true && JSON.stringify(JSON.parse(JSON.stringify(me)).brain) === JSON.stringify(me.brain));

console.log("8 — statements still make the page become them");
ok("a statement goes to pagemorph and forms a page as before", P("explore a world and wander through it").kind === "statement" && !!decide({ say: "explore a world and wander through it" }, newPerson(), { vocab: V }).form);

console.log("9 — the person's own single-file page");
const read = p => existsSync(new URL(p, import.meta.url)) ? readFileSync(new URL(p, import.meta.url), "utf8") : null;
const { files, missing } = closure(read, ["morph_app.js"]); files.set("morph.html", read("morph.html"));
const html = mint(files, { id: "test-person", addresses, person: me });
console.log(`     ${files.size} files carried inside one page, ${(html.length / 1024 / 1024).toFixed(2)} MB; missing: ${missing.length ? missing.join(", ") : "none"}`);
ok("it carries the morph page, its modules and the system's graph (vocabulary, lexicon, rules)", !missing.length && ["morph_app.js", "ask.js", "pagemorph.js", "vocabulary.json", "lexicon.json", "bhantugh_rules.json"].every(f => files.has(f)));
ok("no birth date, time or place is in the file, only the addresses", !html.includes(BIRTH.date) && !html.includes(BIRTH.zone) && !html.includes(BIRTH.time) && html.includes('"id":"test-person"'));
ok("it loads nothing from outside: every module import inside it is to its own map", [...sourcesOf(html).entries()].every(([p, t]) => !p.endsWith(".js") || ![...t.matchAll(/^\s*import\b[^;]*?\bfrom\s*["']([^"']+)["']/gm)].some(m => !m[1].startsWith("@synthia/"))));
// run the file's own modules in Node through its own import map, and ask the same question inside it
const map = JSON.parse(html.match(/<script type="importmap">([\s\S]*?)<\/script>/)[1]).imports;
register("data:text/javascript," + encodeURIComponent("let M;export async function initialize(d){M=d.map}export async function resolve(s,c,n){return M[s]?{url:M[s],shortCircuit:true}:n(s,c)}"), { data: { map } });
const inGE = await import("@synthia/gate_engine.js"), inV = (await import("@synthia/vocabulary.json", { with: { type: "json" } })).default, inR = (await import("@synthia/bhantugh_rules.json", { with: { type: "json" } })).default;
inGE.setGateEngineData(inV, inR); const inAsk = await import("@synthia/ask.js"), inPage = await import("@synthia/pagemorph.js");
const personal = JSON.parse(html.match(/<script type="application\/json" id="personal">([\s\S]*?)<\/script>/)[1]);
const inside = inAsk.ask(Q, personal.person, { vocab: inV, addresses: personal.addresses }), outside = ask(Q, me, { vocab: V, addresses });
ok("inside the file, the same question gives the same answers, with what the person taught it", JSON.stringify(inside.offered) === JSON.stringify(outside.offered) && inside.offered[0].id === pick.id);
ok("inside the file, a statement still forms a page", !!inPage.decide({ say: "explore a world and wander through it" }, inPage.newPerson(), { vocab: inV }).form);
const me2 = JSON.parse(JSON.stringify(me)); feedback(me2, outside, outside.offered[2].id, "fits");
const again = remint(html, { id: "test-person", addresses, person: me2 }), back = sourcesOf(again);
ok("\"Keep my page\" writes the file out again with the newest brain, and the same code", [...sourcesOf(html)].every(([p, t]) => back.get(p) === t) &&
  JSON.parse(again.match(/id="personal">([\s\S]*?)<\/script>/)[1]).person.brain.picks === me.brain.picks + 1);

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
