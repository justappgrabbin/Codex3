// make_page.mjs — make one person's own single-file page (v64j). Runs where the birth data already is (their device or the hub):
//   node make_page.mjs --date 1990-06-15 --time 09:30 --zone America/Chicago --id someone   ->  synthia-someone.html
// The birth data is used here to work out the addresses and is not written into the file.
import { readFileSync, writeFileSync, existsSync } from "node:fs"; import { fourCharts } from "./charts.js";
import { closure, mint } from "./mint.js"; import { newPerson } from "./pagemorph.js"; import { newBrain } from "./ask.js";
const arg = k => { const i = process.argv.indexOf("--" + k); return i > 0 ? process.argv[i + 1] : null; };
const birth = { date: arg("date"), time: arg("time") ?? "12:00", zone: arg("zone") ?? "UTC" }, id = (arg("id") ?? "me").replace(/[^\w-]/g, "");
if (!birth.date) { console.error("usage: node make_page.mjs --date YYYY-MM-DD [--time HH:MM] [--zone Area/City] [--id name]"); process.exit(1); }
const addresses = Object.values(fourCharts(birth).charts).flatMap(c => c.addresses);
const read = p => existsSync(new URL(p, import.meta.url)) ? readFileSync(new URL(p, import.meta.url), "utf8") : null;
const { files, missing } = closure(read, ["morph_app.js"]); files.set("morph.html", read("morph.html"));
if (missing.length) { console.error("missing: " + missing.join(", ")); process.exit(1); }
const person = newPerson(); person.brain = newBrain();
const out = `synthia-${id}.html`; writeFileSync(new URL(out, import.meta.url), mint(files, { id, addresses, person }));
console.log(`${out}: ${addresses.length} addresses, ${files.size} files inside`);
