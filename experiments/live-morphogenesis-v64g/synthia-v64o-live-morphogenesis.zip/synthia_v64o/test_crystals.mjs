// test_crystals.mjs — the Crystals and the Monopole as intermingling (v64n). Run plain and: node run_with_arcadia.mjs test_crystals.mjs
//   1 membership from the paper   2 intermingling: two inputs, NAND at the hexagram scale   3 the diamond's edges and diagonals
//   4 Space from the whole diamond   5 channels at two levels independently   6 the Monopole connects outward
//   7 the swarm reads it; switch off = v64m unchanged; nothing moves   8 the axis lines and the two sides' pairing are kept   9 purity
import { readFileSync, existsSync } from "node:fs";
import { LivingSwarm, SETTINGS } from "./living.js"; import { intermingle, readCrystals, pooled, hamming6, HUMAN_REGISTER, diamondFrom, CYCLE } from "./crystals.js";
import { CRYSTALS } from "./codex3/synthia-dual-swarm/core/state-space-canon.js"; import { PAIR, twoSides } from "./dual.js"; import { maskFromKingWen, kingWenFromMask } from "./kingwen.js";
import { baseline, differences } from "./regression.mjs";
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const DIMS = ["Movement", "Evolution", "Being", "Design"];
const addr = i => ({ gate: 1 + (i * 7) % 64, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: DIMS[i % 4], degree: (i * 37) % 360, house: 1 + (i * 5) % 12 });
const swarm = (n, seed = 3) => { const L = new LivingSwarm({ seed }); for (let i = 0; i < n; i++) L.add(addr(i), "mover", 0.2 + (i % 10) * 0.06, 0.2 + Math.floor(i / 10) * 0.1); return L; };
const unit = (id, dimension, gate, extra = {}) => ({ id, address: { dimension, gate, color: 1, tone: 1, base: 1, ...extra } });

console.log("1 — membership, as the paper says");
ok("Design Crystal = Being + Design; Personality Crystal = Evolution + Space; the Monopole = Movement alone",
  CRYSTALS.Design.members.join() === "Being,Design" && [...CRYSTALS.Personality.members].sort().join() === "Evolution,Space" && CRYSTALS.MagneticMonopole.members.join() === "Movement" && !CRYSTALS.MagneticMonopole.binary);

console.log("2 — intermingling takes two inputs");
const a = { gate: 1, color: 2, tone: 3, base: 4 }, b = { gate: 2, color: 2, tone: 3, base: 5 };
const ab = intermingle(a, b, "Being", "Design"), ba = intermingle(b, a, "Design", "Being");
ok("one input alone gives no meaning", intermingle(a, null, "Being", "Design") === null);
ok("at the hexagram scale it is the bond's NAND of the two hexagrams", ab.mask === (~(maskFromKingWen(1) & maskFromKingWen(2)) & 63) && ab.gate === kingWenFromMask(ab.mask));
ok("it is the same whichever side asks", ab.mask === ba.mask && ab.agree.join() === ba.agree.join());
ok("it says which levels (earth, human, heaven) the two agree on", Array.isArray(ab.agree) && ab.agree.every(l => ["earth", "human", "heaven"].includes(l)));

console.log("3 — the diamond's edges are made live; their names are only a reference");
{ const R = readCrystals(swarm(40).units); const name = e => `${e.of.slice().sort().join("-")}:${e.edge.reference.physics}/${e.edge.reference.human}`;
  const got = R.edges.map(name).sort(); console.log(`     ${got.join("  ")}`);
  ok("four edges, exactly the paper's: Mind-Ego Speed/Civilisation, Body-Individuality Force/Friction, Mind-Body Material/Humanity, Ego-Individuality Position/Earth",
    got.join() === ["Design-Evolution:Speed/Civilisation", "Being-Movement:Force/Friction", "Being-Evolution:Material/Humanity", "Design-Movement:Position/Earth"].sort().join());
  ok("each edge carries its own intermingled result, not a label", R.edges.every(e => Number.isInteger(e.gate) && e.gate >= 1 && e.gate <= 64));
  const d = intermingle(a, b, "Evolution", "Movement");
  ok("corners across the diamond are no edge: the diagonal passes through Space", d.edge === null && d.diagonal.through === "Space"); }

console.log("4 — Space comes from the whole diamond");
{ const base = [unit(0, "Movement", 10), unit(1, "Evolution", 20), unit(2, "Being", 30), unit(3, "Design", 40)];
  const R = readCrystals(base); ok("Space is the two diagonals (Evolution×Movement, Design×Being) intermingled", R.space && R.space.of.join() === "Evolution×Movement,Design×Being");
  const changed = DIMS.map((d, i) => { const v = base.map(u => u.address.dimension === d ? unit(u.id, d, 63) : u); return readCrystals(v).space.gate !== R.space.gate; });
  console.log(`     change one corner's gate to 63 -> Space changes: ${DIMS.map((d, i) => `${d} ${changed[i]}`).join(", ")}`);
  ok("every one of the four corners can change Space (it has no substance of its own)", changed.every(Boolean));
  { const z = [unit(0, "Movement", 1), unit(1, "Evolution", 2), unit(2, "Being", 30), unit(3, "Design", 40)], z2 = z.map(u => u.address.dimension === "Movement" ? unit(0, "Movement", 63) : u);
    ok("NAND's own law shows: an all-yin corner (gate 2) leaves its diagonal partner nothing to change", readCrystals(z).space.gate === readCrystals(z2).space.gate); }
  ok("with a corner missing there is no Space", readCrystals(base.slice(0, 3)).space === null);
  const P0 = R.crystals.Personality.gate, D0 = R.crystals.Design.gate;
  const mv = readCrystals(base.map(u => u.address.dimension === "Movement" ? unit(0, "Movement", 63) : u));
  console.log(`     Movement changed: Space ${R.space.gate} -> ${mv.space.gate}, Personality ${P0} -> ${mv.crystals.Personality.gate}, Design ${D0} -> ${mv.crystals.Design.gate}`);
  ok("the Personality Crystal takes Space in, so it feels the whole diamond; the Design Crystal is Being×Design only",
    R.crystals.Personality.of.join() === "Space,Evolution" && mv.crystals.Design.gate === D0 && mv.space.gate !== R.space.gate); }

console.log("5 — channels emerge at each level on its own (paper §2)");
{ const g1 = maskFromKingWen(1), near = kingWenFromMask(g1 ^ 1);
  const x = intermingle({ gate: 1, color: 1, tone: 1, base: 1 }, { gate: near, color: 6, tone: 6, base: 5 });
  const y = intermingle({ gate: 1, color: 1, tone: 1, base: 1 }, { gate: kingWenFromMask(~g1 & 63), color: 2, tone: 1, base: 1 });
  ok("one line apart at the gate, far apart below: a gate channel only", x.channel.gate && x.channel.gateDistance === 1 && x.channel.fine === false);
  ok("far apart at the gate, one bit apart in colour/tone/base: a fine channel only", !y.channel.gate && y.channel.fine === true && y.channel.fineDistance === 1); }

console.log("6 — the Monopole (Movement, unpaired) is where it connects outward");
{ const base = [unit(0, "Movement", 1), unit(1, "Evolution", 2), unit(2, "Being", 3), unit(3, "Design", 4)], R = readCrystals(base);
  const target = R.crystals.Design.mask, mover = unit(9, "Movement", kingWenFromMask(target ^ 4));
  const R2 = readCrystals([...base, mover]);
  ok("a Movement unit one line from a crystal's result is a channel out to it", R2.monopole.outward.some(o => o.unit === 9 && o.to === "Design" && o.distance === 1));
  ok("the Monopole has no partner and keeps its keynote I Define", !("MagneticMonopole" in R2.crystals) && R2.monopole.keynote === "I Define");
  ok("every outward link is within Hamming 1", R2.monopole.outward.every(o => o.distance <= 1)); }

console.log("7 — in the swarm");
const v64m = baseline("v64m");
if (v64m) { const K = await import(v64m); const x = swarm(40, 9), y = new K.LivingSwarm({ seed: 9 });
  for (let i = 0; i < 40; i++) y.add(addr(i), "mover", 0.2 + (i % 10) * 0.06, 0.2 + Math.floor(i / 10) * 0.1);
  for (let k = 0; k < 20; k++) { x.step(); y.step(); }
  const diff = differences(x, y); if (diff.length) console.log("     " + diff.slice(0, 5).join("; "));
  ok("CRYSTALS off: identical to v64m after 20 steps (positions, health, addresses, bonds, acquired, learned, programs)", SETTINGS.CRYSTALS === false && !x.crystals && !diff.length); }
else ok("v64m baseline present for comparison (regression-baselines/ or SYNTHIA_BASELINES)", false);
{ const off = swarm(40, 9); SETTINGS.CRYSTALS = true; const on = swarm(40, 9); for (let k = 0; k < 20; k++) { on.step(); } SETTINGS.CRYSTALS = false; for (let k = 0; k < 20; k++) off.step();
  const C = on.crystals; console.log(`     Design Crystal gate ${C.crystals.Design.gate}, Personality ${C.crystals.Personality.gate}, Space ${C.space.gate}, Monopole out-links ${C.monopole.outward.length}`);
  ok("CRYSTALS on: the swarm carries its reading every step", C && C.crystals.Design && C.crystals.Personality && C.space && C.edges.length === 4);
  ok("reading meaning moves nothing: same positions as with it off", on.units.every((u, i) => u.x === off.units[i].x && u.y === off.units[i].y)); }

console.log("8 — perspective bound: the diamond turns with the reader");
{ const M = diamondFrom("Movement"), B = diamondFrom("Being"), S = diamondFrom("Space");
  console.log(`     from Movement pairs ${["Movement", "Design"].map(d => d + "-" + M.pair[d]).join(", ")}; from Being ${["Being", "Design"].map(d => d + "-" + B.pair[d]).join(", ")}; read order from Being ${B.order.join(" ")}`);
  ok("read from Movement it is the canon's square exactly (every corner where the canon puts it)", Object.entries(M.at).every(([d, p]) => ({ Movement: "bottom right", Being: "bottom left", Evolution: "top left", Design: "top right" })[d] === `${p.row} ${p.side}`));
  ok("from Movement the pairs are Movement-Being and Design-Evolution (what Celestial read, and what dual.js and the v64k axis hold)", M.pair.Movement === "Being" && M.pair.Design === "Evolution" && M.pair.Being === PAIR.Being && M.pair.Evolution === PAIR.Evolution);
  ok("from Being the diamond turns: Being takes the Monopole's place and pairs with Evolution; Design with Movement", B.at.Being.row === "bottom" && B.at.Being.side === "right" && B.pair.Being === "Evolution" && B.pair.Design === "Movement");
  ok("from every corner the same four edges exist; only their lines (and reference names) move", ["Movement", "Being", "Evolution", "Design"].every(p => diamondFrom(p).edges.filter(e => e.line).map(e => e.corners.join("-")).sort().join() === M.edges.filter(e => e.line).map(e => e.corners.join("-")).sort().join())
    && diamondFrom("Being").edges.find(e => e.corners.join() === "Movement,Being").line !== M.edges.find(e => e.corners.join() === "Movement,Being").line);
  ok("read order starts at the reader and goes round (from Movement: Movement Being Evolution Design)", M.order.join() === "Movement,Being,Evolution,Design" && B.order[0] === "Being");
  ok("Space is the centre in every view: read from Space nothing turns", S.order.join() === M.order.join() && S.pair.Space === "Space");
  const U = swarm(40).units, rm = readCrystals(U, { perspective: "Movement" }), rb = readCrystals(U, { perspective: "Being" });
  const key = e => e.of.slice().sort().join("-"), seenM = Object.fromEntries(rm.edges.map(e => [key(e), e.seen.gate])), seenB = Object.fromEntries(rb.edges.map(e => [key(e), e.seen.gate]));
  ok("the same two corners mean the same thing in themselves, but read differently through different readers", rm.edges.every(e => rb.edges.find(f => key(f) === key(e)).gate === e.gate) && Object.keys(seenM).some(k => seenM[k] !== seenB[k]));
  ok("the crystals themselves don't change with the reader (they are groupings of corners)", rm.crystals.Design.gate === rb.crystals.Design.gate && rm.space.gate === rb.space.gate);
  const L = swarm(48); const d0 = twoSides(L.units, { dimension: "Being" }), d1 = twoSides(L.units, { dimension: "Being", perspective: "Being" });
  ok("dual.js can take a perspective: Being's shadow is Movement by default, Evolution read from Being", d0.shadowDim === "Movement" && d1.shadowDim === "Evolution"); }

console.log("9 — the axis lines and the two sides' pairing are kept");
ok("dual.js still pairs Being-Movement, Evolution-Design, Space-Space (the crystals combine meaning; they don't re-pair the sides)",
  PAIR.Being === "Movement" && PAIR.Evolution === "Design" && PAIR.Space === "Space");

console.log("10 — purity");
{ const src = readFileSync(new URL("./crystals.js", import.meta.url), "utf8");
  ok("crystals.js: no neural nets, no random draws", !/tensor|neural|onnx|tfjs|Math\.random/i.test(src)); }
console.log(`${pass} passed, ${fail} failed`); process.exitCode = fail ? 1 : 0;
