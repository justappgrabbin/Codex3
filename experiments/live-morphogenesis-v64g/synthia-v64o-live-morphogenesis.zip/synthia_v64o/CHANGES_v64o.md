# v64o — the "switch off = the earlier swarm" checks made portable and stricter (Nov 26)

v64n is kept as it was. v64o = v64n with only test files changed and two things added: `regression.mjs` and `regression-baselines/`.
Nothing in the swarm itself changed (living.js, crystals.js, social.js, opp.js and the rest are byte-for-byte v64n's).

Why: four checks in v64n compared the swarm against the earlier builds by reading them from a folder that only exists on the
build computer (/mnt/project-files/...). On any other computer those four failed with "saved copy present: FAIL". That was a
missing comparison, not a broken swarm, but it was a real gap. Found by another checker Celestial ran; confirmed here.

- `regression-baselines/synthia_v64k`, `_v64l`, `_v64m`: the genuine earlier builds' own living.js and every file it loads
  (found by following its imports, plus the vocabulary and rule book it reads), copied unchanged from the saved builds. 852 KB.
  Point `SYNTHIA_BASELINES` at another folder to compare against a different copy (the full saved builds give the same result).
- `regression.mjs`: `baseline(version)` finds them by relative path; `differences(a, b)` compares two swarms unit by unit on
  position, health, broken, kind, address, bonds, what each acquired, what each learned (transforms) and its program.
  Before, the four checks compared position and health only.
- A missing baseline is still a failed check, never a pass.
- Exit codes: test_cross, test_crystals and test_social now exit 1 when anything fails (test_dualswarm already did).
  run_all.sh exits 1 if any suite fails and prints each suite's seconds.
- Two always-true checks fixed: test_crystals had a leftover `... && false || true` in the "read from Movement" check (the real
  comparison after it was always there and still runs); test_social's "dissolving happens" part was `>= 0`. That check now says
  births and ties, since dissolving by mood and by age has its own checks in section 6.

Shown to work: run from a fresh unzip in another folder, all green; with the baseline missing, the check fails and the exit code
is 1; with one number changed in a baseline (DECAY), the comparison catches it in all three versions.
Timing: test_lack takes about a minute each way (ten full searches, by design); every other suite takes a few seconds.
Not covered by a baseline: births, inheritance and the crystals, because no earlier build had them to compare with.
