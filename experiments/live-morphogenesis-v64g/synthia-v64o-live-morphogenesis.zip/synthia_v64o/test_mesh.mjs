// test_mesh.mjs — the shared learning mesh (v64h, Nov 26): a research swarm puts its METHOD on the mesh; a fresh swarm with
// different units, in a different host, reads the mesh and solves what the research swarm learned. Counted against the same
// fresh swarm learning cold. Run plain (Arcadia absent) and with: node run_with_arcadia.mjs test_mesh.mjs
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js";
import { enter, morphBuilder, AFTER_LEARN } from "./morphogenesis.js"; import { appHost } from "./hosts.js"; import { runPlan } from "./unitbuild.js";
import { adoptSwarm } from "./recursion.js"; import { Mesh, methodOf } from "./mesh.js"; import { setGateEngineData } from "./gate_engine.js";
import { readFileSync } from "node:fs";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const arcadiaOn = AFTER_LEARN.some(h => h.name === "arcadia"); console.log(`Arcadia ${arcadiaOn ? "installed" : "absent"}`);
const step = (r, n) => r.steps.filter(s => s.step === n).at(-1);
const asserts = (name, n, f, file) => { const rows = []; for (let k = 0; k < 2 ** n; k++) { const a = Array.from({ length: n }, (_, i) => (k >> (n - 1 - i)) & 1); rows.push(`assert(${name}(${a.join(",")}) === ${f(...a)});`); }
  return [{ path: "t.js", text: `import { ${name} } from './${file}';\n${rows.join("\n")}\n` }]; };
// research swarm: 48 units, gates 1-48 in order
const D = ["Movement", "Evolution", "Being", "Design"];
const research = () => { const S = new LivingSwarm({ seed: 3 });
  for (let i = 0; i < 48; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  const O = new OrganismSwarm(S); for (let t = 0; t < 5; t++) O.step(); return O; };
// a different swarm: 40 units, other gates, other lines/colours/tones/bases, other dimension order, other seed
const D2 = ["Design", "Being", "Evolution", "Movement"];
const other = () => { const S = new LivingSwarm({ seed: 29 });
  for (let i = 0; i < 40; i++) S.add({ gate: 1 + (i * 37) % 64, line: 1 + (i * 5) % 6, color: 1 + (i * 3 + 1) % 6, tone: 1 + (i + 2) % 6, base: 1 + (i * 2) % 5, dimension: D2[i % 4] }, "person", 0.25 + (i % 8) * 0.06, 0.25 + Math.floor(i / 8) * 0.06);
  const O = new OrganismSwarm(S); for (let t = 0; t < 7; t++) O.step(); return O; };
const tries = r => { const c = step(r, "construct"); return c?.recalled ? (c.toFirst ?? 0) : (c?.executions ?? Infinity); };

console.log("1 — the research swarm learns, then puts its method on the mesh");
const R = research(), mesh = new Mesh();
const rA = enter(R, appHost(asserts("onlyBoth", 2, (a, b) => a & b, "g.js"))), rB = enter(R, appHost(asserts("all3", 3, (a, b, c) => a & b & c, "g.js")));
const rC = enter(R, appHost(asserts("eitherOne", 2, (a, b) => a ^ b, "g.js")));
ok("the research swarm built AND, all3 and XOR", rA.ok && rB.ok && rC.ok);
const pub = mesh.publish(R, { from: "research" }), J1 = JSON.stringify(mesh.toJSON());
ok(`on the mesh: ${pub.methods} methods, craft for ${pub.gates} gates${arcadiaOn ? `, ${pub.kinds} kinds` : ""} (${J1.length} bytes)`, pub.methods >= 3);
const researchUnits = new Set(R.S.units.map(u => u.id));
ok("method only: no unit ids, host names, files or test cases on the mesh", !/"unit"|"units"|"host"|"carry"|"bound"|"materials"|g\.js|onlyBoth|all3|eitherOne/.test(J1));
ok("every method lists the operations it needs (its vocabulary)", mesh.toJSON().methods.every(m => m.needs.length && m.needs.every(n => n.op)));

console.log("2 — transfer: a different swarm, a different host (other file, other function names)");
const task = () => appHost(asserts("allThree", 3, (a, b, c) => a & b & c, "z.js"));
const cold = other(), rCold = enter(cold, task());
const warm = other(), took = Mesh.fromJSON(JSON.parse(J1)).read(warm, { morphBuilder, runPlan, adoptSwarm, kinds: arcadiaOn }), rWarm = enter(warm, task());
console.log(`     cold: ${rCold.ok ? "solved" : "NOT solved"} after ${tries(rCold)} tries (${step(rCold, "construct")?.recalled ? "recalled" : "searched"}); ` +
  `reading the mesh: ${rWarm.ok ? "solved" : "NOT solved"} after ${tries(rWarm)} tries (${step(rWarm, "construct")?.recalled ? "recalled" : "searched"}); took ${took.taken} methods, craft on ${took.craftPlaced} units, skipped ${took.skipped.length}`);
ok("the swarm that read the mesh solved it", rWarm.ok);
ok(`far fewer tries than learning cold (${tries(rWarm)} vs ${tries(rCold)})`, rWarm.ok && tries(rWarm) * 5 <= tries(rCold));
ok("it solved it from the method, not by copying actions: its own units carried the steps", rWarm.ok && (step(rWarm, "organize")?.units ?? []).every(c => warm.S.units[c.unit]) && step(rWarm, "construct")?.recalled);
const rX = enter(warm, appHost(asserts("differ", 2, (a, b) => a ^ b, "q.js"))), rXc = enter(other(), appHost(asserts("differ", 2, (a, b) => a ^ b, "q.js")));
console.log(`     XOR in the other swarm: cold ${tries(rXc)} tries, from the mesh ${tries(rX)}`);
ok("a second method transfers too (XOR)", rX.ok && tries(rX) < tries(rXc));

console.log("3 — vocabulary: a swarm whose builder lacks an operation the method needs");
const thin = other(), Bt = morphBuilder(thin); Bt.registry.delete("nand");
const tThin = Mesh.fromJSON(JSON.parse(J1)).read(thin, { morphBuilder, runPlan, adoptSwarm });
console.log("     skipped:", JSON.stringify(tThin.skipped));
ok("methods needing an unknown operation are skipped and named, not forced", tThin.skipped.length >= 1 && tThin.skipped.every(s => s.missing.length) && tThin.skipped.some(s => s.missing.some(m => m.startsWith("nand"))));
ok("a method that builds on a skipped one is skipped too (all3 rests on AND)", tThin.taken < pub.methods);

console.log("4 — the mesh is plain data: write it, read it back, same methods");
ok("round trip keeps every method", Mesh.fromJSON(JSON.parse(J1)).toJSON().methods.length === pub.methods);
ok("methodOf on a swarm that learned nothing gives an empty method", methodOf(other()).methods.length === 0);

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
