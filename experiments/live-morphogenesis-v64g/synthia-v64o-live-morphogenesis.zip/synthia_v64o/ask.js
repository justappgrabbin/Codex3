// ask.js — the person asks the page (v64j, Nov 26). Celestial sent a third doc ("This is fire") and asked to put it in the app
// (Nov 26: "Can we put it in the app somewhere"). It lives inside the morph page's own loop: the page already becomes what the
// person tells it to be (pagemorph.js); now a question typed into the same line gets answered, and their pick teaches it.
//
//   ask -> perspective -> gate cores -> causal projector -> they pick -> experience brain
//
// What the doc had, and what this file does instead (my reading; purity first, no neural nets):
//   perspective parser   doc: substring match on who/what/when/why/how, default "what"; it had no "where" and "who" matched
//                        inside "whole". Here: whole words only, and the five dimension questions as Celestial gave them
//                        (Nov 26): Space who, Movement where, Evolution what, Being when, Design why. "how" is not a dimension:
//                        it asks for the expression, so it reads the process and the form. A "?" with no question word reads as
//                        "what", as the doc defaulted. No question word and no "?" = a statement, which goes to pagemorph as before.
//   which chart answers  each dimension reads its own chart (chart map confirmed Nov 24): Movement mean draconic, Design true
//                        draconic, Being tropical, Evolution sidereal Fagan; Space and "how" read all four. Fields stay distinct.
//   gate cores           doc: an invented 64-gate seed pack (pressure / process / resolution / links), with wrong links.
//                        Here nothing is typed in: pressure = the gate's anchor (lexicon.json, from Celestial's docs);
//                        process = what the gate does (gate_engine: inner trigram through outer); resolution = the end of the
//                        line's own trajectory through the base's chain (lexicon.js Section 5); links = the gate's channel
//                        partners (vocabulary.json "harmonic").
//   StellarNet           doc: a trained network picks the gate. Here: the person's words are ranked against each gate's own
//                        text (research.js BM25, as pagemorph does), linked gates come in at half weight, a gate they carry in
//                        that chart counts double; that weight is scaled so the best answer is 1, and the experience brain adds
//                        what they have taught it (within +/-1), so their teaching can always outweigh the rest. Deterministic.
//   causal projector     doc: one template per perspective. Here too, with "where" added (it was missing), filled only from
//                        the gate core and the person's own address. The chain under it is lexicon.js's trajectory.
//   Rule O               lexicon.sentence() halts on two thirds of lenses (base x tone x colour); for answers that would leave
//                        most people with nothing, so here a lens that doesn't fit lowers the answer's score (LENS_MISS) and
//                        is shown as not fitting, instead of halting. lexicon.js itself is unchanged.
//   experience brain     doc: +/-0.1 per helpful/unhelpful answer in a preference table (then a learned 16-float vector).
//                        Here only the table: +STEP when they pick an answer, -STEP when they say "not this", kept per
//                        dimension and gate.line, clamped to +/-1. It belongs to the person and stays on their device: it is
//                        never put on the mesh (mesh.js only reads the builder's registry and units' craft, never a person),
//                        and nothing here imports the mesh. It stays quarantined until a proving step exists (not built).
// Not built (not asked yet): the doc's "+1 open channel", the resonance packet, the three-body pings, the 64 creative ports.
import { statedGates, formOfGate } from "./pagemorph.js"; import { gateFunction } from "./gate_engine.js";
import { LEX, BASE_DIM, CHAINS, anchorIn, trajectory, ruleO } from "./lexicon.js";

export const ASK = { step: 0.1, clamp: 1, show: 3, linkWeight: 0.5, ownWeight: 2, lensMiss: 0.5 };
export const WH = { who: "Space", where: "Movement", what: "Evolution", when: "Being", why: "Design" };
const ALIAS = { whom: "who", whose: "who", which: "what", whence: "where", wherever: "where", whenever: "when", how: "how" };
const CHART_OF = { Movement: "Movement", Design: "Design", Being: "Being", Evolution: "Evolution" };   // field name = chart field in charts.js

/** Read a line of text: a question (with its dimension) or a statement. */
export function perspective(text) {
  const say = String(text ?? "").trim(), words = say.toLowerCase().match(/[a-z]+/g) ?? [];
  for (const w of words) { const k = WH[w] ? w : ALIAS[w]; if (!k) continue;
    return { kind: "question", wh: k, dimension: WH[k] ?? null, mode: k === "how" ? "expression" : "meaning", text: say }; }
  if (say.endsWith("?")) return { kind: "question", wh: "what", dimension: "Evolution", mode: "meaning", text: say, defaulted: true };
  return { kind: "statement", text: say };
}

/** One gate's core, read from what the system already holds. */
export function core(gate, vocab = null) {
  const v = vocab?.gates?.[gate] ?? {}, L = LEX.gates[gate] ?? {}, f = gateFunction(gate);
  return { gate, name: v.iching_name ?? L.name ?? f.name ?? `Gate ${gate}`, keynote: v.keynote ?? f.keynote ?? L.archetype ?? "",
    pressure: L.anchor ?? v.entry_node ?? "", process: f.does ?? "", field: f.field ?? null, op: f.op ?? null,
    sign: L.zodiac ?? v.sign ?? null, house: L.house ?? null, lines: L.lines ?? {}, links: (v.harmonic ?? []).filter(g => g >= 1 && g <= 64) };
}

/** The person's experience brain: a preference table, nothing else. Lives on the person, on their device. */
export const newBrain = () => ({ schema: "experience-brain/1", quarantined: true, prefs: {}, picks: 0, nots: 0, log: [] });
const keyOf = (dim, gate, line) => `${dim}|${gate}.${line}`;
const pref = (person, k) => person?.brain?.prefs?.[k] ?? 0;

function lensOf(addresses, dim) {
  const own = dim && CHART_OF[dim] ? addresses.filter(a => a.field === CHART_OF[dim]) : addresses;
  const sun = own.find(a => a.side === "Personality" && a.planetary === "Sun") ?? own[0] ?? null;
  return { own, lens: sun ? { line: sun.line, color: sun.color, tone: sun.tone, base: sun.base, chart: sun.chart ?? sun.field } : null };
}

/** The sentence parts for one address, without halting: the lens either fits (Rule O) or it doesn't. */
function chainFor(a) {
  const base = a.base ?? (LEX.gates[a.gate]?.base ?? 1), A = anchorIn(a.gate, base), path = trajectory(a.line, A.chain, A.at, a.gate);
  const fit = a.color && a.tone ? ruleO(base, a.tone, a.color) : { ok: null };
  return { dim: BASE_DIM[base - 1], path, end: path[path.length - 1] ?? null, fit: fit.ok, why: fit.reason ?? null };
}

const PROJECT = {   // the causal projector: one frame per question word (wording mine; slots only from the gate core and address)
  who: (c, a) => `You are someone shaped by ${c.pressure}. ${c.name}, line ${a.line}: ${c.lines[a.line] ?? ""}.`,
  where: (c, a) => `Where: house ${a.house ?? c.house} in ${a.zodiac ?? c.sign}, where things ${c.field}. ${c.name}, line ${a.line}: ${c.lines[a.line] ?? ""}.`,
  what: (c, a) => `What is happening: it ${c.process}. ${c.name}, line ${a.line}: ${c.lines[a.line] ?? ""}.`,
  when: (c, a, ch) => `When it resolves: at ${ch.end}. ${c.name}, line ${a.line}: ${c.lines[a.line] ?? ""}.`,
  why: (c, a) => `Because of ${c.pressure}: ${c.keynote}. ${c.name}, line ${a.line}: ${c.lines[a.line] ?? ""}.`,
  how: (c, a) => `How: it ${c.process}, shown as ${formOfGate(c.gate)}. ${c.name}, line ${a.line}: ${c.lines[a.line] ?? ""}.`,
};

/** Answer a question. addresses = the person's own activations (all four charts); person carries the brain. */
export function ask(text, person = null, { vocab = null, addresses = [] } = {}) {
  const q = perspective(text); if (q.kind !== "question") return { q, offered: [] };
  const dim = q.dimension ?? "how", { own, lens } = lensOf(addresses ?? [], q.dimension);
  const w = new Map(); for (const s of statedGates(q.text, vocab)) w.set(s.gate, Math.max(w.get(s.gate) ?? 0, s.w));
  const top = Math.max(0, ...w.values()); for (const [g, v] of w) w.set(g, top ? v / top : 1);
  for (const [g, v] of [...w]) for (const l of core(g, vocab).links) if (!w.has(l)) w.set(l, v * ASK.linkWeight);
  if (!w.size) for (const a of own) w.set(a.gate, 1);                         // no words matched: their own gates answer
  const out = [];
  for (const [gate, ws] of w) {
    const mine = own.filter(a => a.gate === gate);
    const as = mine.length ? mine : lens ? [{ gate, ...lens, zodiac: null, house: null }] : [1, 2, 3, 4, 5, 6].map(line => ({ gate, line }));
    for (const a of as) { const c = core(gate, vocab), ch = chainFor(a), k = keyOf(dim, gate, a.line);
      const base = ws * (mine.length ? ASK.ownWeight : 1) * (ch.fit === false ? ASK.lensMiss : 1), p = pref(person, k);
      out.push({ id: k, key: k, gate, line: a.line, own: !!mine.length, lensFits: ch.fit, lensWhy: ch.why, base: +base.toFixed(4), pref: +p.toFixed(4),
        score: 0, text: PROJECT[q.wh](c, a, ch), chain: ch.path.join(" → "), form: formOfGate(gate), from: a.chart ?? null }); } }
  // what they taught must be able to outweigh the rest: the system's own weight is put on 0..1 (the best = 1) before the
  // preference (within +/-1) is added, so enough picks lift any answer to the top and enough "not this" sink it.
  const most = Math.max(0, ...out.map(x => x.base)) || 1; for (const x of out) { x.weight = +(x.base / most).toFixed(4); x.score = +(x.weight + x.pref).toFixed(4); }
  const seen = new Set(), offered = out.sort((x, y) => y.score - x.score || x.gate - y.gate || x.line - y.line)
    .filter(x => !seen.has(x.text) && seen.add(x.text)).slice(0, ASK.show);
  return { q, dimension: dim, chart: q.dimension && CHART_OF[q.dimension] ? q.dimension : "all four", offered, considered: out.length };
}

/** Their pick teaches the brain. verdict "fits" (+step) or "not" (-step). Returns what changed. */
export function feedback(person, round, id, verdict = "fits") {
  const c = round.offered.find(x => x.id === id); if (!c || !person) return null;
  person.brain ??= newBrain(); const B = person.brain, before = B.prefs[c.key] ?? 0, d = verdict === "fits" ? ASK.step : -ASK.step;
  B.prefs[c.key] = +Math.max(-ASK.clamp, Math.min(ASK.clamp, before + d)).toFixed(4); verdict === "fits" ? B.picks++ : B.nots++;
  B.log.push({ key: c.key, verdict, wh: round.q.wh }); B.log = B.log.slice(-50);
  return { key: c.key, verdict, before, after: B.prefs[c.key] };
}

/** The answers as a page: each one a region, best first. */
export function askPage(round) {
  if (!round.offered?.length) return { form: "answers", regions: [], why: round.q.kind === "question" ? "nothing in the system matched this question yet" : "not a question" };
  return { form: "answers", asks: round.q.wh, dimension: round.dimension, regions: round.offered.map((c, i) => ({ kind: "answer", id: c.id, text: c.text, chain: c.chain,
    own: c.own, lensFits: c.lensFits, share: +(1 / round.offered.length).toFixed(3), at: [0.5, (i + 1) / (round.offered.length + 1)] })) };
}
export function renderAsk(page) {
  const esc = s => String(s ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  if (!page.regions.length) return `<main data-form="answers"><p>${esc(page.why)}</p></main>`;
  return `<main data-form="answers" data-asks="${esc(page.asks)}" style="display:flex;flex-wrap:wrap">${page.regions.map(r =>
    `<article data-kind="answer" data-id="${esc(r.id)}" style="flex-grow:${Math.max(1, Math.round(r.share * 10))}"><p>${esc(r.text)}</p>` +
    `<p data-chain>${esc(r.chain)}</p>${r.lensFits === false ? `<p data-lens="miss">your lens doesn't fit this one</p>` : ""}` +
    `<button data-verdict="fits">This fits</button><button data-verdict="not">Not this</button></article>`).join("")}</main>`;
}
