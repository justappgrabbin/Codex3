// axis.js — how Being and Movement read, now that they share the vertical axis (v64k, Nov 26).
// Celestial (Nov 26): "being moves across and counts up moving down movement moves upward and reads across but everything is in
// line even the duals". My translation, derived from the agent's shape (tiling.js), nothing tabled:
//   * a READING is a count (1, 2, 3, ...) laid over rows. A dimension that sits on a tip of the vertical axis starts at its own
//     tip: Being at the top tip, so its rows go downward while the count goes up; Movement at the bottom tip, so its rows go
//     upward. Within a row both read ACROSS, the same way round, so the two readings are one line run in opposite directions.
//   * agent scale: the rows are the two halves of the bipyramid (the three faces on each tip); across is the order of the
//     tile's edges E1->E2, E2->E3, E3->E1. Movement reads 1 2 3 then 4 5 6 (the I Ching's own bottom-to-top count);
//     Being reads 4 5 6 then 1 2 3.
//   * shell scale (the same rule one size up): the shell's top tip is the corner it grew from (my pick); its rows are the rings
//     of agents by how far they sit from that tip; across is a walk round each ring (start at the lowest agent, step to the
//     lowest unvisited neighbour in the ring), the same walk for both. Being reads the rings top to bottom, Movement bottom to top.
//   * "even the duals": in the agent each dual pair spans one line (see tiling.js); across the two sides (dual.js), an agent
//     and its shadow partner sit on the same ring, so the line runs through both.
// Only Being and Movement have a reading here; the other three were not described, so they get none (null).
import { AGENT } from "./tiling.js";

const tipOf = dim => Object.keys(AGENT.corners).find(c => AGENT.corners[c] === dim);
const RING = ["E1", "E2", "E3"];
const acrossOf = l => { const [, a, b] = AGENT.faces[l], i = RING.indexOf(a); return RING[(i + 1) % 3] === b ? i : RING.indexOf(b); };

/** One agent read by a dimension on the vertical axis: [{ count, face, row }], or null for a dimension not on it. */
export function readAgent(dim) {
  const tip = tipOf(dim); if (tip !== "B" && tip !== "T") return null; const other = tip === "B" ? "T" : "B";
  const row = t => [1, 2, 3, 4, 5, 6].filter(l => AGENT.faces[l][0] === t).sort((x, y) => acrossOf(x) - acrossOf(y));
  const order = [...row(tip), ...row(other)].map((face, i) => ({ count: i + 1, face, row: i < 3 ? 0 : 1 }));
  return { dimension: dim, from: tip, moves: tip === "B" ? "up" : "down", order };
}

/** The rings of a shell, from its top tip (the corner it grew from): rows[r] = agent ids read across. */
export function ringsOf(T, top = 0) {
  const nb = new Map(); for (const e of T.edges.keys()) { const [a, b] = e.split("-").map(Number); nb.set(a, [...(nb.get(a) ?? []), b]); nb.set(b, [...(nb.get(b) ?? []), a]); }
  const dist = new Map([[top, 0]]), q = [top]; while (q.length) { const v = q.shift(); for (const w of nb.get(v) ?? []) if (!dist.has(w)) { dist.set(w, dist.get(v) + 1); q.push(w); } }
  const rowOf = T.faces.map(f => Math.min(...f.v.map(v => dist.get(v) ?? Infinity)));
  const touch = (i, j) => T.faces[i].v.filter(v => T.faces[j].v.includes(v)).length === 2;
  const rows = [];
  for (const r of [...new Set(rowOf)].sort((a, b) => a - b)) {
    const left = T.faces.map(f => f.id).filter(i => rowOf[i] === r), walk = [];
    while (left.length) { let cur = Math.min(...left);
      while (cur != null) { walk.push(cur); left.splice(left.indexOf(cur), 1); const next = left.filter(j => touch(cur, j)); cur = next.length ? Math.min(...next) : null; } }
    rows.push(walk); }
  return { rows, rowOf };
}

/** A whole shell read by Being (top down) or Movement (bottom up): [{ count, agent, row }], or null for another dimension. */
export function readShell(T, dim, top = 0) {
  const tip = tipOf(dim); if (tip !== "B" && tip !== "T") return null;
  const { rows } = ringsOf(T, top), seq = tip === "T" ? rows : rows.slice().reverse();
  const order = []; seq.forEach(walk => walk.forEach(agent => order.push({ count: order.length + 1, agent, row: rows.indexOf(walk) })));
  return { dimension: dim, moves: tip === "B" ? "up" : "down", rows: rows.length, order };
}
