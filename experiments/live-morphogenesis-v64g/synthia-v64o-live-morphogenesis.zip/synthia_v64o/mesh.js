// mesh.js — the shared learning mesh (v64h, Nov 26). Celestial (Nov 26, voice): "if the research version gets on the mesh,
// then the other ones can learn from it and not do exactly what it does, but learn exactly how it works."
// Built from what is already here, nothing rebuilt: recursion.extractSwarm / adoptSwarm already carry a swarm's learning as
// data, and PrimitiveSwarm already promotes a verified chain to a reusable primitive. What the mesh adds is the filter:
//   METHOD goes on the mesh   each verified formation as its graph of operations (which op feeds which, its typed inputs and
//                             output), what operations it needs (its vocabulary), and the craft each GATE gained per op
//                             (pooled over the units of that gate, so it is how a kind of unit does a step, not who did it).
//   ACTIONS stay off          which unit carried a step, the host and file it was built for, the cases it was checked
//                             against, the materials, the cluster records (they name the units that led them).
// Reading the mesh: a swarm takes a method only if its own builder knows every operation the method needs (same op, same
// version); otherwise the method is skipped and the mismatch reported, never forced. Methods that use other methods are taken
// after them. Arcadia's kinds (if Arcadia is installed on both sides) travel as names and centroids only.
// Checking the vocabulary (my reading): the only vocabulary a formation depends on is its builder's operation ids and versions;
// unit addresses never enter a method, so swarms with different units and different charts can share one.

const strip = plan => plan.map(({ id, op, inputs }) => ({ id, op, inputs }));

/** What one swarm puts on the mesh: its method only. */
export function methodOf(O) {
  const B = O.morph; if (!B) return { schema: "mesh-method/1", methods: [], craftByGate: [], kinds: [] };
  const methods = [...B.registry.values()].filter(p => p.formation && String(p.id).startsWith("formation."))
    .map(p => ({ id: p.id, inputs: p.inputs, output: p.output, cost: p.cost, plan: strip(p.formation.plan), result: p.formation.output,
      needs: [...new Set(p.formation.plan.map(s => s.op))].map(op => ({ op, version: B.registry.get(op)?.version ?? null })) }));
  const byGate = new Map();
  for (const u of O.S.units) if (u.craft) { const g = u.address.gate, c = byGate.get(g) ?? { gate: g, n: 0, craft: {} }; c.n++;
    for (const [op, v] of Object.entries(u.craft)) c.craft[op] = (c.craft[op] ?? 0) + v; byGate.set(g, c); }
  const craftByGate = [...byGate.values()].map(c => ({ gate: c.gate, craft: Object.fromEntries(Object.entries(c.craft).map(([k, v]) => [k, v / c.n])) }));
  const kinds = (O.arcadia?.kinds ?? []).map(k => ({ name: k.name, centroid: k.centroid, count: k.count }));
  return JSON.parse(JSON.stringify({ schema: "mesh-method/1", methods, craftByGate, kinds }));
}

export class Mesh {
  constructor() { this.methods = new Map(); this.craft = new Map(); this.kinds = []; this.from = []; }
  /** Put a swarm's method on the mesh. Repeat publishes merge: same method id is kept once; gate craft is averaged in. */
  publish(O, { from = "swarm" } = {}) {
    const m = methodOf(O); this.from.push(from);
    for (const x of m.methods) if (!this.methods.has(x.id)) this.methods.set(x.id, { ...x, from });
    for (const c of m.craftByGate) { const prev = this.craft.get(c.gate);
      if (!prev) this.craft.set(c.gate, { gate: c.gate, n: 1, craft: { ...c.craft } });
      else { prev.n++; for (const [op, v] of Object.entries(c.craft)) prev.craft[op] = (prev.craft[op] ?? 0) + (v - (prev.craft[op] ?? 0)) / prev.n; } }
    for (const k of m.kinds) if (!this.kinds.some(j => j.name === k.name)) this.kinds.push(k);
    return { methods: m.methods.length, gates: m.craftByGate.length, kinds: m.kinds.length };
  }
  /** Everything on the mesh, as plain data (it never holds a unit id, host name or test case). */
  toJSON() { return { schema: "mesh/1", from: this.from, methods: [...this.methods.values()], craftByGate: [...this.craft.values()].map(({ gate, craft }) => ({ gate, craft })), kinds: this.kinds }; }
  static fromJSON(j) { const M = new Mesh(); M.from = [...j.from]; for (const x of j.methods) M.methods.set(x.id, x);
    for (const c of j.craftByGate) M.craft.set(c.gate, { gate: c.gate, n: 1, craft: { ...c.craft } }); M.kinds = [...(j.kinds ?? [])]; return M; }

  /** A swarm reads the mesh. morphBuilder, runPlan and adoptSwarm are passed in so this file depends on nothing else.
   *  kinds: true takes Arcadia's kinds too (pass it only where Arcadia is installed). */
  read(O, { morphBuilder, runPlan, adoptSwarm, kinds: takeKinds = false }) {
    const B = morphBuilder(O), taken = [], skipped = [], pending = [...this.methods.values()];
    // take a method once every operation it needs is known here (methods that use methods come after them)
    for (let progress = true; progress && pending.length;) { progress = false;
      for (let i = 0; i < pending.length; i++) { const x = pending[i];
        const missing = x.needs.filter(n => !B.registry.has(n.op) && !taken.includes(n.op) || (B.registry.has(n.op) && n.version != null && (B.registry.get(n.op).version ?? null) !== n.version));
        const waitsOnMesh = missing.length && missing.every(n => this.methods.has(n.op) && !taken.includes(n.op) && pending.some(p => p.id === n.op));
        if (waitsOnMesh) continue;
        pending.splice(i--, 1); progress = true;
        if (missing.length) { skipped.push({ id: x.id, missing: missing.map(n => `${n.op}${n.version != null ? " v" + n.version : ""}`) }); continue; }
        taken.push(x.id); } }
    for (const x of pending) skipped.push({ id: x.id, missing: x.needs.filter(n => !B.registry.has(n.op) && !taken.includes(n.op)).map(n => n.op) });
    const learned = taken.map(id => { const x = this.methods.get(id); return { id: x.id, inputs: x.inputs, output: x.output, cost: x.cost, formation: { plan: x.plan, output: x.result } }; });
    const r = adoptSwarm(O, { learned, craft: [...this.craft.values()].map(c => ({ id: null, gate: c.gate, craft: c.craft })) }, { morphBuilder, runPlan });
    let kinds = 0; if (takeKinds) { O.arcadia ??= { kinds: [], seen: {} };
      for (const k of this.kinds) if (!O.arcadia.kinds.some(j => j.name === k.name)) { O.arcadia.kinds.push({ id: `kind.${O.arcadia.kinds.length + 1}`, name: k.name, centroid: k.centroid, count: k.count, formations: [], carriers: [], history: [] }); kinds++; } }
    return { taken: taken.length, skipped, craftPlaced: r.craftPlaced, kinds };
  }
}
