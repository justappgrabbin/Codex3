// places.js — two PLACES for the two-environment test (Celestial's list, item 1, Nov 26). These are environments, not
// the swarm. A place shows only three things, and never what it needs:
//   there()   what is there: items { id, kind, type, value, provides:[names], refers:[{name, from, arity, argType}] }
//   can()     what can be done there: operations { id, inputs, output: "fit", run } — run TRIES the change in a copy of
//             the place and answers { score: health after, change }; nothing is changed until apply()
//   health()  one number 0..1, the place's own state
//   apply(change)  the change made for real (only when the swarm settles on it)
// The swarm (place.js) has to orient and find what is missing on its own.
import { World } from "./hostworld.js";
import { UnitSystem, trial } from "./morph.js";
import { runHost } from "./lifecycle.js";

// ---------------- a half-broken app ----------------
// Its health = the share of its test files that run clean (each run with every non-test file). Its items are its files,
// what each file exports (provides) and what it imports and calls (refers, with the call's arity and argument kind as
// written). It doesn't say which reference is unanswered.
const isTest = f => /assert\(/.test(f.text);
const defsOf = t => [...t.matchAll(/export\s+(?:function|const|let)\s+([A-Za-z_$][\w$]*)/g)].map(m => m[1]);
const importsOf = t => [...t.matchAll(/import\s*\{([^}]*)\}\s*from\s*['"]\.\/([^'"]+)['"]/g)].flatMap(m => m[1].split(",").map(s => s.trim()).filter(Boolean).map(n => ({ name: n, from: m[2] })));
const callArgs = (t, n) => { const m = t.match(new RegExp(n.replace(/\$/g, "\\$") + "\\(([^()]*)\\)")); return m ? m[1].split(",").map(s => s.trim()) : null; };
export function appPlace(files, name = "app") {
  const F = files.map(f => ({ ...f }));
  const health = (fs = F) => { const tests = fs.filter(isTest), rest = fs.filter(f => !isTest(f));
    return tests.length ? tests.filter(t => runHost([...rest, t]).ok).length / tests.length : 1; };
  const tableFn = (n, table, arity) => `export function ${n}(${Array.from({ length: arity }, (_, i) => "a" + i).join(", ")}) { return ${JSON.stringify(table)}[${Array.from({ length: arity }, (_, i) => `(a${i} ? 1 : 0) * ${2 ** (arity - 1 - i)}`).join(" + ")}]; }`;
  const withDef = (fs, { name: n, table, path }) => { const arity = Math.log2(table.length), code = tableFn(n, table, arity), f = fs.find(x => x.path === path);
    return f ? fs.map(x => x === f ? { ...x, text: x.text + "\n" + code + "\n" } : x) : [...fs, { path, text: code + "\n" }]; };
  return { name, kind: "place:app",
    there: () => F.flatMap(f => [{ id: "file:" + f.path, kind: "file", type: "file", value: f.path, provides: defsOf(f.text),
      refers: importsOf(f.text).map(r => { const a = callArgs(f.text, r.name); return { ...r, arity: a?.length ?? null, argType: a && a.every(x => /^[01]$/.test(x)) ? "bits" : null }; }) }]),
    // what can be done here: put a definition into a file, given as a name, a file and a table of answers
    can: () => [{ id: "define", inputs: { name: "name", path: "path", table: "bits" }, output: "fit",
      run: ({ name: n, path, table }) => { const ok = Number.isInteger(Math.log2(table.length)) && table.length >= 2;
        return { score: ok ? health(withDef(F, { name: n, table, path })) : 0, change: { name: n, path, table } }; } }],
    health: () => health(),
    apply: ch => { const next = withDef(F, ch); F.length = 0; F.push(...next); },
    files: F };
}

// ---------------- a small world ----------------
// A grid world (hostworld.js) with one check of its own; its items are what is in it to work with (its edges, the
// directions on its grid, the ways a thing can leave a mark, the colours it can show). Health = its own check after a run.
// v64h: each item also says how much of it is PRESENT in the world right now (what's there, not what's needed):
// a colour by how many cells show it, an edge/heading/mode by how many running things in the world use it.
// `order` (optional seed) only shuffles the order the world lists its items in, so a test can check that finding
// something doesn't hang on list order.
export function worldPlace(W, check, { order = null } = {}) {
  W.checks = [check]; const ids = Array.from({ length: 24 }, (_, i) => `u${i}`);
  let items = [...["top", "bottom", "left", "right", "anywhere"].map(v => ({ id: "edge:" + v, kind: "edge", type: "edge", value: v })),
    ...[[0, 1], [0, -1], [-1, 0], [1, 0]].map((v, i) => ({ id: "heading:" + i, kind: "heading", type: "heading", value: v })),
    ...["no", "trail", "contact"].map(v => ({ id: "mode:" + v, kind: "mode", type: "mode", value: v })),
    ...W.palette.map((v, i) => ({ id: "colour:" + i, kind: "colour", type: "colour", value: v }))].map(x => ({ ...x, provides: [], refers: [] }));
  if (order !== null) { let sd = (order * 2654435761) >>> 0; const rnd = () => (sd = (sd * 1664525 + 1013904223) >>> 0) / 4294967296;
    items = items.map(x => [rnd(), x]).sort((a, b) => a[0] - b[0]).map(x => x[1]); }
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const presentOf = it => { const bs = W.systems.map(s => s.b).filter(Boolean);
    if (it.type === "colour") return W.cells.filter(c => same(c, it.value)).length;
    if (it.type === "edge") return bs.filter(b => b.appear === it.value).length;
    if (it.type === "heading") return bs.filter(b => same(b.move, it.value)).length;
    if (it.type === "mode") return bs.filter(b => b.leaveColour === it.value).length; return 0; };
  return { name: W.name, kind: "place:world",
    types: { edge: x => ["top", "bottom", "left", "right", "anywhere"].includes(x), heading: x => Array.isArray(x) && x.length === 2,
      mode: x => ["no", "trail", "contact"].includes(x), colour: x => Array.isArray(x) && x.length === 3 },
    there: () => items.map(it => ({ ...it, present: presentOf(it) })),
    can: () => [{ id: "behave", dimension: "Movement", inputs: { appear: "edge", move: "heading", mark: "mode", colour: "colour" }, output: "fit",
      run: ({ appear, move, mark, colour }) => { const b = { appear, move, wander: 0, stopOnContact: 0, leaveColour: mark, colour };
        return { score: +trial(W, b, ids).toFixed(3), change: b }; } }],
    health: () => +W.fork().run(120).score().toFixed(3),
    apply: b => W.systems.push(new UnitSystem(b, ids.map(i => W.name + "-" + i), { seed: 11 })),
    world: W };
}
