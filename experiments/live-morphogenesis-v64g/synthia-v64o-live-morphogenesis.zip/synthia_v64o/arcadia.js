// arcadia.js — the swarm's vector coordinator (Celestial's list, item 2, Nov 26). Pure JS, no neural nets, no backend.
// Celestial's words (Nov 2026): when part of the swarm forms something, Arcadia should classify what it is being, how
// its parts sit with the whole, and how it expresses (out loud, breaking, regenerating) — not just store agents.
// What was studied, not copied: ruvnet's ARCADIA (research-only here) keeps vectors and finds the nearest by cosine
// similarity (src/vector_index.rs). The old arcadia.ts is a backend router that stores agents in MySQL through a remote
// server; its centre tables disagree with v64's address.js, so nothing is taken from it.
//
// A CONDITION, not a feature: nothing here names a kind, a world or a task. Kinds are not a list; they come out of
// what the swarm forms. My translation of the three questions:
//   BEING    every formation gets a vector made only of what the swarm already reads off it: which of the eight gate
//            operations its members' gates do (gate_engine), which dimensions its units sit in, where each member's
//            trigger landed on the ladder (recursion.js), its scale and its coherence. The nearest known kind by cosine
//            similarity is what it is being; if none is close enough, it is a new kind, named by rule from its own
//            leading operation, leading dimension and the rung its triggers most often reached (numbered if taken).
//   PARTS    each member's own vector against the whole: core (at or above the formation's mean alignment) or edge
//            (below); a sub-formation inside it is an inner whole.
//   EXPRESS  read from the kind's own history: forming (first time), holding (back with coherence kept), breaking
//            (back with coherence down by more than ARCADIA.drop), regenerating (back and whole again after breaking);
//            outward = it changed a host.
// FEEDBACK  (how the swarm uses it): what one formation learned is shared with every unit that carries a formation
//            of the same kind (a share of the gain, ARCADIA.share), so anything learned is learned across that kind.
// Working values (mine): same 0.9, drop 0.2, share 0.25.
import { gateFunction } from "./gate_engine.js";
// OPTIONAL LAYER: morphogenesis does not import this file. installArcadia(AFTER_LEARN) adds it; ARCADIA.on turns it off again.
// Where Arcadia is not allowed, leave it uninstalled (or leave the file out): the swarm builds, learns and shares craft without it.

export const ARCADIA = { on: true, same: 0.9, drop: 0.2, share: 0.25 };
const OPS = ["create", "store", "trigger", "route", "filter", "propagate", "render", "exchange"];
const DIMS = ["Movement", "Evolution", "Being", "Design", "Space"];
const RUNGS = ["base", "tone", "color", "line", "gate"];

const dimOf = (O, id) => O.S.units[id]?.address?.dimension ?? O.S.units[id]?.dimension ?? null;
function vec(parts, scale = 1, coherence = 1) {
  const v = new Array(OPS.length + DIMS.length + RUNGS.length + 2).fill(0), n = Math.max(1, parts.length);
  for (const p of parts) {
    const o = OPS.indexOf(p.op); if (o >= 0) v[o] += 1 / n;
    const d = DIMS.indexOf(p.dim); if (d >= 0) v[OPS.length + d] += 1 / n;
    const r = RUNGS.indexOf(p.rung); if (r >= 0) v[OPS.length + DIMS.length + r] += 1 / n; }
  v[v.length - 2] = Math.min(1, scale / 4); v[v.length - 1] = coherence; return v;
}
export const cosine = (a, b) => { let d = 0, x = 0, y = 0; for (let i = 0; i < a.length; i++) { d += a[i] * b[i]; x += a[i] * a[i]; y += b[i] * b[i]; } return x && y ? d / Math.sqrt(x * y) : 0; };
const partOf = (O, m) => ({ op: gateFunction(m.gate).op, dim: dimOf(O, m.unit), rung: m.climb?.landed ?? null });
const leading = (xs) => { const c = {}; for (const x of xs) if (x) c[x] = (c[x] ?? 0) + 1; return Object.entries(c).sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1))[0]?.[0] ?? "none"; };

/** Classify one regulated formation (recursion.regulate's output) and feed back. Memory lives in O.arcadia. */
export function coordinate(O, reg, { formationId, outward = false, learned = null } = {}) {
  const A = (O.arcadia ??= { kinds: [], seen: {} });
  const parts = reg.members.map(m => partOf(O, m)), whole = vec(parts, reg.scale, reg.coherence);
  // BEING: nearest known kind
  let best = null, sim = -1; for (const k of A.kinds) { const s = cosine(whole, k.centroid); if (s > sim) { sim = s; best = k; } }
  let kind, isNew = false;
  if (best && sim >= ARCADIA.same) { kind = best; const n = kind.count; kind.centroid = kind.centroid.map((c, i) => (c * n + whole[i]) / (n + 1)); kind.count++; }
  else { isNew = true; const base = `${leading(parts.map(p => p.op))}·${leading(parts.map(p => p.dim))}·${leading(parts.map(p => p.rung))}`;
    const taken = A.kinds.filter(k => k.name === base || k.name.startsWith(base + "·")).length, name = taken ? `${base}·${taken + 1}` : base;
    kind = { id: `kind.${A.kinds.length + 1}`, name, centroid: whole, count: 1, formations: [], carriers: [], history: [] }; A.kinds.push(kind); }
  if (formationId && !kind.formations.includes(formationId)) kind.formations.push(formationId);
  // PARTS: each member against the whole
  const align = reg.members.map((m, i) => cosine(vec([parts[i]], m.scale ?? reg.scale, m.climb?.cascade ? 1 : 0), whole));
  const mean = align.reduce((a, b) => a + b, 0) / Math.max(1, align.length);
  const members = reg.members.map((m, i) => ({ unit: m.unit, op: parts[i].op, dimension: parts[i].dim, landed: parts[i].rung, alignment: +align[i].toFixed(3),
    sits: align[i] >= mean ? "core" : "edge", role: m.role, scale: m.scale }));
  const inner = (reg.subclusters ?? []).map(s => ({ cluster: s.cluster, via: s.via, as: "inner whole", link: s.link?.landed ?? null }));
  // EXPRESS: from this kind's own history
  const prev = kind.history.at(-1); let expresses;
  if (!prev) expresses = "forming";
  else if (reg.coherence < prev.coherence - ARCADIA.drop) expresses = "breaking";
  else if (prev.expresses === "breaking") expresses = "regenerating";
  else expresses = "holding";
  kind.history.push({ formation: formationId ?? null, coherence: reg.coherence, expresses, outward });
  // FEEDBACK: carriers of this kind share what this formation's members learned
  const here = [...new Set(reg.members.map(m => m.unit))];
  for (const id of here) if (!kind.carriers.includes(id)) kind.carriers.push(id);
  let shared = 0;
  // only what this formation just taught (learned: unit|op -> gain, from learnFrom), never a unit's whole craft again
  for (const [key, gain] of learned ?? []) { if (!gain) continue; const op = key.slice(key.indexOf("|") + 1);
    for (const c of kind.carriers) { if (here.includes(c)) continue; const v = O.S.units[c]; if (!v || v.broken) continue;
      (v.craft ??= {})[op] = (v.craft[op] ?? 0) + gain * ARCADIA.share; shared++; } }
  return { kind: kind.id, name: kind.name, new: isNew, similarity: +Math.max(0, sim).toFixed(3), being: kind.name,
    parts: { core: members.filter(m => m.sits === "core").length, edge: members.filter(m => m.sits === "edge").length, inner: inner.length, members, inner },
    expresses, outward, sharedTo: shared, kinds: A.kinds.length };
}

/** What learnFrom just added, per unit|op, by comparing craft before and after. */
export const craftOf = (O, reg) => new Map(reg.members.map(m => [`${m.unit}|${m.op}`, O.S.units[m.unit]?.craft?.[m.op] ?? 0]));
export const gained = (O, reg, before) => new Map([...craftOf(O, reg)].map(([k, v]) => [k, v - (before.get(k) ?? 0)]).filter(([, d]) => d > 0));

/** Add Arcadia to morphogenesis's after-learn layers (once). Usage: import { AFTER_LEARN } from "./morphogenesis.js"; installArcadia(AFTER_LEARN). */
export function installArcadia(hooks) {
  if (hooks.some(h => h.name === "arcadia")) return false;
  hooks.push({ name: "arcadia", before: (O, reg) => ARCADIA.on ? craftOf(O, reg) : null,
    after: (O, reg, { formationId, outward, before, say }) => { if (!ARCADIA.on || !before) return;
      const a = coordinate(O, reg, { formationId, outward, learned: gained(O, reg, before) }); O.lastArcadia = a;
      say("arcadia", { kind: a.kind, being: a.being, new: a.new, similarity: a.similarity, core: a.parts.core, edge: a.parts.edge, inner: a.parts.inner, expresses: a.expresses, sharedTo: a.sharedTo, kinds: a.kinds }); } });
  return true;
}

/** For saving with the rest of what the swarm acquired (recursion.extractSwarm leaves this out; carried separately). */
export const extractArcadia = O => JSON.parse(JSON.stringify(O.arcadia ?? { kinds: [], seen: {} }));
export const adoptArcadia = (O, a) => { O.arcadia = JSON.parse(JSON.stringify(a)); return O.arcadia.kinds.length; };
