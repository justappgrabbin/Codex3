# v64n — the crystals, built from the Locked Architecture Spec §3.1, perspective bound (Nov 26)

v64m is kept as it was. v64n = v64m + `crystals.js` + `test_crystals.mjs` + one switch in `living.js` (CRYSTALS, off by default)
+ an optional `perspective` in `dual.twoSides`. With the switch off the swarm moves exactly as v64m's did, step for step.

## From the paper (Drive "language contact model — Locked Architecture Spec")
- §3.1 four-corner diamond: Mind/Evolution top left, Ego/Design top right, Body/Being bottom left, Individuality/Movement bottom right.
- §3.1 edges "generated live by intermingling the two corner dimensions they sit between"; Speed/Civilisation, Force/Friction,
  Material/Humanity, Position/Earth are reference names to check against, never an assignment.
- §3.1 Space emergent at the centre "through the interplay of the other four dimensions", no substance of its own.
- §0 the Personality Crystal (Evolution + Space) and the Design Crystal (Being + Design) are groupings; the Monopole (Movement,
  unpaired) is where intermingling connects outward. §0: build meaning as intermingling (>= 2 inputs), not a lookup.
- §2 channels emerge by Hamming 1, checked at each level on its own. §4.0 and §1.5: a reading is filtered through the reader.

## Glued, not rebuilt
The diamond, edges, diagonals and crystal membership come from the build's canon (codex3 state-space-canon.js). The bond operator
is the swarm's own NAND. dual.js PAIR and the v64k axis are unchanged.

## Built
- `intermingle(A, B)`: NAND of the two hexagrams, which levels agree (earth/human/heaven), channels at gate level and at
  colour/tone/base level separately, and the edge with its two reference names (or the diagonal through Space).
- Space = the two diagonals (Evolution×Movement, Design×Being) intermingled. Every corner can change it.
- Personality Crystal = Evolution × Space (so it feels the whole diamond); Design Crystal = Being × Design.
- The Monopole connects outward wherever a Movement unit's gate is within Hamming 1 of a crystal's result. Keynote "I Define".
- Perspective bound: `diamondFrom(reader)` turns the diamond so the reader takes the Monopole's place (bottom right); corners keep
  their order round the square, so the same four edges exist from every view but sit on different lines (different reference
  names), and each edge's result is read once more through the reader's own input. Space reads without turning.
- `dual.twoSides(units, { perspective })` pairs by the reader's rows when given one; without it, PAIR as before.

## How it sits with the v64k axis turn
- From Movement the rows are Movement-Being and Design-Evolution: the same pairs as the v64k axis, dual.js PAIR, and what
  Celestial read ("movement being design evolution"). No conflict there.
- From Being the rows become Being-Evolution and Design-Movement. The agent's axis does not turn with the reader yet; it stays the
  Movement view. Not built (don't build ahead).
- In the diamond Movement and Being share an edge (Force/Friction); on the v64k agent they sit at the two tips of one axis. Different
  layers (meaning vs body geometry), so I read it as tension, not a code conflict. Flagged.

## Checks
test_crystals 32/32, all 15 suites plus Arcadia green both ways.
NAND's own law: an all-yin corner (gate 2) leaves its diagonal partner nothing to change. Shown in a test, not hidden.
