#!/bin/sh
# run_all.sh — every test, without Arcadia and with it. Prints each suite's result and seconds; exits 1 if anything failed.
# The "switch off = the earlier swarm" checks read the earlier builds from regression-baselines/ (or $SYNTHIA_BASELINES).
cd "$(dirname "$0")"; bad=0
for t in test_recursion test_two_places test_lack test_mesh test_pagemorph test_fagan test_tiling test_dual test_governor test_ask test_axis test_dualswarm test_social test_cross test_crystals; do
  s=$(date +%s); node $t.mjs > $t.out.txt 2>&1 || bad=1; a=$(tail -n1 $t.out.txt); m=$(date +%s)
  node run_with_arcadia.mjs $t.mjs > $t.arcadia.out.txt 2>&1 || bad=1; b=$(tail -n1 $t.arcadia.out.txt); e=$(date +%s)
  echo "$t | without Arcadia: $a ($((m-s))s) | with: $b ($((e-m))s)"
done
s=$(date +%s); node test_arcadia.mjs > test_arcadia.out.txt 2>&1 || bad=1; echo "test_arcadia | $(tail -n1 test_arcadia.out.txt) ($(( $(date +%s)-s ))s)"
grep -l "FAIL" *.out.txt >/dev/null 2>&1 && grep -h "^  FAIL" *.out.txt && bad=1
[ $bad = 0 ] && echo "ALL GREEN" || echo "SOMETHING FAILED"; exit $bad
