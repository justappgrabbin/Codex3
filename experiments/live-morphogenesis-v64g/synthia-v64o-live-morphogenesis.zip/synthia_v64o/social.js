// social.js — social system laws as swarm conditions (v64m, Nov 26).
// Celestial's ask: "Multiply and dissolve by mood, connections weighted 1 to 5, inheritance by chance, crowding brakes, and the
// mood law: interpretation × relationship weight."
// SOURCE (ported, not invented): the Social Game System (MIT, Java: Center.java, Giocatore.java, Carattere.java), which they
// pointed to. Numbers below are that code's own:
//   mood starts at 50; on each message received: mood += interpretation * importance / divisor          (Giocatore.Assimila_messaggio)
//   mood >= 100: a child if children < 3, then mood -= 50; mood <= 0 or the day of death: dies          (AggiornaGiocatore)
//   day of death = random(20) + max age; importance starts at the crowding value, range 1-5, re-weighed every 5th message,
//   the tie breaks below 1                                                                                (ValoreInterazione, ControllaAmicizia)
//   new ties: 60% of the population get a chance each day; a tie forms if two draws in -5..5 are both >= 0 (Crea_Amicizia)
//   the child copies the parent's vocabulary; its character is drawn from the list of all characters plus
//   (characters/4) extra copies of the parent's (inheritance by chance)                                   (Nascita, CompilaListe)
//   crowding brakes by population: over 10000 -> divisor 4, max age 30, start importance 2; under 100 -> 2, 60, 3;
//   otherwise 3, 50, 2.5                                                                                  (Center.Controlli)
// TRANSLATED to the swarm (MY PICKS, each marked; change freely):
//   - a message = the instruction the sender is running now (its ASCII opcode). The receiver's VOCABULARY holds what each
//     instruction means to it. A word heard for the first time gets its meaning from the resonance of that first contact
//     (bond count c of 0..5 -> 2c - 5, so -5..5), where the game draws it at random. This keeps their earlier law
//     "mood is how in resonance it is" (rule_world.js) inside the new one.
//   - "character" = the unit's dimension (each dimension reads its own way); a child's dimension is drawn from the four
//     primaries plus floor(4/4) = 1 extra copy of the parent's, so the parent's comes back 2 times in 5. Space is never drawn
//     (it results from the four).
//   - the child's address is the hash of the parent with its strongest tie (living.combine, the doc's deterministic mutation);
//     it is born next to the parent and copies its vocabulary and what it acquired.
//   - re-weighing every 5th message: importance += mean of the last 5 interpretations / 5 (the game does this per character;
//     its "random" character adds a random -0.5..0.5). Capped at 5.
//   - messages travel along a tie only while the two are within sight of each other; new ties form only with units in contact.
//   - a person's own unit never dissolves (living.js already never breaks a person); its children are movers.
//   - one swarm step = one day. All draws come from this society's own seeded generator, so a run repeats exactly and the
//     swarm's own generator is untouched.
import { combine, PRIMARIES, SETTINGS } from "./living.js";
import * as OPS from "./bhantugh_ops.js";

export const SOCIAL = { START_MOOD: 50, BIRTH_AT: 100, BIRTH_COST: 50, CHILDREN: 3, AGE_SPREAD: 20, NEW_TIE_SHARE: 0.6,
  REWEIGH_EVERY: 5, MIN_WEIGHT: 1, MAX_WEIGHT: 5, PERSONS_DISSOLVE: false,
  CROWDED_OVER: 10000, SPARSE_UNDER: 100 };   // the game's thresholds; the living page slows past about a thousand units, so lower them there if needed
/** Crowding brakes (Center.Controlli). */
export function brakes(population) {
  if (population > SOCIAL.CROWDED_OVER) return { crowd: "high", divisor: 4, maxAge: 30, startWeight: 2 };
  if (population < SOCIAL.SPARSE_UNDER) return { crowd: "low", divisor: 2, maxAge: 60, startWeight: 3 };
  return { crowd: "default", divisor: 3, maxAge: 50, startWeight: 2.5 };
}
/** First-contact meaning of a word: the contact's resonance count, 0..5 -> -5..5. */
export const meaningOf = (a, b) => 2 * OPS.evaluateSwarmBond(a.address, b.address).connectionCount - 5;
/** Inheritance by chance: the list every character is drawn from (CompilaListe). */
export const dominantList = (parentDim, all = PRIMARIES) => [...all, ...Array(Math.floor(all.length / 4)).fill(parentDim)];

export class Society {
  constructor(swarm, { seed = 1 } = {}) {
    this.S = swarm; swarm.society = this; let s = (seed * 2654435761) >>> 0;
    this.rand = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32);
    this.int = n => Math.floor(this.rand() * n);
    this.day = 0; this.events = []; this.log = [];
    this.brake = brakes(this.alive().length);
    for (const u of swarm.units) this.enter(u);
  }
  alive() { return this.S.units.filter(u => !u.broken); }
  enter(u) { if (u.soc) return u.soc;
    return u.soc = { mood: SOCIAL.START_MOOD, born: this.day, deathAge: this.int(SOCIAL.AGE_SPREAD) + this.brake.maxAge, children: 0, ties: new Map(), vocab: new Map() }; }
  /** Two units become tied (both sides, the crowding start weight). */
  tie(a, b) { if (a.soc.ties.has(b.id)) return false; const w = this.brake.startWeight;
    a.soc.ties.set(b.id, { weight: w, heard: [] }); b.soc.ties.set(a.id, { weight: w, heard: [] }); this.events.push({ day: this.day, type: "tie", a: a.id, b: b.id }); return true; }
  untie(a, b, why) { a.soc.ties.delete(b.id); b.soc?.ties.delete(a.id); this.events.push({ day: this.day, type: "untie", a: a.id, b: b.id, why }); }
  /** The receiver hears a word from the sender: meaning from its vocabulary (learned on first hearing), then the mood law. */
  hear(to, from, word) {
    const t = to.soc.ties.get(from.id); if (!t) return null;
    let m = to.soc.vocab.get(word); if (m == null) { m = meaningOf(to, from); to.soc.vocab.set(word, m); }
    t.heard.push(m); const before = to.soc.mood;
    to.soc.mood += m * t.weight / this.brake.divisor;                                    // mood law: interpretation x relationship weight
    if (t.heard.length % SOCIAL.REWEIGH_EVERY === 0) { const last = t.heard.slice(-SOCIAL.REWEIGH_EVERY);
      t.weight = Math.min(SOCIAL.MAX_WEIGHT, t.weight + last.reduce((s, x) => s + x, 0) / last.length / 5); }
    return { word, meaning: m, weight: t.weight, before, after: to.soc.mood };
  }
  /** One day (one swarm step). */
  tick() {
    const S = this.S; this.day++; this.brake = brakes(this.alive().length);
    for (const u of S.units) if (!u.broken) this.enter(u);
    // new ties: 60% of the living get a chance, each with one unit it is touching now
    const L = this.alive(); for (let i = L.length - 1; i > 0; i--) { const j = this.int(i + 1); [L[i], L[j]] = [L[j], L[i]]; }
    for (const u of L.slice(0, Math.floor(L.length * SOCIAL.NEW_TIE_SHARE))) {
      const nb = u.bonds.map(e => S.units[e.a === u.id ? e.b : e.a]).filter(o => !o.broken && !u.soc.ties.has(o.id)); if (!nb.length) continue;
      const o = nb[this.int(nb.length)], a = this.int(11) - 5, b = this.int(11) - 5; if (a >= 0 && b >= 0) this.tie(u, o); }
    // social life: each tie within sight exchanges one message each way
    const word = u => u.program[Math.floor(S.t) % (u.program.length || 1)] ?? u.opcode?.act ?? "silence";
    for (const u of this.alive()) for (const [id] of [...u.soc.ties]) { const o = S.units[id]; if (!o || o.broken || id < u.id) continue;
      if (Math.hypot(o.x - u.x, o.y - u.y) > SETTINGS.SIGHT) continue;
      this.hear(o, u, word(u)); this.hear(u, o, word(o));
      for (const [x, y] of [[u, o], [o, u]]) { const t = x.soc.ties.get(y.id); if (t && t.weight < SOCIAL.MIN_WEIGHT) this.untie(x, y, "weight below 1"); } }
    // multiply and dissolve by mood (and age)
    for (const u of this.alive()) {
      if (u.soc.mood >= SOCIAL.BIRTH_AT) { if (u.soc.children < SOCIAL.CHILDREN) this.birth(u); u.soc.mood -= SOCIAL.BIRTH_COST; }
      else if (u.soc.mood <= 0 || this.day - u.soc.born >= u.soc.deathAge) this.dissolve(u, u.soc.mood <= 0 ? "mood" : "age"); }
    this.log.push({ day: this.day, alive: this.alive().length, crowd: this.brake.crowd });
    return this;
  }
  birth(p) {
    const best = [...p.soc.ties].sort((x, y) => y[1].weight - x[1].weight || x[0] - y[0])[0], mate = best ? this.S.units[best[0]] : p;
    const ch = combine(p, mate), L = dominantList(p.address.dimension), dimension = L[this.int(L.length)];
    const addr = { ...ch, dimension }; delete addr.hash;
    const kind = p.kind === "person" ? "mover" : p.kind, ang = this.rand() * 2 * Math.PI;
    const c = this.S.add(addr, kind, Math.min(1, Math.max(0, p.x + 0.02 * Math.cos(ang))), Math.min(1, Math.max(0, p.y + 0.02 * Math.sin(ang))));
    this.enter(c); for (const [w, m] of p.soc.vocab) c.soc.vocab.set(w, m);               // the child copies the parent's vocabulary
    for (const a of p.acquired ?? []) c.acquired.add(a); for (const [k, v] of p.transforms ?? []) c.transforms.set(k, v);
    c.parent = p.id; p.soc.children++;
    this.events.push({ day: this.day, type: "birth", parent: p.id, mate: mate.id, child: c.id, dimension, from: p.address.dimension });
    return c;
  }
  dissolve(u, cause) {
    if (u.kind === "person" && !SOCIAL.PERSONS_DISSOLVE) return false;
    u.broken = true; this.S.loose.push({ from: u.id, address: u.address, t: this.S.t });
    for (const [id] of [...u.soc.ties]) { const o = this.S.units[id]; if (o?.soc) o.soc.ties.delete(u.id); } u.soc.ties.clear();
    this.events.push({ day: this.day, type: "dissolve", unit: u.id, cause }); this.S.events.push({ t: this.S.t, type: "dissolve", unit: u.id, cause });
    return true;
  }
}
