# v64m — social system laws as swarm conditions (Nov 26)

v64l is kept as it was. v64m = v64l + `social.js` + `test_social.mjs` + one line in `living.js` step:
`if (this.society) this.society.tick();` — with no Society attached the swarm moves exactly as v64l's (tested).

## Checked first (what already existed)
- rule_world.js: mood = resonant contacts / all contacts ("mood is how in resonance it is"). Kept; social.js builds on it
  (a word's first meaning comes from the resonance of first contact).
- Consciousness Realm (Swarm World / EmbodiedWorldEngine): needs (energy, connection, growth, purpose, rest), random
  relationships (friend/mentor/student/partner, strength 20); "belief" there is the kernel's HMM state, not beliefs about
  each other. No mood-driven births, deaths, weighted ties or crowding brakes anywhere. So the laws were ported, not reinvented.

## Source
The Social Game System (MIT, Java) Celestial pointed to: Center.java, Giocatore.java, Carattere.java. Its own numbers are used.

## The laws (all in SOCIAL / brakes(), settings not hard-codes)
- Mood starts at 50. Each message heard: mood += meaning x tie weight / divisor.
- Mood >= 100: a child if fewer than 3, then mood -50. Mood <= 0 or past its day of death (random 0-19 + max age): dissolves.
- Ties start at the crowding weight, re-weighed every 5th message by the mean of the last 5 / 5, capped at 5, break below 1.
- New ties: 60% of the living get a chance each day with one unit they're bonded to; forms if two draws in -5..5 are both >= 0.
- Inheritance by chance: the child's dimension is drawn from the four primaries plus one extra copy of the parent's (2 in 5).
- Crowding brakes: under 100 -> divisor 2, max age 60, start weight 3; over 10000 -> 4, 30, 2; else 3, 50, 2.5.
  Thresholds are settings (CROWDED_OVER, SPARSE_UNDER); the living page slows past about a thousand units.

## My picks (marked in the file's header)
- A message is the instruction the sender is running now; "character" is the unit's dimension; one step = one day;
  messages only travel within sight; the child's address = hash of parent + strongest tie; persons never dissolve,
  their children are movers. The society has its own seeded generator, so the swarm's own draws are untouched.

## Body pairs steer movement (opp.js, switch CROSS_STEER, off by default)
- Glued as it was from the research build: the PAIR table (Sun-Earth, Nodes, Moon-Mercury, Venus-Mars, Jupiter-Saturn,
  Uranus-Neptune, Pluto unpaired) and crossOf (fixed pair, relative axes: facing up, your own body is the vertical arm;
  facing sideways, the pair swaps). The OPP now carries the cross. bhantugh_rules.json got the bodyPairs block back
  (identical to the research build's rules now); a test checks the table and the rule book agree.
- Fix: charts write "North Node", the table "NorthNode"; names are matched without spaces.
- Each dimension's mark, from Celestial's words (Nov 26) "being moves across ... movement moves upward":
  Movement steps on the vertical arm, Being across. Design, Evolution and Space weren't described, so they have no mark
  and move on the arm their own body is on for the way they're going. Pluto has one arm and keeps to it.
- Steering (my pick): the unit's own move for the step keeps its length and its sign along the chosen arm; the other
  part is dropped. Only free movers and persons; units holding a picture and the words mode are not steered.
- With the switch off the swarm is v64l's, step for step (tested).

## Becoming and embodying (no reality layer)
- Already there: morph.js (units take the role of what the host needs, find the behaviour, clone, integrate, leave),
  morphogenesis.js (the developmental cycle) and governor.js (kind, the stage it's becoming, how it expresses).
- Glued: after a formation is governed, each member unit now carries `u.becoming` (kind, now, toward, stage, phase, mode,
  core/edge, lean, whether it's the voice), so the knowing sits in the units, not only in the organism's last reading.

## Not done here
- Crystal pairing still waits on Celestial.
