// test_two_places.mjs — Celestial's item 1 (Nov 26): the SAME swarm in two places, a half-broken app and a small world.
// Each place shows only what is there, what can be done, and a health signal. The swarm must orient through its POP and
// find what is missing itself. Nothing below tells the swarm what to build; the checks only look at what it did.
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js"; import { World } from "./hostworld.js";
import { appPlace, worldPlace } from "./places.js"; import { settle, orient } from "./place.js";
import { setGateEngineData } from "./gate_engine.js"; import { readFileSync } from "node:fs";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const show = r => r.steps.forEach(s => console.log("     ", JSON.stringify(s).slice(0, 300))), st = (r, n) => r.steps.filter(s => s.step === n).at(-1), first = (r, n) => r.steps.find(s => s.step === n);
const D = ["Movement", "Evolution", "Being", "Design"], S = new LivingSwarm({ seed: 5 });
for (let i = 0; i < 48; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
const O = new OrganismSwarm(S); for (let t = 0; t < 5; t++) O.step();

console.log("Place 1 — a half-broken app (one feature works, one is missing; the app never says which)");
const app = appPlace([
  { path: "logic.js", text: "export function flip(a) { return a ? 0 : 1; }\n" },
  { path: "test_flip.js", text: "import { flip } from './logic.js';\nassert(flip(0) === 1);\nassert(flip(1) === 0);\n" },
  { path: "test_gate.js", text: "import { both } from './gate.js';\nassert(both(1,1) === 1);\nassert(both(1,0) === 0);\nassert(both(0,1) === 0);\nassert(both(0,0) === 0);\n" }], "half-broken app");
const h0 = app.health();
const rA = settle(O, app); show(rA);
const oA = st(rA, "orient"), dA = first(rA, "discover");
ok(`health before: ${h0} (half works)`, h0 === 0.5);
ok(`the swarm oriented: saw ${oA.seen} of ${oA.items} items after ${oA.orientRounds} round(s) of moving toward what it couldn't see`, oA.seen === oA.items);
ok(`it found what is missing itself: a gap '${dA.gap?.name}' in ${dA.gap?.from}, ${dA.gap?.arity} bits, noticed by units ${dA.gap?.noticedBy}`, dA.kind === "gap" && dA.gap.name === "both" && dA.gap.from === "gate.js");
ok(`it set its own aim from health (${st(rA, "aim")?.healthNow} → at least ${st(rA, "aim")?.aim})`, st(rA, "aim")?.aim > h0);
ok(`it built the missing piece with its units (${st(rA, "act+evaluate")?.plan?.join(" → ")}) and the app is whole: health ${rA.healthAfter}`, rA.ok && rA.healthAfter === 1);
ok("with the swarm gone the app still runs whole", st(rA, "extract")?.checkWithSwarmGone === 1);
const rA2 = settle(O, app);
ok("back in the app once it's whole, the swarm finds nothing missing and rests", rA2.rested && first(rA2, "discover").kind === "nothing");

console.log("Place 2 — a small world (cold; its own check is low; nothing in it refers to anything missing)");
const PAL = [[20, 20, 20], [200, 40, 30], [40, 170, 60], [40, 80, 220], [230, 200, 40], [235, 235, 245]];
const W = new World({ name: "cold-valley", temperature: -5 }); W.palette = PAL;
const bright = c => (c[0] + c[1] + c[2]) / 3 > 200;
const world = worldPlace(W, { measure: W => { let n = 0; for (let x = 0; x < W.w; x++) if (bright(W.cells[(W.h - 1) * W.w + x])) n++; return W.temperature < 0 ? n / W.w : 1; } });
const w0 = world.health();
const rW = settle(O, world); show(rW);
const dW = first(rW, "discover");
ok(`health before: ${w0}`, w0 < 0.5);
ok("the same swarm finds no gap here and goes by health instead", dW.kind === "low-health");
ok(`it raised the world's own health to ${rW.healthAfter} through what can be done there (${JSON.stringify(rW.applied)})`, rW.ok && rW.healthAfter > w0 && rW.healthAfter >= st(rW, "aim").aim);
console.log("Orientation when the swarm can't see the place at first (a thin swarm of 6 units, same rules)");
const S6 = new LivingSwarm({ seed: 9 }); for (let i = 0; i < 6; i++) S6.add({ gate: 10 + i * 7, line: 1 + i % 6, color: 1 + (i * 2) % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.2 + i * 0.12, 0.5 + (i % 2) * 0.1);
const O6 = new OrganismSwarm(S6); for (let t = 0; t < 3; t++) O6.step();
const app6 = appPlace([
  { path: "logic.js", text: "export function flip(a) { return a ? 0 : 1; }\n" },
  { path: "test_flip.js", text: "import { flip } from './logic.js';\nassert(flip(0) === 1);\nassert(flip(1) === 0);\n" },
  { path: "util.js", text: "export function same(a) { return a; }\n" },
  { path: "test_same.js", text: "import { same } from './util.js';\nassert(same(1) === 1);\n" },
  { path: "test_gate.js", text: "import { either } from './gate.js';\nassert(either(1,1) === 1);\nassert(either(1,0) === 1);\nassert(either(0,1) === 1);\nassert(either(0,0) === 0);\n" }], "half-broken app, thin swarm");
const r6 = settle(O6, app6); show(r6.steps.length ? r6 : { steps: [] });
const o6 = first(r6, "orient"), d6 = first(r6, "discover");
ok(`it started half-blind and moved toward what it couldn't see (rounds: ${JSON.stringify(o6.rounds)}), ending with ${o6.seen} of ${o6.items} seen`, o6.orientRounds > 0 && o6.rounds[0].blind > 0 && o6.blind.length === 0);
ok(`it still found the gap itself (${d6.gap?.name ?? d6.kind}) once the item that holds it came into sight`, d6.kind === "gap" && d6.gap.name === "either");
ok(`and built it: health ${app6.health()}`, r6.ok && r6.healthAfter === 1);
ok("the swarm-side code names no place, task or answer", !/both|either|gate\.js|snow|bright|cold|flip/i.test(readFileSync(new URL("./place.js", import.meta.url), "utf8")));
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
