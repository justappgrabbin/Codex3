// run_with_arcadia.mjs — run any test with Arcadia installed:  node run_with_arcadia.mjs test_recursion.mjs
// Plain "node test_x.mjs" runs without Arcadia (it is an optional layer). Run both to see the swarm with and without it.
import { AFTER_LEARN } from "./morphogenesis.js"; import { installArcadia } from "./arcadia.js";
installArcadia(AFTER_LEARN);
await import(new URL("./" + process.argv[2], import.meta.url));
