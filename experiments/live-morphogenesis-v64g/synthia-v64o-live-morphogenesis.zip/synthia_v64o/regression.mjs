// regression.mjs — where the earlier builds live for the "switch off = the old swarm" checks, and how two swarms are compared.
// v64o (Nov 26). The baselines are the genuine earlier builds' own files (living.js and everything it loads), copied unchanged
// from the saved synthia_v64k / v64l / v64m into regression-baselines/. Point SYNTHIA_BASELINES at another folder to use a
// different copy. A missing baseline is a failed check, never a pass.
import { existsSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import { join } from "node:path";
const HERE = fileURLToPath(new URL(".", import.meta.url));
export const BASELINES = process.env.SYNTHIA_BASELINES ?? join(HERE, "regression-baselines");
/** The baseline's living.js as an importable URL, or null when it isn't there. */
export function baseline(version) { const p = join(BASELINES, `synthia_${version}`, "living.js"); return existsSync(p) ? pathToFileURL(p).href : null; }
const bondsOf = u => u.bonds.map(e => [Math.min(e.a, e.b), Math.max(e.a, e.b)].join("-")).sort().join();
const addressOf = u => { const { hash, ...a } = u.address ?? {}; return JSON.stringify(a, Object.keys(a).sort()); };
/** Every way two swarms can differ: count, then per unit position, health, broken, address, bonds, what it acquired,
 *  what it learned to do (transforms), its program and its kind. Returns the list of differences (empty = the same swarm). */
export function differences(a, b) {
  const d = []; if (a.units.length !== b.units.length) return [`unit count ${a.units.length} vs ${b.units.length}`];
  a.units.forEach((u, i) => { const v = b.units[i], w = [];
    if (u.x !== v.x || u.y !== v.y) w.push("position"); if (u.health !== v.health) w.push("health"); if (!!u.broken !== !!v.broken) w.push("broken");
    if (u.kind !== v.kind) w.push("kind"); if (addressOf(u) !== addressOf(v)) w.push("address"); if (bondsOf(u) !== bondsOf(v)) w.push("bonds");
    if ([...(u.acquired ?? [])].sort().join() !== [...(v.acquired ?? [])].sort().join()) w.push("acquired");
    if ([...(u.transforms?.keys() ?? [])].sort().join() !== [...(v.transforms?.keys() ?? [])].sort().join()) w.push("learned");
    if ((u.program ?? []).join() !== (v.program ?? []).join()) w.push("program");
    if (w.length) d.push(`unit ${i}: ${w.join(", ")}`); });
  return d;
}
