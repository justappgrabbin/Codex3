// test_pagemorph.mjs — the page is the swarm (v64h, Nov 26). Run plain (Arcadia absent) and: node run_with_arcadia.mjs test_pagemorph.mjs
//   1 stated need alone re-forms the page   2 birth chart alone   3 both agree: no questions
//   4 they disagree: the dimensions ask yes/no, and the answers change the form   5 over repeated use it stops asking
//   6 "tell it what to become" still works with everything else off or broken   7 switches   8 birth data never enters
import { readFileSync } from "node:fs"; import { setGateEngineData } from "./gate_engine.js";
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js"; import { AFTER_LEARN } from "./morphogenesis.js";
import { PAGE, decide, answer, compose, render, newPerson, formOfGate } from "./pagemorph.js"; import { fourCharts } from "./charts.js";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); const V = J("./vocabulary.json"); setGateEngineData(V, J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
console.log(`Arcadia ${AFTER_LEARN.some(h => h.name === "arcadia") ? "installed" : "absent"}`);
const D = ["Movement", "Evolution", "Being", "Design"];
const swarm = () => { const S = new LivingSwarm({ seed: 5 });
  for (let i = 0; i < 64; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.1 + (i % 8) * 0.11, 0.1 + Math.floor(i / 8) * 0.11);
  const O = new OrganismSwarm(S); for (let t = 0; t < 3; t++) O.step(); return O; };
const O = swarm(), show = p => `${p.form}: ${p.regions.map(r => `${r.kind}(${r.share}, op ${r.op}, ${r.carriers?.length ?? 0} units)`).join(" | ")}`;
// the person's addresses are worked out here, on the device; only the addresses go to the page
const addresses = Object.values(fourCharts({ date: "1990-06-15", time: "09:30", zone: "America/Chicago" }).charts).flatMap(c => c.addresses);
const LEARN = "teach me the details of the formula", WORLD = "explore a world and wander through it", AGREE = "I want to learn how to understand and study ideas";

console.log("1 — tell it what to become (stated need alone)");
const pL = compose(O, decide({ say: LEARN }, newPerson(), { vocab: V })), pW = compose(O, decide({ say: WORLD }, newPerson(), { vocab: V }));
console.log("     " + show(pL)); console.log("     " + show(pW));
ok(`"${LEARN}" forms a ${pL.form} page; "${WORLD}" forms a ${pW.form} page`, pL.form && pW.form && pL.form !== pW.form);
ok("the page re-forms: different regions and different HTML from the same swarm", render(pL) !== render(pW) && JSON.stringify(pL.regions.map(r => r.kind)) !== JSON.stringify(pW.regions.map(r => r.kind)));
ok("every region is carried by the swarm's own units and shows what they are", [...pL.regions, ...pW.regions].every(r => r.carriers.length && r.carriers.every(id => O.S.units[id])));
const src = readFileSync(new URL("./pagemorph.js", import.meta.url), "utf8").replace(/^\s*\/\/.*$/gm, "");
ok("pagemorph.js holds no screen: no ids, no fixed layout, no named pages", !/id=|getElementById|<header|<nav|lesson|world page|class=/.test(src));

console.log("2 — noticed need alone (the person's chart, from birth time and place)");
const pB = compose(O, decide({ addresses }, newPerson(), { vocab: V })); console.log("     " + show(pB));
ok(`their chart alone forms a ${pB.form} page`, !!pB.form && pB.regions.length >= 1);

console.log("3 — both, and they agree");
const dA = decide({ say: AGREE, addresses }, newPerson(), { vocab: V });
ok(`"${AGREE}" and the chart both lead to ${dA.form}: no questions`, dA.form && !dA.ask && dA.why === "stated and noticed agree");

console.log("4 — both, and they disagree: the dimensions ask");
const P1 = newPerson(), dQ = decide({ say: LEARN, addresses }, P1, { vocab: V }), qp = compose(O, dQ);
for (const q of dQ.ask ?? []) console.log(`     ${q.dimension.padEnd(9)} asks ${q.asks.padEnd(5)} ${q.text}`);
ok("the page becomes questions", qp.form === "questions" && dQ.ask?.length >= 2);
ok("each is a yes/no question from one dimension, in its own frame", dQ.ask.every(q => ({ Space: "who", Movement: "where", Evolution: "what", Being: "when", Design: "why" })[q.dimension] === q.asks) && /Yes<\/button><button data-answer="no">No/.test(render(qp)));
ok("only dimensions where the two sides differ ask", dQ.ask.every(q => q.yes.v !== q.no.v));
const all = v => Object.fromEntries(dQ.ask.map(q => [q.id, v]));
const yes = answer(dQ, all("yes"), newPerson(), { vocab: V }), no = answer(dQ, all("no"), newPerson(), { vocab: V });
console.log(`     all yes -> ${yes.form} (${yes.why});  all no -> ${no.form} (${no.why})`);
ok("the answers change the form the page takes", yes.form && no.form && yes.form !== no.form);
ok(`all yes lands on what they said (${dQ.a.form}), all no on what their chart leans to (${dQ.b.form})`, yes.form === dQ.a.form && no.form === dQ.b.form);
const words = answer(dQ, { words: "I want to read and understand the details" }, newPerson(), { vocab: V });
ok(`they can answer in their own words too (-> ${words.form})`, !!words.form);
const P2 = newPerson(); answer(dQ, all("yes"), P2, { vocab: V });
ok("Space's answer (who they are now) joins their live state", P2.now.length === 1 && P2.now[0] === dQ.a.gate);

console.log("5 — over repeated use it becomes what they come for, and stops asking");
const P = newPerson(); let asked = 0, settledAt = null;
for (let use = 1; use <= 12; use++) { const d = decide({ say: LEARN, addresses }, P, { vocab: V });
  if (d.ask) { asked++; compose(O, answer(d, Object.fromEntries(d.ask.map(q => [q.id, "yes"])), P, { vocab: V }), P); }
  else { compose(O, d, P); if (settledAt == null) settledAt = use; } }
console.log(`     asked on ${asked} of 12 visits; from visit ${settledAt} on it went straight to the page`);
ok("it asked at first, then stopped once it had learned the person", asked >= 1 && settledAt != null && settledAt <= 8);
ok("and the settled page is the form they kept choosing", decide({ say: LEARN, addresses }, P, { vocab: V }).form === yes.form);

console.log("6 — tell it what to become, with everything else off or broken");
const noUnits = compose(null, decide({ say: LEARN }, newPerson(), { vocab: V }));
ok(`no swarm at all: still a ${noUnits.form} page (${noUnits.regions.length} regions)`, noUnits.form === pL.form && noUnits.regions.length >= 1);
const broken = swarm(); broken.S.units.forEach(u => u.broken = true);
ok("every unit broken: still the same form", compose(broken, decide({ say: LEARN }, newPerson(), { vocab: V })).form === pL.form);
setGateEngineData(null, null); const noVocab = compose(O, decide({ say: LEARN }, newPerson())); setGateEngineData(V, J("./bhantugh_rules.json"));
ok(`no vocabulary loaded: the words still reach gates (gematria) and form a ${noVocab.form} page`, !!noVocab.form && noVocab.regions.length >= 1);
ok("no Arcadia, no mesh, no world needed (pagemorph imports none of them)", !/arcadia|mesh\.js|hostworld|places?\.js/.test(src));
ok("a broken chart (no addresses) doesn't stop the stated path", compose(O, decide({ say: WORLD, addresses: [null, {}] }, newPerson(), { vocab: V })).form === pW.form);

console.log("7 — switches");
PAGE.onDisagree = "stated"; const s1 = decide({ say: LEARN, addresses }, newPerson(), { vocab: V }).form;
PAGE.onDisagree = "noticed"; const s2 = decide({ say: LEARN, addresses }, newPerson(), { vocab: V }).form; PAGE.onDisagree = "ask";
ok(`onDisagree "stated" -> ${s1}, "noticed" -> ${s2}`, s1 === dQ.a.form && s2 === dQ.b.form);

console.log("8 — birth data stays on the device");
ok("pagemorph.js never reads a date, time or place", !/\bdate\b|\btime\b|zone|birth(Date|Time|Place)|fourCharts/.test(src.replace(/birthGates/g, "")));

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
