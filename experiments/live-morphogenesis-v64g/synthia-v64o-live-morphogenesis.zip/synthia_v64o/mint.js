// mint.js — one person's own page as one HTML file (v64j, Nov 26), the per-person file Celestial's third doc describes
// (hub + forge: the universal graph and the person's own state baked into one offline page). Here nothing new is built for it:
// the file is the morph page itself (morph.html + morph_app.js) with every module it uses and the system's own graph
// (vocabulary.json, lexicon.json, bhantugh_rules.json) carried inside it, plus that person's addresses and experience brain.
//   - the modules ride in an import map as data: URLs, so the page runs from a file with no server and no network
//   - the person's part is one JSON block: an id, their addresses (all four charts) and their person record (page memory and
//     experience brain). Birth date, time and place are never in the file; only the addresses worked out from them.
//   - "Keep my page" in a minted page writes the file out again with what it has learned (remint), from its own import map.
// Works in Node (to make the first file) and in the browser (to keep it). No bundler, no dependencies.

const PREFIX = "@synthia/";
const SPEC = /(\bfrom\s*|\bimport\s*\(\s*|\bimport\s+)(["'])(\.{1,2}\/[^"']+)\2/g;
const norm = p => { const out = []; for (const s of p.split("/")) { if (s === "..") out.pop(); else if (s && s !== ".") out.push(s); } return out.join("/"); };
const dir = p => p.includes("/") ? p.slice(0, p.lastIndexOf("/") + 1) : "";
const resolveFrom = (from, spec) => norm(dir(from) + spec);
const MIME = p => p.endsWith(".json") ? "application/json" : p.endsWith(".html") ? "text/html" : "text/javascript";

function b64(text) { if (globalThis.Buffer) return globalThis.Buffer.from(text, "utf8").toString("base64");
  const u = new TextEncoder().encode(text); let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); }
function unb64(s) { if (globalThis.Buffer) return globalThis.Buffer.from(s, "base64").toString("utf8");
  const bin = atob(s), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return new TextDecoder().decode(u); }

/** Every file the entries reach through relative imports (static, dynamic and JSON). read(path) -> text or null. */
export function closure(read, entries = ["morph_app.js"]) {
  const files = new Map(), missing = [], todo = [...entries];
  while (todo.length) { const p = norm(todo.pop()); if (files.has(p)) continue; const t = read(p); if (t == null) { missing.push(p); continue; }
    files.set(p, t); if (!p.endsWith(".js")) continue;
    for (const m of t.replace(/^\s*\/\/.*$/gm, "").matchAll(SPEC)) todo.push(resolveFrom(p, m[3])); }
  return { files, missing };
}

/** Rewrite a module's relative imports to the page's own names. */
export const rewrite = (path, text) => path.endsWith(".js") ? text.replace(SPEC, (_, a, q, s) => `${a}${q}${PREFIX}${resolveFrom(path, s)}${q}`) : text;

/** Make the file. sources: Map or object path -> text, including "morph.html". personal: { id, addresses, person }. */
export function mint(sources, personal) {
  const src = sources instanceof Map ? sources : new Map(Object.entries(sources)); const shell = src.get("morph.html");
  if (!shell) throw new Error("mint needs morph.html among the sources");
  const imports = {}; for (const [p, t] of src) imports[PREFIX + p] = `data:${MIME(p)};base64,${b64(rewrite(p, t))}`;
  const safe = JSON.stringify({ id: personal.id, addresses: personal.addresses ?? [], person: personal.person ?? null }).replace(/</g, "\\u003c");
  const head = `<script type="importmap">${JSON.stringify({ imports })}</script>\n<script type="application/json" id="personal">${safe}</script>\n`;
  return shell.replace(/<script type="module" src="\.\/morph_app\.js"><\/script>/, `${head}<script type="module">import "${PREFIX}morph_app.js";</script>`);
}

/** Read a minted page's own sources back out of its import map (browser: pass document; Node: pass the HTML text). */
export function sourcesOf(docOrHtml) {
  const raw = typeof docOrHtml === "string" ? docOrHtml.match(/<script type="importmap">([\s\S]*?)<\/script>/)?.[1] : docOrHtml.querySelector('script[type="importmap"]')?.textContent;
  const map = JSON.parse(raw ?? "{}").imports ?? {}, out = new Map();
  for (const [k, v] of Object.entries(map)) if (k.startsWith(PREFIX)) out.set(k.slice(PREFIX.length), unb64(v.slice(v.indexOf(",") + 1)));
  return out;
}
/** Write a minted page out again with its newest state. */
export const remint = (docOrHtml, personal) => mint(sourcesOf(docOrHtml), personal);
