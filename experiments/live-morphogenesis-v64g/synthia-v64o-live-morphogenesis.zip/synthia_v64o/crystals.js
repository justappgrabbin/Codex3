// crystals.js — the Crystals and the Monopole as intermingling functions (v64n, Nov 26).
// Built from Celestial's paper "language contact model — Locked Architecture Spec" (Drive 1YMqasm...):
//   §0  "Evolution+Space intermingle into the Personality Crystal, Being+Design intermingle into the Design Crystal; the Monopole
//        (Movement, unpaired) is the site where intermingling connects outward — the channel."
//   §0  "any new feature that computes 'what does X mean' should be built as an intermingling function (combining >=2 dimensional
//        inputs to produce a scale-appropriate interpretation), not a lookup or a single-dimension readout."
//   §3.1 four-corner diamond (Mind/Evolution top left, Ego/Design top right, Body/Being bottom left, Individuality/Movement bottom
//        right), Space emergent at the centre "through the interplay of the other four"; the edge connectors (Speed/Civilisation,
//        Force/Friction, Material/Humanity, Position/Earth) are "generated live by intermingling the two corner dimensions they
//        sit between", the named terms are a reference to check against, never the assignment.
//   §2  channels emerge by Hamming distance 1, checked at every structural level independently (gate; colour/tone/base).
// Glued, not rebuilt: the diamond, edges (corners sharing a row or side), diagonals through Space and the crystal membership all
// come from the build's own canon (codex3 state-space-canon.js: SQUARE, edgeBetween, diagonal, CRYSTALS). The bond operator is the
// swarm's own NAND (relational.js, kept on every bond since Nov 22). The axis lines from v64k stay the movement geometry; nothing
// here moves a unit or changes the two sides' pairing (dual.js PAIR is unchanged).
// MY PICKS (marked): a dimension's input in a swarm is its units' pooled hexagram (a line is yang when at least half its units have
// it yang, the same pooling governor.js uses); intermingling two inputs at the hexagram scale = their NAND; Space = the NAND of the
// two diagonals' results (each diagonal "passes through Space" in the canon); the Monopole connects outward wherever a Movement
// unit's gate sits at Hamming distance <= 1 from a crystal's result (the §2 emergence rule, used as the channel test).
// PERSPECTIVE BOUND (Celestial, Nov 26: "it's supposed to be perspective bound"; "It changes its Perspective dependent"; and
// "I was reading that it was supposed to be movement being design evolution"). Paper §4.0: "there is no fixed, universal
// interpretation ... only a reading of it filtered through the dimension ... they are speaking from"; §1.5: same field,
// different vantage, different local readout. Built (my translation, check it):
//   * the canon's square is the diamond read from Movement (the Monopole sits bottom right). Read from another corner, the
//     diamond turns so the reader takes that place; the corners keep their cyclic order (Movement, Being, Evolution, Design
//     round the square), so the same four edges exist from every view, but which line each one sits on, and so its reference
//     name, depends on the reader.
//   * the pairs are the two rows as the reader sees them. From Movement: Movement-Being and Design-Evolution, which is what
//     Celestial read and what dual.js PAIR and the v64k axis already hold. From Being: Being-Evolution and Design-Movement. Etc.
//   * every edge's result is read through the reader's own input (one more intermingling), so the same two corners read
//     differently from different readers. Space has no corner: read from Space the diamond does not turn, and its filter is
//     Space's own (emergent) result.
//   * read order: start at the reader, then round the diamond (Movement, Being, Evolution, Design from Movement).
import { maskFromKingWen, kingWenFromMask } from "./kingwen.js";
import { SQUARE, CRYSTALS, BASES, FRAMES, edgeBetween, diagonal } from "./codex3/synthia-dual-swarm/core/state-space-canon.js";

const LEVELS = { earth: [1, 2], human: [3, 4], heaven: [5, 6] };
const bit = (m, l) => (m >> (l - 1)) & 1;
export const hamming6 = (a, b) => { let x = (a ^ b) & 63, n = 0; while (x) { n += x & 1; x >>= 1; } return n; };
const nand6 = (a, b) => ~(a & b) & 63;
// the human register of the edge names (doc §3.1). Reference only, like the canon's physics frame.
export const HUMAN_REGISTER = Object.freeze({ top: "Civilisation", bottom: "Friction", left: "Humanity", right: "Earth" });
const FRAME_PHYSICS = FRAMES.physics;

/** A dimension's input from a set of addresses: pooled hexagram plus pooled colour/tone/base (most common value; ties -> lowest). */
export function pooled(addresses) {
  const a = addresses.filter(x => x?.gate); if (!a.length) return null;
  let mask = 0; for (let l = 1; l <= 6; l++) if (a.filter(x => bit(maskFromKingWen(x.gate), l)).length * 2 >= a.length) mask |= 1 << (l - 1);
  const mode = k => { const c = {}; for (const x of a) if (x[k] != null) c[x[k]] = (c[x[k]] ?? 0) + 1; const e = Object.entries(c).sort((p, q) => q[1] - p[1] || p[0] - q[0])[0]; return e ? +e[0] : null; };
  return { mask, gate: kingWenFromMask(mask), color: mode("color"), tone: mode("tone"), base: mode("base"), count: a.length };
}

/** Fine level bits for §2's second emergence site: colour, tone and base, 3 bits each (value - 1). */
const fine = x => x && x.color && x.tone && x.base ? ((x.color - 1) | ((x.tone - 1) << 3) | ((x.base - 1) << 6)) : null;
const ham = (a, b) => { let x = a ^ b, n = 0; while (x) { n += x & 1; x >>= 1; } return n; };

/** Intermingle two dimensional inputs: { dim: pooled-or-address }. Returns the interpretation at each scale. */
export function intermingle(A, B, dimA, dimB) {
  if (!A || !B) return null;
  const mA = A.mask ?? maskFromKingWen(A.gate), mB = B.mask ?? maskFromKingWen(B.gate), mask = nand6(mA, mB);
  const agree = Object.entries(LEVELS).filter(([, [p, q]]) => bit(mA, p) === bit(mB, p) && bit(mA, q) === bit(mB, q)).map(([k]) => k);
  const fA = fine(A), fB = fine(B);
  const out = { of: [dimA, dimB], mask, gate: kingWenFromMask(mask), agree,
    channel: { gate: hamming6(mA, mB) <= 1, gateDistance: hamming6(mA, mB), fine: fA != null && fB != null ? ham(fA, fB) <= 1 : null, fineDistance: fA != null && fB != null ? ham(fA, fB) : null } };
  if (dimA && dimB && SQUARE.corners[dimA] && SQUARE.corners[dimB] && dimA !== dimB) {
    const e = edgeBetween(dimA, dimB);
    out.edge = e ? { line: e.line, reference: { physics: e.name, human: HUMAN_REGISTER[e.line] } } : null;   // reference, not assigned
    out.diagonal = e ? null : diagonal(dimA, dimB);
  }
  return out;
}

// the square's places in turning order, and the corners as the canon places them (read from Movement)
const PLACES = [["bottom", "right"], ["bottom", "left"], ["top", "left"], ["top", "right"]];
const placeOf = d => { const c = SQUARE.corners[d]; return PLACES.findIndex(([r, s]) => r === c.row && s === c.side); };
export const CYCLE = Object.keys(SQUARE.corners).sort((a, b) => placeOf(a) - placeOf(b));   // [Movement, Being, Evolution, Design]
/** The diamond as one dimension reads it: where each corner sits, which pairs share a row, the edges with their lines, the read order. */
export function diamondFrom(perspective = "Movement") {
  const k = CYCLE.includes(perspective) ? CYCLE.indexOf(perspective) : 0;            // Space (centre): no turn
  const at = Object.fromEntries(CYCLE.map((d, i) => { const [row, side] = PLACES[(i - k + 4) % 4]; return [d, { row, side }]; }));
  const lineOf = (a, b) => at[a].row === at[b].row ? at[a].row : at[a].side === at[b].side ? at[a].side : null;
  const edges = []; for (let i = 0; i < 4; i++) for (let j = i + 1; j < 4; j++) { const a = CYCLE[i], b = CYCLE[j], line = lineOf(a, b);
    edges.push(line ? { corners: [a, b], line, reference: { physics: FRAME_PHYSICS[line], human: HUMAN_REGISTER[line] } } : { corners: [a, b], line: null, through: "Space" }); }
  const rows = ["bottom", "top"].map(r => CYCLE.filter(d => at[d].row === r));
  const pair = Object.fromEntries(rows.flatMap(([a, b]) => [[a, b], [b, a]])); pair.Space = "Space";
  return { perspective, at, edges, pair, order: [...CYCLE.slice(k), ...CYCLE.slice(0, k)], centre: "Space" };
}

/** Read the crystals and the Monopole from a set of units (each with .address.dimension), from one dimension's perspective. */
export function readCrystals(units, { perspective = "Movement" } = {}) {
  const live = units.filter(u => !u.broken && u.address?.gate);
  const by = {}; for (const d of Object.keys(SQUARE.corners)) by[d] = pooled(live.filter(u => u.address.dimension === d).map(u => u.address));
  // Space: no substance of its own; the result of the whole diamond. Each diagonal passes through it; Space = the two meeting.
  const diag1 = intermingle(by.Evolution, by.Movement, "Evolution", "Movement"), diag2 = intermingle(by.Design, by.Being, "Design", "Being");
  const space = diag1 && diag2 ? { ...intermingle(diag1, diag2), of: ["Evolution×Movement", "Design×Being"], from: "the whole diamond (both diagonals)" } : null;
  const spaceIn = space ? { mask: space.mask, gate: space.gate, color: null, tone: null, base: null } : null;
  // the two binary crystals, membership from the canon
  const reading = {};
  for (const [name, C] of Object.entries(CRYSTALS)) { if (!C?.members || !C.binary) continue;
    const [x, y] = C.members, inp = d => d === "Space" ? spaceIn : by[d];
    reading[name] = { members: [...C.members], centre: C.centre, ...(intermingle(inp(x), inp(y), x, y) ?? { missing: [x, y].filter(d => !inp(d)) }) }; }
  // the edges of the diamond as this reader sees it: each pair sharing a line, intermingled live, then read through the reader
  const view = diamondFrom(perspective), reader = perspective === "Space" ? spaceIn : by[perspective] ?? null, edges = [];
  for (const e of view.edges) { if (!e.line) continue; const [x, y] = e.corners, r = intermingle(by[x], by[y], x, y); if (!r) continue;
    const seen = reader ? intermingle(r, reader) : null;
    edges.push({ ...r, edge: { line: e.line, reference: e.reference }, seen: seen && { gate: seen.gate, agree: seen.agree } }); }
  // the Monopole: Movement, unpaired; it connects outward where a Movement unit's gate is within Hamming 1 of a crystal's result
  const movers = live.filter(u => u.address.dimension === "Movement"), keynote = BASES.find(b => b.dimension === "Movement")?.keynote;
  const outward = [];
  for (const u of movers) for (const [name, r] of Object.entries(reading)) if (r.mask != null) { const d = hamming6(maskFromKingWen(u.address.gate), r.mask);
    if (d <= 1) outward.push({ unit: u.id, to: name, distance: d }); }
  return { perspective, view: { at: view.at, pair: view.pair, order: view.order }, inputs: Object.fromEntries(Object.entries(by).map(([d, p]) => [d, p && { gate: p.gate, units: p.count }])), space, crystals: reading, edges,
    monopole: { dimension: "Movement", keynote, units: movers.length, outward } };
}
