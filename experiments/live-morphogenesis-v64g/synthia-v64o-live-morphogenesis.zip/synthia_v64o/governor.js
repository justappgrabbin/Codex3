// governor.js — the swarm's own vector-governing engine (v64i, Nov 26). Pure JS, no neural nets, no backend, no Arcadia.
// Celestial (Nov 26, voice, relayed): yes to building the swarm its own engine that sorts out what a formed piece is becoming,
// how its parts sit with the whole and how it expresses itself; "that's the one that makes a big difference on like if it's a
// human vector or if it's a building vector"; and earlier: "I wanted them to have the different qualities... I didn't know
// how to express it without like scripting it."
// Arcadia (arcadia.js) is untouched and stays optional; nothing here imports it, and it imports nothing from here.
//
// My translation, built on the bipyramid agent (tiling.js) and Celestial's own rule "lines and colors touch other people;
// tones and bases only inside you" (Nov 24):
//   QUALITIES (from the address, no script): an agent's six faces are its hexagram's six lines. Each face's weight is its line's
//     bit (yang 1, yin 0), plus 1 on the face the LINE names and 1 on the face the COLOR names (these touch others: they land
//     where they point), plus 1 from the TONE on a self face (tones only inside you: tone 1-3 on face 2, the inner self face;
//     4-6 on face 5, the outer one). The BASE sets which of the five corners leads (base 1-5 = Movement, Evolution, Being,
//     Design, Space, the canon's base table). No two different addresses are scripted alike; they differ because their
//     numbers do.
//   KIND FIRST (human or building, or another): a formation's INWARDNESS is the share of its members' weight sitting on the
//     two faces that face only themselves. The line it is measured against is not chosen: it is the mean inwardness over
//     every possible gate, line, colour and tone, worked out at load. Above it a formation leans to the self: the HUMANITY
//     side of the five-dimensions table (a human vector). Below it the weight sits on the ports, in what holds between
//     agents: the UNIVERSE side (Celestial's page 115: "Macrocosmic / The Universe"). Then the leading dimension (by the
//     members' bases) names the kind from that table: humanity side -> Individuality, The Mind, The Body, The Ego,
//     Personality; universe side -> Energy, Gravity, Matter, Structure, Form. "Design is Structure" on the universe side is
//     what I call a BUILDING vector (Celestial's example); a human vector is any humanity-side kind (all five are parts of a
//     person). Exactly on the line: "between".
//   BECOMING: each kind's nature chain from the table is read as the stages it grows through (my reading): Design on the
//     universe side Structure -> Progress -> Smell -> Life -> Art; the stage is how far the formation has closed.
//   GOVERNED BY KIND: how much a formation exchanges through its ports is its outward share (1 - inwardness); how much it
//     couples to its own unseen side through the self faces is its inwardness. A human vector keeps more to itself and its
//     shadow; a building vector carries more through its joints.
//   PARTS AND WHOLE: core (every port joined inside the formation) or edge (an open port); the VOICE is the member whose
//     qualities are closest to the whole's; each member leans inner (faces 1-3 heavier) or outer (4-6).
//   EXPRESSION: mode from the members' pooled lines (function_side.kindOf: line 1 and line 6 -> semantic, sound, picture,
//     video; out loud = semantic or sound). Phase from what the formation was last time: forming (new, or growing and not yet
//     closed), holding (whole and steady), breaking (members lost), regenerating (growing back after breaking, until whole).
import { maskFromKingWen } from "./kingwen.js";
import { kindOf } from "./function_side.js";
import { AGENT, exchange } from "./tiling.js";
import { BASES } from "./codex3/synthia-dual-swarm/core/state-space-canon.js";

export const GOVERN = { on: true };
const FACES = [1, 2, 3, 4, 5, 6], DIMS = ["Movement", "Evolution", "Being", "Design", "Space"];
let NATURES = null;
/** The five-dimensions table (five_dimensions.json). Optional: without it kinds are still told apart, named by dimension only. */
export const setDimensionNatures = j => { NATURES = j; };

const bitsOf = g => FACES.map(f => (maskFromKingWen(g) >>> (f - 1)) & 1);
const inRange = x => Number.isInteger(x) && x >= 1 && x <= 6;
export const dimensionOfBase = b => BASES[(b ?? 0) - 1]?.dimension ?? null;

/** A unit's qualities, from its address alone. */
export function qualities(a) {
  const w = Object.fromEntries(FACES.map(f => [f, 0]));
  if (a?.gate >= 1 && a.gate <= 64) bitsOf(a.gate).forEach((b, i) => { w[i + 1] += b; });
  if (inRange(a?.line)) w[a.line] += 1;
  if (inRange(a?.color)) w[a.color] += 1;
  if (inRange(a?.tone)) w[a.tone <= 3 ? AGENT.self[0] : AGENT.self[1]] += 1;
  const total = FACES.reduce((s, f) => s + w[f], 0), self = AGENT.self.reduce((s, f) => s + w[f], 0);
  return { faces: w, inside: total ? self / total : 0, lead: dimensionOfBase(a?.base) ?? a?.dimension ?? null,
    lean: w[1] + w[2] + w[3] >= w[4] + w[5] + w[6] ? "inner" : "outer" };
}

// The line kinds are measured against: mean inwardness over every gate, line, colour and tone (82,944 addresses).
export const BASELINE = (() => { let s = 0, n = 0;
  for (let g = 1; g <= 64; g++) for (let l = 1; l <= 6; l++) for (let c = 1; c <= 6; c++) for (let t = 1; t <= 6; t++) { s += qualities({ gate: g, line: l, color: c, tone: t }).inside; n++; }
  return s / n; })();

const vecOf = q => FACES.map(f => q.faces[f]);
const cos = (a, b) => { let d = 0, x = 0, y = 0; for (let i = 0; i < a.length; i++) { d += a[i] * b[i]; x += a[i] * a[i]; y += b[i] * b[i]; } return x && y ? d / Math.sqrt(x * y) : 0; };
const leadOf = qs => { const c = Object.fromEntries(DIMS.map(d => [d, 0])); for (const q of qs) if (q.lead) c[q.lead]++;
  return DIMS.reduce((best, d) => c[d] > c[best] ? d : best, DIMS[0]); };

/** Stage 1, kind: human vector, building vector, or another kind. members: [{address}] (anything with an address). */
export function classify(members) {
  const qs = members.map(m => qualities(m.address)), n = Math.max(1, qs.length);
  const inside = qs.reduce((s, q) => s + q.inside, 0) / n, lead = leadOf(qs);
  const side = Math.abs(inside - BASELINE) < 1e-12 ? "between" : inside > BASELINE ? "humanity" : "universe";
  const human = NATURES?.humanity?.[lead], world = NATURES?.universe?.[lead];
  const nature = side === "humanity" ? human?.dimension ?? BASES.find(b => b.dimension === lead)?.human ?? lead : side === "universe" ? world?.[0] ?? lead : "Space";
  const label = side === "humanity" ? "human" : side === "universe" ? (lead === "Design" ? "building" : "world") : "between";
  const share = DIMS.map(d => qs.filter(q => q.lead === d).length / n);
  return { label, side, dimension: lead, nature, name: `${label}: ${nature}`, inside: +inside.toFixed(4), baseline: +BASELINE.toFixed(4),
    vector: [inside, ...share, qs.filter(q => q.lean === "inner").length / n], qualities: qs };
}

/** The whole reading of one formation. progress: 0..1 how far it has closed (a shell's closed corners, or a regulation's
 *  coherence). ports: for seated agents, each member's port links. memory: where the formation's last reading is kept. */
export function govern(members, { id = null, memory = null, progress = null, ports = null, closed = null, empty = 0 } = {}) {
  const K = classify(members), qs = K.qualities, n = Math.max(1, qs.length);
  // becoming
  const chain = K.side === "humanity" ? NATURES?.humanity?.[K.dimension]?.nature : K.side === "universe" ? NATURES?.universe?.[K.dimension] : null;
  const p = progress == null ? 0 : Math.max(0, Math.min(1, progress)), stage = chain ? Math.min(chain.length - 1, Math.floor(p * (chain.length - 1) + 1e-9)) : null;
  const becoming = { chain: chain ?? null, stage, now: chain ? chain[stage] : K.nature, toward: chain ? chain.at(-1) : null, progress: +p.toFixed(3) };
  // parts and whole
  const mean = FACES.map((f, i) => qs.reduce((s, q) => s + q.faces[f], 0) / n), align = qs.map(q => cos(vecOf(q), mean));
  const avg = align.reduce((a, b) => a + b, 0) / n, inSet = new Set(members.map(m => m.agent ?? m.unit));
  const parts = members.map((m, i) => { let sits;
    if (ports) { const L = ports[i] ?? {}; sits = AGENT.ports.every(l => L[l] && inSet.has(L[l].agent)) ? "core" : "edge"; }
    else sits = align[i] >= avg ? "core" : "edge";
    return { unit: m.unit ?? null, agent: m.agent ?? null, sits, lean: qs[i].lean, alignment: +align[i].toFixed(3), lead: qs[i].lead }; });
  const voice = parts[align.indexOf(Math.max(...align))] ?? null;
  // governed by kind
  const rates = { ports: +(1 - K.inside).toFixed(4), coupling: +K.inside.toFixed(4) };
  // expression
  const pooled = FACES.map(f => members.filter(m => m.address?.gate && (bitsOf(m.address.gate)[f - 1])).length * 2 >= members.filter(m => m.address?.gate).length && members.some(m => m.address?.gate) ? 1 : 0);
  const mode = kindOf(pooled), ids = members.map(m => m.agent ?? m.unit), prev = id != null ? memory?.[id] : null;
  const lost = prev ? prev.members.filter(x => !ids.includes(x)).length : 0, whole = closed ?? true;
  let phase;
  if (!prev) phase = "forming";
  else if (lost > 0) phase = "breaking";
  else if (prev.phase === "breaking" || prev.phase === "regenerating") phase = ids.length >= prev.peak && whole ? "holding" : "regenerating";
  else if (ids.length > prev.members.length || !whole) phase = "forming";
  else phase = "holding";
  if (id != null && memory) memory[id] = { members: ids, phase, peak: Math.max(prev?.peak ?? 0, ids.length), kind: K.name };
  const { qualities: _q, ...kind } = K;
  return { kind, becoming, empty, parts, core: parts.filter(x => x.sits === "core").length, edge: parts.filter(x => x.sits === "edge").length,
    voice, rates, expresses: { mode, outLoud: mode === "semantic" || mode === "sound", phase, lost } };
}

/** Govern a seated shell (tiling.seat) whose agents stand on the swarm's units. T: the tiling (for closure). */
export function governShell(S, units, { T = null, id = null, memory = null, take = null } = {}) {
  const agents = take ? S.agents.filter(g => take.includes(g.id)) : S.agents, byId = new Map((units ?? []).map(u => [u.id, u]));
  const seated = agents.filter(g => byId.get(g.unit)?.address);   // a place with no unit standing on it is empty, not a member
  const members = seated.map(g => ({ agent: g.id, unit: g.unit, address: byId.get(g.unit).address }));
  let progress = null; if (T) { const deg = [...T.fans.values()].map(f => f.length); progress = deg.filter(d => d >= T.k).length / Math.max(1, deg.length); }
  return govern(members, { id, memory, progress, ports: seated.map(g => g.links), closed: T ? T.closed : null, empty: agents.length - seated.length });
}

/** One tick of both sides (dual.js's twoSides), each governed by its own kind: ports exchange at the side's own rate, and the
 *  self faces couple across at the mean of the two sides' coupling rates. Returns the two readings. */
export function governedTick(D, units, { memory = null } = {}) {
  const gs = governShell(D.seen, units, { id: "seen", memory }), gh = governShell(D.shadow, units, { id: "shadow", memory });
  exchange(D.seen, { rate: gs.rates.ports }); exchange(D.shadow, { rate: gh.rates.ports });
  const r = (gs.rates.coupling + gh.rates.coupling) / 2;
  D.partner.forEach((j, i) => { if (j == null) return; const a = D.seen.agents[i], b = D.shadow.agents[j];
    for (const l of AGENT.self) { const x = a.value[l], y = b.value[l]; a.value[l] = (1 - r) * x + r * y; b.value[l] = (1 - r) * y + r * x; } });
  return { seen: gs, shadow: gh, coupling: +r.toFixed(4) };
}

/** Plug into morphogenesis (AFTER_LEARN), alongside Arcadia or without it. GOVERN.on = false turns it off again. */
export function installGovernor(hooks) {
  hooks.push({ name: "governor", before: () => null,
    after: (O, reg, { formationId, say }) => { if (!GOVERN.on) return;
      const members = reg.members.map(m => ({ unit: m.unit, address: O.S.units[m.unit]?.address })).filter(m => m.address);
      const g = govern(members, { id: formationId, memory: (O.governor ??= {}), progress: reg.coherence });
      O.lastGovernance = g;
      // v64m: each member unit carries what its formation is becoming and how it is expressing it, so the knowing is in the
      // units themselves, not only in the organism's last reading. Its own place in the whole comes with it (core/edge, lean).
      g.parts.forEach(pt => { const u = O.S.units[pt.unit]; if (!u) return;
        u.becoming = { formation: formationId, kind: g.kind.name, side: g.kind.side, now: g.becoming.now, toward: g.becoming.toward, stage: g.becoming.stage,
          phase: g.expresses.phase, mode: g.expresses.mode, sits: pt.sits, lean: pt.lean, voice: g.voice?.unit === pt.unit }; });
      say("govern", { kind: g.kind.name, becoming: g.becoming.now, phase: g.expresses.phase, mode: g.expresses.mode, core: g.core, edge: g.edge, voice: g.voice?.unit }); } });
  return hooks;
}
