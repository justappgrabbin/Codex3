# v64l — the BHANTUGH dual-swarm doc, checked against what was built (Nov 26)

Source: Celestial's Google Doc "BHANTUGH — Adaptive Generative Dual-Swarm Architecture" (the second link is the same text).
v64k is kept as it was. v64l = v64k + `dualswarm.js` + `test_dualswarm.mjs` + three switches in `living.js` (all off by default).
With the switches off the swarm moves exactly as v64k's did, step for step (the test checks this against the saved v64k).

## Map: doc section -> done / partial / missing (before v64l), and what v64l did

| § | Doc part | Before v64l | Where it was | v64l |
|---|---|---|---|---|
| 1 | binary/ASCII/Unicode/UTF-8/transliteration | done | encoding.js (8 layers per character, NFD transliteration) | reused |
| 3 | XOR + Hamming attract/repel | done | living.js step (binary reaction) | reused |
| 3 | bit-shift locomotion | missing | — | added: 32-bit register, rotate << / >> by cycle, low nibble steers (`SHIFT_LOCOMOTION`) |
| 4 | hex -> XYZ sectors / RGB | partial (colour came from sound) | expression.js | added: `hexOf`, `stateOf`, `u.state` (0x3F8A1C -> 3F/8A/1C) |
| 5 | ASCII opcodes, executed | done | bhantugh_ops.js OPCODES + living.run | reused |
| 6 | box-drawing connectors | done | living.js linkGlyph | reused |
| 6 | shapes + arrows | missing | — | added: `shapeGlyph`, `arrowGlyph`, `u.glyph` |
| 7 | NATO voice, rhythm | done | bhantugh_ops.voice, opcode beats | reused |
| 7 | neighbours sync clock phases | missing | — | added: Kuramoto rule on validated bonds, weighted by NATO beats (`PHASE_SYNC`) |
| 8 | contracts | partial (bondable/full) | bhantugh_ops.CONTRACTS | added: `isOntologicalAddress`, `isClusterNode` |
| 8 | AST -> executable JS | missing | — | added inside §22: graph -> generated JS source |
| 9 | hash combine -> child | done | living.combine (sha256) | reused |
| 9 | hash-prefix bond | missing | — | added: `hashBond`, extra opener in link (`HASH_BOND`, off) |
| 10 | gematria mass | done | living.gematria | reused |
| 10 | digital root -> symmetry | missing | — | added: `digitalRoot`, `polygonSVG` |
| 13 | the ten-step cycle | partial (pieces) | — | added: `cycle(a,b)` all ten steps, `cycleWord("FORM")` |
| 15 | Swarm A (Boolean) / Swarm B (form) | done as one swarm, two sides | relational.js NAND on every bond (A); living expression + SVG (B); function side / morph side since v61 | mapped, not split |
| 17 | 10D features + gossip | done (thesis version) | formation.js | added the doc's variant `featuresDoc` (drops repeated degree, 10th = gematria) |
| 18 | 13-part address, sentence | done | bhantugh_ops.addressSentence | reused; added both hexagram readings (below) |
| 19 | harmony + bond count | done | bhantugh_ops.evaluateSwarmBond | reused |
| 20 | levels, visible at 3 | done (by count) | bhantugh_ops.LEVELS | added the doc's table by governing coordinates `LEVEL_TABLE`, `shownAt` |
| 21 | Sobel edges, units onto them | done | bhantugh_ops.asciiImage / pictureTargets, grow.js | reused |
| 21 | sentences along contours | missing | — | added: `sentencesSVG` (textPath along each level-3+ cluster's outline) |
| 22/24 | cluster -> computational graph | missing | — | added: `compileGraph` -> evaluate, generated JS, GLSL, CPPN image, audio |
| 22 | neural nets / tensor graphs | out on purpose | — | left out (purity) |
| 23 | leading dimension | done | bhantugh_ops.leadingDimension (Space never leads) | reused |
| 23 | output routing | missing | — | added: `route` (Movement keyframes, Evolution recurrent, Being image+shader, Design HTML, Space 3D+panned audio, only if pinned) |
| 25 | bidirectional loop | done | morph page (pagemorph, ask, grow) | reused; `cycle` takes a user bit-flip as step 9 |

## My picks (all settings or tables)
- Rotate instead of plain shift, so the register never empties. << while the unit's cycle rises, >> while it falls.
- Hash bond: the two bit strings in a fixed order, so it's the same whichever unit asks. Off by default; "00" passes about 1 in 256.
- Phase sync only along validated bonds (§13 step 7: only validated clusters broadcast). Off by default (K = 0).
- Glyphs: ● ▲ ■ from the shapes block; ⬟ ⬢ for 5 and 6 come from another block (none exist in U+25A0-25FF); 7-9 draw only as the SVG polygon.
- Graph: gate -> activation by its lower trigram (Kun gauss, Zhen step, Kan sin, Dui sigmoid, Gen clamp, Li abs, Xun tanh, Qian linear);
  color -> scale, base -> bias, sender's tone -> edge weight; edges lower id -> higher id so it's always a DAG; sources read x, y or r
  by their line's bigram (earth x, human y, heaven radius).

## The two hexagram readings, kept together
- Trigram reading (bonding): lines 1-3 lower, 4-6 upper; harmony pairs 1-4, 2-5, 3-6.
- Bigram reading (level): 1-2 earth, 3-4 human, 5-6 heaven; the hexagram (body level) is three bigrams.
- How they meet (checked on all 64 gates): every line is in one harmony pair and one bigram; the trigram cut splits only the human bigram;
  each harmony pair is the bridge between two levels, one bridge per pair of levels: 1-4 earth-human, 2-5 earth-heaven, 3-6 human-heaven.
- Agent: each face's mirror across the equator is its harmony partner, in both orientations. The self faces 2 and 5 are each other's
  partner and share the seam (E2-E3). So the self pair is the earth-heaven bridge, and the ports pair as 1-4 and 3-6.
- Mind/Heart carrying more bits: the doc gives no count, so none is invented. `depthBits` shows what an address carries now
  (hexagram 6 bits, gate-to-base about 16.1).

## Not done here
- GLSL is generated and checked for every node but not run (no GPU here).
- Crystal pairing still not wired (waiting on Celestial).
