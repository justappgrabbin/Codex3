// recursion.js — gate-led clusters at two (and more) scales, with the upward trigger ladder (Celestial's assignment,
// Nov 26, built on v64 slim). Added beside morphogenesis.js; nothing there is replaced. morphogenesis.enter() calls
// clusterOf / regulate / learnFrom once a formation has met the host's need and works without the swarm.
//
// WHAT IS REUSED UNCHANGED (v64):
//   resonance_rules.js  contact(), baseReach(), colourRelation(), lineHarmony(), lineFacing(), canTouch()
//   gate_engine.js      gateFunction() (the gate's fixed function), lineExpression() (line mode, swayed by colour,
//                       tone, base) — these ARE the five engines; this file only reads them for a formation's leader
//   opp.js              oppOf() (each unit's spatial OPP) and popOf() (the POP across units)
//   function_side.js    formationLines(), abilityOf(), kindOf() (what the pooled lines of a cluster can do)
//   klein_local.js      linesOf() (a unit's lines read in its dimension's order; Space reads in the leader's order)
//
// MICRO  A formation is a cluster. Its LEADING GATE is the gate of the unit carrying the step that produces the
//        formation's output (my reading of "the gate whose function governs the operation leads the cluster"). The
//        other carriers are the SUPPORTING gates.
// MACRO  A learned formation used as ONE step of a new formation joins as a SUB-CLUSTER that keeps its own leader. The
//        new formation has its own leader. A formation built this way is learned in turn and can join a further
//        composition (scale 3, 4 ...).
//
// THE LADDER (user's rule book: "Gate > Line > Color > Tone > Base", resonance_rules.canTouch = neighbours only;
// the climb as Celestial posted it Nov 26): every unit sits on its base. A trigger starts at the base and climbs
// base -> tone -> color -> line -> gate, one neighbouring level at a time. It keeps climbing while it resonates at
// each rung and LANDS at the rung where resonance ran out; reaching the gate is a full cascade. It cannot jump a rung
// (LADDER.bridges is empty until Celestial says a bridge exists).
//   Resonance per rung, from the existing rules only:
//     base  baseReach(...) === "resonance"   (exact base; "reaches"/"weak"/"blocked" are reach, not resonance)
//     tone  same tone                         (tone never transfers)
//     color same colour; transference (3 apart) is recorded as a blind spot and does NOT pass (LADDER.transferencePasses)
//     line  same line; harmony (1-4, 2-5, 3-6) is recorded but does NOT pass (LADDER.harmonyPasses)
//     gate  reached when the line rung passes: the trigger is now in the leader's function
//
// RECURSION (both: unit vs swarm, and swarm vs host — Celestial, Nov 26: "same rules, one scale up each time"):
//   each formation's members climb against THAT formation's leader (REGULATION.relativeTo = "each-formation"; the
//   other setting, "outermost", has every unit climb against the outermost leader). A trigger that reaches its leader's
//   gate is now in that leader, and the leader climbs against the leader one scale up (the sub-cluster joining the
//   larger formation), and the outermost leader climbs against the host when the host offers an address. So a trigger
//   lands at a rung AND at a scale. Units' addresses are never written to.
//   Downward: the outer formation's frame (its leader's base -> dimension) is the frame in which Space units read their
//   lines (klein_local.linesOf). That is the only downward effect built; nothing else is invented.
import { contact, baseReach, colourRelation, lineHarmony, lineFacing, canTouch } from "./resonance_rules.js";
import { gateFunction, lineExpression } from "./gate_engine.js";
import { oppOf, popOf as spatialPOP } from "./opp.js";
import { BASES } from "./codex3/synthia-dual-swarm/core/state-space-canon.js";
import { linesOf } from "./klein_local.js";
import { formationLines, abilityOf, kindOf } from "./function_side.js";

/** The open choices, kept in one place so they are one-word changes. */
export const REGULATION = { relativeTo: "each-formation" };          // or "outermost"
export const LADDER = { rungs: ["base", "tone", "color", "line", "gate"], transferencePasses: false, harmonyPasses: false,
  bridges: [] };                                                     // e.g. [{ from: "base", to: "color", when: (a, b) => ... }] — none until Celestial says so
export const LEARNING = { rate: 0.5 };                               // craft added per rung climbed (working value, mine)

const addr = (O, id) => O.S.units[id]?.address ?? null;
const fieldsOf = a => a ? { gate: a.gate, line: a.line, color: a.color, tone: a.tone, base: a.base, dimension: a.dimension, side: a.side ?? null } : null;
export const frameOf = a => BASES[(a?.base ?? 0) - 1]?.dimension ?? a?.dimension ?? "Movement";
// the rule book's own order check: the ladder only ever steps between levels canTouch allows
for (let i = 1; i < 4; i++) if (!canTouch(LADDER.rungs[i], LADDER.rungs[i + 1])) throw Error("ladder breaks canTouch at " + LADDER.rungs[i]);

/** One rung: does a resonate with b at this level? Returns { passes, kind }. */
function rung(level, a, b, side) {
  if (level === "base") { const r = a.base != null && b.base != null ? baseReach(a.base, b.base, side) : "none"; return { passes: r === "resonance", kind: r }; }
  if (level === "tone") return { passes: a.tone != null && a.tone === b.tone, kind: a.tone === b.tone ? "resonance" : "none" };
  if (level === "color") { const r = a.color != null && b.color != null ? colourRelation(a.color, b.color) : "none";
    return { passes: r === "resonance" || (r === "transference" && LADDER.transferencePasses), kind: r, blindSpot: r === "transference" }; }
  if (level === "line") { const same = a.line != null && a.line === b.line, harm = !same && a.line != null && b.line != null && lineHarmony(a.line, b.line);
    return { passes: same || (harm && LADDER.harmonyPasses), kind: same ? "resonance" : harm ? "harmony" : "none" }; }
  return { passes: true, kind: "function" };                         // gate: arriving here is the cascade completing
}

/** The climb of a trigger from a's base toward b's gate. The leader itself (a === b) cascades by definition. */
export function climb(a, b, { side = a?.side ?? "Personality" } = {}) {
  if (!a || !b) return { landed: "base", passed: [], cascade: false, steps: [] };
  const steps = []; let at = 0;
  while (at < LADDER.rungs.length) {
    const level = LADDER.rungs[at], r = rung(level, a, b, side); steps.push({ level, ...r });
    if (!r.passes) { const br = LADDER.bridges.find(x => x.from === level && x.when?.(a, b));   // a bridge, if one is ever declared
      if (br) { steps.push({ level, bridge: br.to }); at = LADDER.rungs.indexOf(br.to); continue; } break; }
    at++;
  }
  const passed = steps.filter(s => s.passes).map(s => s.level), cascade = passed.includes("gate");
  return { landed: cascade ? "gate" : steps.at(-1).level, passed, cascade, rungsClimbed: passed.filter(l => l !== "gate").length,
    blindSpot: steps.some(s => s.blindSpot), steps };
}

/** Build the cluster record of one formation. steps = [{id, op, inputs, unit}], output = the output step's id.
 *  clusters = records of formations learned before (by their operation id), to recognise sub-clusters. */
export function clusterOf(O, { id, steps, output, host, clusters = {} }) {
  const lead = steps.find(s => s.id === output);
  if (!lead || lead.unit == null) return null;                       // output is a raw material or nobody carried it
  const subclusters = steps.filter(s => clusters[s.op]).map(s => ({ via: s.id, cluster: s.op, carrier: s.unit, leader: clusters[s.op].leader }));
  const support = steps.filter(s => s !== lead && s.unit != null && s.unit !== lead.unit && !clusters[s.op])
    .map(s => ({ unit: s.unit, op: s.op, step: s.id, gate: addr(O, s.unit)?.gate ?? null }));
  const scale = 1 + Math.max(0, ...subclusters.map(s => clusters[s.cluster].scale ?? 1));
  const composing = new Set([addr(O, lead.unit)?.gate, ...support.map(s => s.gate)]);
  for (const s of subclusters) for (const g of clusters[s.cluster].composingGates ?? []) composing.add(g);
  composing.delete(undefined); composing.delete(null);
  return { id, host, scale, reused: steps.length === 1 && !!clusters[lead.op],
    leader: { unit: lead.unit, op: lead.op, step: lead.id, ...fieldsOf(addr(O, lead.unit)) },
    support, subclusters, steps: steps.map(s => ({ id: s.id, op: s.op, unit: s.unit })),
    composingGates: [...composing].sort((a, b) => a - b) };
}

/** A member's OPP: v64's own spatial OPP (opp.js, unchanged) plus where it stands toward its formation's leader. */
function memberOPP(O, u, a, L, c, { role, step, scale, frame }) {
  // the live page reads u.opp every tick; use that when it is there, else read it on a copy so the unit's heading isn't reset
  const spatial = u ? (u.opp ?? oppOf({ ...u }, O.S.units)) : null;
  const k = contact(a, L, { inside: true, side: a.side ?? "Personality" });   // the existing crossing rule, unchanged
  return { ...(spatial ?? {}), toLeader: { role, step, scale, frame, facing: a.line ? lineFacing(a.line) : null, landed: c.landed,
    climbed: c.passed, crosses: k.by?.level ?? null, registers: k.all.map(x => x.level), blindSpot: c.blindSpot } };
}

/** Regulate a cluster record: every member climbs against the formation's leader; a sub-cluster's leader climbs
 *  against this leader (one scale up); members whose trigger cascaded carry on up through their leader.
 *  above = { leader, top, chain } when this cluster sits inside a larger one. Never writes to a unit's address. */
export function regulate(O, rec, clusters = O.morphMemory?.clusters ?? {}, above = null, host = null) {
  const L = addr(O, rec.leader.unit) ?? rec.leader, top = above?.top ?? L;
  const ref = REGULATION.relativeTo === "outermost" ? top : L;
  const frame = frameOf(ref), members = [];
  // how far a trigger arriving at THIS leader's gate goes on up: the chain of leaders above (and the host, if addressed)
  const upChain = above?.chain ?? [];
  const onward = from => { let scaleUp = 0, landedAbove = null;
    for (const next of upChain) { const c = climb(from, next.address); if (!c.cascade) { landedAbove = { at: next.scale, rung: c.landed }; break; } scaleUp++; from = next.address; }
    return { scalesUp: scaleUp, landedAbove }; };
  const add = (unit, op, a, role, step) => { const c = role === "leader" && ref === L ? climb(a, a) : climb(a, ref);
    const up = c.cascade ? onward(L) : { scalesUp: 0, landedAbove: null };
    members.push({ unit, op, gate: a.gate, role, scale: rec.scale, regulatedBy: ref.gate, climb: c, ...up,
      opp: memberOPP(O, O.S.units[unit], a, ref, c, { role, step, scale: rec.scale, frame }) }); };
  add(rec.leader.unit, rec.leader.op, L, "leader", rec.leader.step);
  for (const s of rec.support) { const a = addr(O, s.unit); if (a) add(s.unit, s.op, a, "support", s.step); }
  const subs = [];
  for (const s of rec.subclusters) { const sub = clusters[s.cluster]; if (!sub) continue;
    const subLead = addr(O, sub.leader.unit) ?? sub.leader, link = climb(subLead, ref);     // the sub-cluster, as one member, meets this leader
    const inner = regulate(O, sub, clusters, { top, chain: [{ scale: rec.scale, address: L }, ...upChain] });
    subs.push({ cluster: s.cluster, via: s.via, leadingGate: subLead.gate, link: { landed: link.landed, passed: link.passed, cascade: link.cascade }, coherence: inner.coherence });
    members.push(...inner.members); }
  // upward summary: the share of this formation's own triggers that reached its leader's gate (sub-clusters count as one each)
  const direct = members.filter(m => m.scale === rec.scale);
  const coherence = (direct.filter(m => m.climb.cascade).length + subs.filter(s => s.link.cascade).length) / Math.max(1, direct.length + subs.length);
  // the swarm meets the host (outermost formation only), when the host offers an address
  const hostClimb = !above && host?.address ? climb(L, host.address) : null;
  // the five engines: v64's gate engine read for the leader, plus what the pooled lines of the cluster can do
  const pooled = formationLines([rec.leader.unit, ...rec.support.map(s => s.unit)].map(id => O.S.units[id]).filter(Boolean)
    .map(u => ({ lines: linesOf(u.address, frame) ?? [] })));
  const ability = pooled ? abilityOf(pooled) : null, f = gateFunction(L.gate), e = lineExpression(L);
  const engines = {
    gate: { gate: L.gate, does: f.does, op: f.op, field: f.field, name: f.name, keynote: f.keynote, pooledCore: ability?.core ?? null, tool: ability?.tool ?? null },
    line: { line: L.line, mode: e.mode, does: e.does, lineName: e.lineName, pooledKind: pooled ? kindOf(pooled) : null },
    color: { color: L.color, motivation: e.sway.motivation },
    tone: { tone: L.tone, sense: e.sway.sense },
    base: { base: L.base, ground: e.sway.ground, frame },
  };
  return { id: rec.id, scale: rec.scale, leader: rec.leader.unit, leadingGate: L.gate, regulatedBy: ref.gate, members, subclusters: subs, coherence,
    engines, host: hostClimb, pop: above ? null : formationPOP(O, members) };
}

/** POP of a formation: v64's own POP over its member units (opp.js popOf, unchanged), plus the proportion of the whole
 *  at each rung where triggers landed, at each scale, and how far up they carried. */
export function formationPOP(O, members) {
  const n = Math.max(1, members.length), share = key => { const m = {}; for (const x of members) { const k = String(key(x) ?? "none"); m[k] = (m[k] ?? 0) + 1 / n; }
    return Object.fromEntries(Object.entries(m).map(([k, v]) => [k, +v.toFixed(3)])); };
  const seen = new Set(), units = members.filter(m => !seen.has(m.unit) && seen.add(m.unit) && m.opp?.position)
    .map(m => ({ opp: m.opp, latent: !!O.S.units[m.unit]?.latent }));
  return { members: members.length, spatial: units.length ? spatialPOP(units) : null,
    landed: share(m => m.climb.landed), scale: share(m => m.scale), role: share(m => m.role),
    scalesUp: share(m => m.scalesUp), blindSpots: members.filter(m => m.climb.blindSpot).length };
}

/** The structure acts back on its parts: each member's craft for the step it carried grows by how far its trigger
 *  climbed (rungs, plus one per scale it carried up). Units' addresses are never touched. */
export function learnFrom(O, reg) {
  for (const m of reg.members) { const u = O.S.units[m.unit]; if (!u) continue;
    const gain = LEARNING.rate * (m.climb.rungsClimbed + m.scalesUp) / LADDER.rungs.length;
    if (gain) (u.craft ??= {})[m.op] = (u.craft[m.op] ?? 0) + gain; }
}

// ---------- extraction: the swarm leaves with what it learned, and another swarm can take it up ----------
/** Everything the swarm acquired: learned formations (as data, not closures), cluster records, each unit's craft. */
export function extractSwarm(O) {
  const B = O.morph, learned = B ? [...B.registry.values()].filter(p => p.formation && String(p.id).startsWith("formation."))
    .map(p => ({ id: p.id, inputs: p.inputs, output: p.output, cost: p.cost, formation: p.formation })) : [];
  return JSON.parse(JSON.stringify({ schema: "swarm-acquired/1", learned, clusters: O.morphMemory?.clusters ?? {}, formations: O.morphMemory?.formations ?? [],
    craft: O.S.units.filter(u => u.craft).map(u => ({ id: u.id, gate: u.address.gate, craft: u.craft })) }));
}
/** Take up what a swarm acquired. morphBuilder and runPlan are passed in so this file stays free of the builder.
 *  Craft goes to the unit with the same id and gate, or else the first unit with the same gate. Learned formations
 *  whose steps need operations this swarm doesn't have are kept but can only run where those operations are offered. */
export function adoptSwarm(O, x, { morphBuilder, runPlan }) {
  const B = morphBuilder(O);
  for (const f of x.learned ?? []) if (!B.registry.has(f.id)) B.register({ id: f.id, inputs: f.inputs, output: f.output, cost: f.cost ?? 0.5, formation: f.formation,
    run: args => runPlan(f.formation.plan, f.formation.output, B.registry, (t, v) => B.validate(t, v), args) });
  const mem = O.morphMemory; mem.clusters = { ...(mem.clusters ?? {}), ...(x.clusters ?? {}) };
  for (const f of x.formations ?? []) if (!mem.formations.some(g => g.formation === f.formation && g.host === f.host)) mem.formations.push(f);
  let placed = 0;
  for (const c of x.craft ?? []) { const same = O.S.units[c.id]?.address.gate === c.gate ? O.S.units[c.id] : null, u = same ?? O.S.units.find(v => v.address.gate === c.gate);
    if (!u) continue; placed++; u.craft ??= {}; for (const [k, v] of Object.entries(c.craft)) u.craft[k] = (u.craft[k] ?? 0) + v; }
  return { learned: (x.learned ?? []).length, clusters: Object.keys(x.clusters ?? {}).length, craftPlaced: placed };
}
