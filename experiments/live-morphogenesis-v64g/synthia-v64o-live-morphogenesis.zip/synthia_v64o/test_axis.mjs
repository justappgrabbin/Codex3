// test_axis.mjs — the agent turned: Movement and Being on the vertical axis (v64k, Nov 26). Run plain and with run_with_arcadia.mjs.
//   1 the turn, and the old orientation kept   2 "everything is in line even the duals" inside one agent
//   3 one agent read each way   4 a whole shell read each way   5 across the two sides, each agent in line with its shadow
import { readFileSync } from "node:fs"; import { setGateEngineData } from "./gate_engine.js"; import { LivingSwarm } from "./living.js";
import { AGENT, ORIENTATIONS, setOrientation, agentShape, tile, read } from "./tiling.js"; import { PAIR, twoSides } from "./dual.js";
import { readAgent, readShell, ringsOf } from "./axis.js"; import { AFTER_LEARN } from "./morphogenesis.js";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
console.log(`Arcadia ${AFTER_LEARN.some(h => h.name === "arcadia") ? "installed" : "absent"}`);

console.log("1 — the turn");
console.log(`     now: ${JSON.stringify(AGENT.corners)}`);
ok("Being is the top tip and Movement the bottom tip: both on the vertical axis", AGENT.corners.T === "Being" && AGENT.corners.B === "Movement" && AGENT.orientation === "turned");
ok("Space still sits where the four ports meet, touching neither self face", agentShape().touches.Space.join() === "1,3,4,6");
ok("the old orientation is kept by name (v64h: Design on top), and can be put back", ORIENTATIONS.v64h.T === "Design" && setOrientation("v64h").corners.T === "Design" && setOrientation("turned").corners.T === "Being");

console.log("2 — everything is in line, even the duals (inside one agent)");
const LINES = [["B", "T"], ["E2", "E3"]], cornerOf = d => Object.keys(AGENT.corners).find(c => AGENT.corners[c] === d);
const inLine = () => Object.entries(PAIR).filter(([a, b]) => a < b).map(([a, b]) => [a, b, [cornerOf(a), cornerOf(b)].sort().join("-")]);
for (const [a, b, l] of inLine()) console.log(`     ${a} and ${b}: corners ${l} (${l === "B-T" ? "the vertical axis, tip to tip" : l === "E2-E3" ? "the seam, the edge the two self faces share" : "neither of the agent's two lines"})`);
ok("the agent's own two lines each hold one dual pair: the axis Being-Movement, the seam Design-Evolution; Space is its own dual", inLine().every(([, , l]) => LINES.some(L => L.slice().sort().join("-") === l)) && cornerOf("Space") === "E1");
setOrientation("v64h"); const before = inLine().filter(([, , l]) => LINES.some(L => L.slice().sort().join("-") === l)).length; setOrientation("turned");
ok(`before the turn ${before} of 2 dual pairs sat on those lines (the axis held Movement-Design, the seam Being-Evolution)`, before < 2);

console.log("3 — one agent, read each way");
const rb = readAgent("Being"), rm = readAgent("Movement");
console.log(`     Being    (from the ${rb.from === "T" ? "top" : "bottom"} tip, moving ${rb.moves}): ${rb.order.map(o => `${o.count}:face ${o.face}`).join("  ")}`);
console.log(`     Movement (from the ${rm.from === "T" ? "top" : "bottom"} tip, moving ${rm.moves}): ${rm.order.map(o => `${o.count}:face ${o.face}`).join("  ")}`);
ok("Movement moves upward: it counts the faces 1 to 6 from the bottom, the I Ching's own count", rm.moves === "up" && rm.order.map(o => o.face).join() === "1,2,3,4,5,6");
ok("Being counts up while moving down: its 1 2 3 are the top faces 4 5 6, then 1 2 3", rb.moves === "down" && rb.order.map(o => o.face).join() === "4,5,6,1,2,3");
ok("both read across the same way round (each row in the order E1-E2, E2-E3, E3-E1)", [rb, rm].every(r => [0, 1].every(row => r.order.filter(o => o.row === row).map(o => o.face % 3).join() === "1,2,0")));
ok("the other three dimensions get no reading (not described yet)", ["Space", "Evolution", "Design"].every(d => readAgent(d) === null));

console.log("4 — a whole shell, read each way");
const D4 = ["Movement", "Evolution", "Being", "Design"], S = new LivingSwarm({ seed: 4 });
for (let i = 0; i < 64; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + (i * 5) % 6, tone: 1 + (i * 2) % 6, base: 1 + i % 5, dimension: D4[i % 4] }, "item", Math.random(), Math.random());
const T = tile(S.units, { dimension: "Being" }), { rows } = ringsOf(T), sb = readShell(T, "Being"), sm = readShell(T, "Movement");
console.log(`     the ${read(T).seen} grows into ${rows.length} rings of ${rows.map(r => r.length).join(", ")} agents, top to bottom`);
const pass1 = r => [...new Set(r.order.map(o => o.row))].map(row => `[${r.order.filter(o => o.row === row).map(o => `${o.count}:${o.agent}`).join(" ")}]`).join(" ");
console.log(`     Being    (count:agent, ring by ring, moving ${sb.moves}): ${pass1(sb)}`);
console.log(`     Movement (count:agent, ring by ring, moving ${sm.moves}): ${pass1(sm)}`);
ok("every agent is read once by each", sb.order.length === T.faces.length && new Set(sb.order.map(o => o.agent)).size === T.faces.length && new Set(sm.order.map(o => o.agent)).size === T.faces.length);
ok("Being goes ring by ring downward, Movement ring by ring upward: the same rings, opposite directions", sb.order.map(o => o.row).every((r, i, a) => !i || r >= a[i - 1]) && sm.order.map(o => o.row).every((r, i, a) => !i || r <= a[i - 1]));
ok("within each ring both read across the same way", rows.every((w, r) => sb.order.filter(o => o.row === r).map(o => o.agent).join() === w.join() && sm.order.filter(o => o.row === r).map(o => o.agent).join() === w.join()));
ok("each ring's walk goes from neighbour to neighbour", rows.every(w => w.every((a, i) => !i || T.faces[a].v.filter(v => T.faces[w[i - 1]].v.includes(v)).length === 2)));

console.log("5 — across the two sides: each agent in line with its shadow");
const Dd = twoSides(S.units, { dimension: "Being" }), Ts = tile(S.units.slice(0, Math.ceil(S.units.length / 2)), { dimension: "Being" }), Th = tile(S.units.slice(Math.ceil(S.units.length / 2)), { dimension: "Movement" });
const rs = ringsOf(Ts).rowOf, rh = ringsOf(Th).rowOf, paired = Dd.partner.map((j, i) => [i, j]).filter(([, j]) => j != null);
ok(`seen side read by Being, shadow side by Movement; all ${paired.length} partners sit on the same ring as each other`, Dd.shadowDim === "Movement" && paired.every(([i, j]) => rs[i] === rh[j]));
const hb = readShell(Th, "Movement"); console.log(`     the shadow, read by Movement from the bottom: ${pass1(hb)}`);

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
