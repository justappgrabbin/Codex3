// morph_app.js — the morph page's own loop (v64j, Nov 26). Moved out of morph.html's inline script so the same code runs in
// two places: morph.html served from the site, and one person's own single-file page (mint.js). Behaviour of v64h/v64i kept:
// a statement still makes the page become it (pagemorph.js). New in v64j: a question typed into the same line is answered
// (ask.js), and "This fits" / "Not this" teach that person's experience brain. The brain, the birth data and the page memory
// stay in this browser; nothing here talks to a server or to the mesh.
import { LivingSwarm } from "./living.js"; import { setGateEngineData } from "./gate_engine.js";
import { decide, answer, compose, render, newPerson } from "./pagemorph.js";
import { perspective, ask, feedback, askPage, renderAsk, newBrain } from "./ask.js";
import V from "./vocabulary.json" with { type: "json" }; import R from "./bhantugh_rules.json" with { type: "json" };
setGateEngineData(V, R);

const $ = id => document.getElementById(id);
const embedded = (() => { try { return JSON.parse($("personal")?.textContent ?? "null"); } catch { return null; } })();   // set only in a minted page
const KEY = "morph:" + (embedded?.id ?? "site") + ":";
const store = { get: k => { try { return JSON.parse(localStorage.getItem(KEY + k)); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(KEY + k, JSON.stringify(v)); } catch {} } };
const person = store.get("person") ?? embedded?.person ?? newPerson(); person.brain ??= newBrain();
const birth = store.get("birth") ?? {};
let addresses = embedded?.addresses ?? [], S = new LivingSwarm(), O = { S }, pending = null, answers = {}, round = null;

async function grow() { S = new LivingSwarm(); O = { S };
  if (!embedded && birth.date) try { const { fourCharts } = await import("./charts.js"); addresses = Object.values(fourCharts(birth).charts).flatMap(c => c.addresses); } catch { addresses = []; }
  addresses.forEach(a => S.add(a, "person")); const have = new Set(addresses.map(a => a.gate)), D = ["Movement", "Evolution", "Being", "Design"];
  for (let g = 1, k = 0; g <= 64; g++) if (!have.has(g)) { S.add({ gate: g, line: 1 + k % 6, color: 1 + k % 6, tone: 1 + k % 6, base: 1 + k % 5, dimension: D[k % 4] }, "item"); k++; } }
const save = () => store.set("person", person);
function show(page) { const el = $("page"); el.innerHTML = render(page); draw(el); save();
  el.querySelectorAll("fieldset[data-kind=question] button").forEach(b => b.onclick = () => { const q = b.closest("fieldset").dataset.q; answers[q] = b.dataset.answer; b.closest("fieldset").disabled = true;
    const d = answer(pending, answers, person, { vocab: V }); if (d.form) { pending = null; answers = {}; show(compose(O, d, person)); } }); }
function showAnswers(r) { round = r; const el = $("page"); el.innerHTML = renderAsk(askPage(r)); save();
  el.querySelectorAll("article[data-kind=answer] button").forEach(b => b.onclick = () => { const art = b.closest("article");
    const ch = feedback(person, round, art.dataset.id, b.dataset.verdict); save(); art.dataset.taught = ch ? `${ch.before} -> ${ch.after}` : "";
    art.querySelectorAll("button").forEach(x => x.disabled = true); }); }
function draw(el) { el.querySelectorAll("canvas").forEach(c => { const x = c.getContext("2d"), W = c.width = c.clientWidth, H = c.height = c.clientHeight;
  const pts = JSON.parse(c.dataset.marks ?? c.dataset.paths ?? "[]"); let t = 0;
  const frame = () => { x.clearRect(0, 0, W, H); pts.forEach((p, i) => { const [px, py] = p.from ?? [p.x, p.y], a = c.dataset.moving ? t / 40 + i : 0;
    x.fillStyle = p.color ? `rgb(${p.color.r ?? p.color[0]},${p.color.g ?? p.color[1]},${p.color.b ?? p.color[2]})` : "#9cf";
    x.beginPath(); x.arc(px * W + Math.cos(a) * 12, py * H + Math.sin(a) * 12, 6, 0, 7); x.fill(); }); t++; if (c.dataset.moving && c.isConnected) requestAnimationFrame(frame); }; frame(); });
  el.querySelectorAll("[data-voices]").forEach(d => { d.textContent = "♪"; d.onclick = () => { const ac = new AudioContext();
    d.dataset.voices.split(",").filter(Boolean).forEach((f, i) => { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = +f; g.gain.value = 0.05; o.connect(g).connect(ac.destination); o.start(ac.currentTime + i * 0.25); o.stop(ac.currentTime + i * 0.25 + 0.4); }); }; }); }
function become(say) {
  if (perspective(say).kind === "question") return showAnswers(ask(say, person, { vocab: V, addresses }));
  const d = decide({ say, addresses }, person, { vocab: V }); if (d.ask) { pending = d; answers = {}; } show(compose(O, d, d.ask ? null : person)); }

$("tell").onsubmit = e => { e.preventDefault(); become($("say").value); };
if (embedded) $("birth")?.remove();
else { $("birth").onsubmit = async e => { e.preventDefault(); Object.assign(birth, { date: $("bdate").value, time: $("btime").value, zone: $("bzone").value || Intl.DateTimeFormat().resolvedOptions().timeZone });
    store.set("birth", birth); await grow(); become(""); };
  if (birth.date) { $("bdate").value = birth.date; $("btime").value = birth.time; $("bzone").value = birth.zone; } }
// "Keep my page": a minted page writes itself out again with what it has learned (only a minted page carries its own sources).
const keep = $("keep"); if (keep) { if (!embedded) keep.remove(); else keep.onclick = async () => { const { remint } = await import("./mint.js");
  const html = remint(document, { person, addresses, id: embedded.id }), a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([html], { type: "text/html" })); a.download = `synthia-${embedded.id}.html`; a.click(); }; }
await grow(); become("");
