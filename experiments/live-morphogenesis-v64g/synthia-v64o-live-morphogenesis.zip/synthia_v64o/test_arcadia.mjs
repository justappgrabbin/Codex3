// test_arcadia.mjs — Arcadia as a condition the swarm uses (v64h, Nov 26), run on the organism through morphogenesis.enter.
//   1 being: each formation is classified by nearest kind; kinds come out of what was formed, no kind list
//   2 parts: core / edge members, sub-formations as inner wholes
//   3 expression: forming / holding from real runs; breaking / regenerating by the same rule on a weakened copy
//   4 feedback: what one formation taught is shared with units carrying the same kind; addresses untouched
//   5 persistence: a fresh swarm that takes up the kinds recognises AND at once
//   6 switch: ARCADIA.on = false leaves enter() exactly as before; morphogenesis.js does not import arcadia.js
import { LivingSwarm } from "./living.js"; import { OrganismSwarm } from "./organism_swarm.js";
import { enter, AFTER_LEARN } from "./morphogenesis.js"; import { appHost } from "./hosts.js"; import { setGateEngineData } from "./gate_engine.js";
import { ARCADIA, coordinate, extractArcadia, adoptArcadia, installArcadia } from "./arcadia.js";
import { readFileSync } from "node:fs";
const J = f => JSON.parse(readFileSync(new URL(f, import.meta.url))); setGateEngineData(J("./vocabulary.json"), J("./bhantugh_rules.json"));
installArcadia(AFTER_LEARN);
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const D = ["Movement", "Evolution", "Being", "Design"];
const swarm = seed => { const S = new LivingSwarm({ seed });
  for (let i = 0; i < 48; i++) S.add({ gate: 1 + i, line: 1 + i % 6, color: 1 + i % 6, tone: 1 + i % 6, base: 1 + i % 5, dimension: D[i % 4] }, "person", 0.3 + (i % 8) * 0.05, 0.3 + Math.floor(i / 8) * 0.05);
  const O = new OrganismSwarm(S); for (let t = 0; t < 5; t++) O.step(); return O; };
const asserts = (name, n, f, file = "g.js") => { const rows = []; for (let k = 0; k < 2 ** n; k++) { const a = Array.from({ length: n }, (_, i) => (k >> (n - 1 - i)) & 1); rows.push(`assert(${name}(${a.join(",")}) === ${f(...a)});`); }
  return [{ path: "t.js", text: `import { ${name} } from './${file}';\n${rows.join("\n")}\n` }]; };
const arc = r => r.steps.filter(s => s.step === "arcadia").at(-1);
const HOSTS = [["AND", asserts("onlyBoth", 2, (a, b) => a & b)], ["all3", asserts("all3", 3, (a, b, c) => a & b & c)],
  ["AND again (h.js)", asserts("both", 2, (a, b) => a & b, "h.js")], ["NAND", asserts("onlyBoth", 2, (a, b) => (a & b) ? 0 : 1)],
  ["OR", asserts("orr", 2, (a, b) => a | b)], ["XOR", asserts("xo", 2, (a, b) => a ^ b)], ["NOR", asserts("nor", 2, (a, b) => (a | b) ? 0 : 1)]];

const O = swarm(3), snap = JSON.stringify(O.S.units.map(u => u.address)), R = {};
for (const [label, h] of HOSTS) { const r = enter(O, appHost(h)); R[label] = { r, a: arc(r) };
  console.log(`     ${label.padEnd(17)} ${r.ok ? "built" : "FAILED"}  ->  ${R[label].a?.kind} ${R[label].a?.being}  (${R[label].a?.new ? "new" : "same kind, cosine " + R[label].a?.similarity})  ${R[label].a?.expresses}  core ${R[label].a?.core} edge ${R[label].a?.edge} inner ${R[label].a?.inner?.length}  shared to ${R[label].a?.sharedTo}`); }

console.log("1 — being");
ok("every formation was built and classified", HOSTS.every(([l]) => R[l].r.ok && R[l].a));
ok("the first formation starts the first kind", R.AND.a.new && R.AND.a.kind === "kind.1");
ok("AND met again on another file is the same kind", !R["AND again (h.js)"].a.new && R["AND again (h.js)"].a.kind === R.AND.a.kind);
ok("NAND (the host's conditions changed) is not AND's kind", R.NAND.a.kind !== R.AND.a.kind);
const kinds = O.arcadia.kinds;
ok(`kinds came out of the runs (${kinds.length}), fewer than formations, each named from its own parts`, kinds.length >= 2 && kinds.length < HOSTS.length && kinds.every(k => /^[a-z]+·[A-Za-z]+·[a-z]+(·\d+)?$/.test(k.name)));
ok("kind names are distinct", new Set(kinds.map(k => k.name)).size === kinds.length);
const src = readFileSync(new URL("./arcadia.js", import.meta.url), "utf8");
ok("arcadia.js holds no list of kinds, worlds or tasks", !/onlyBoth|all3|AND|NAND|XOR|appHost|worldPlace|frost|dusk/.test(src.replace(/^\/\/.*$/gm, "")));

console.log("2 — parts and the whole");
ok("all3 holds the learned AND as an inner whole", R.all3.a.inner.some(i => i.cluster === R.AND.r.steps.filter(s => s.step === "cluster").at(-1).id));
const m = O.lastArcadia;
ok("every member is placed core or edge against its whole", m.parts.members.every(x => x.sits === "core" || x.sits === "edge") && m.parts.core >= 1);

console.log("3 — expression");
ok("first appearance of a kind is forming, a return with coherence kept is holding", R.AND.a.expresses === "forming" && R["AND again (h.js)"].a.expresses === "holding");
const reg = O.lastRegulation, k0 = O.arcadia.kinds.find(k => k.id === O.lastArcadia.kind), before = k0.history.length;
const weak = { ...reg, coherence: Math.max(0, k0.history.at(-1).coherence - ARCADIA.drop - 0.05) };
const b = coordinate(O, weak, { formationId: "weakened copy" }), g = coordinate(O, { ...reg }, { formationId: "whole copy" });
ok(`the same regulation with coherence dropped by more than ${ARCADIA.drop} reads as breaking; whole again after it reads as regenerating (rule check on a copy)`,
  b.kind === k0.id && b.expresses === "breaking" && g.kind === k0.id && g.expresses === "regenerating" && k0.history.length === before + 2);

console.log("4 — feedback (the mesh, by kind)");
const shared = HOSTS.reduce((n, [l]) => n + (R[l].a.sharedTo ?? 0), 0);
ok(`what a formation taught reached other carriers of its kind (${shared} shares)`, shared > 0);
ok("no unit's address changed", JSON.stringify(O.S.units.map(u => u.address)) === snap);

console.log("5 — persistence (kinds travel with the swarm)");
const saved = JSON.stringify(extractArcadia(O)), O2 = swarm(7); adoptArcadia(O2, JSON.parse(saved));
const r2 = enter(O2, appHost(asserts("onlyBoth", 2, (a, b) => a & b))), a2 = arc(r2);
ok(`a fresh swarm that took up ${O2.arcadia.kinds.length} kinds (${saved.length} bytes) meets AND as a known kind, ${a2?.kind} (cosine ${a2?.similarity})`, r2.ok && a2 && !a2.new);

console.log("6 — switch");
ARCADIA.on = false; const O3 = swarm(3), r3 = enter(O3, appHost(asserts("onlyBoth", 2, (a, b) => a & b))); ARCADIA.on = true;
ok("ARCADIA.on = false: no arcadia step, no kinds kept, AND still built", r3.ok && !arc(r3) && !O3.arcadia);
ok("morphogenesis.js does not import arcadia.js (Arcadia is a layer, never a dependency)", !/from\s+["']\.\/arcadia\.js["']/.test(readFileSync(new URL("./morphogenesis.js", import.meta.url), "utf8")));

console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
