// dual.js — the seen side and the side you don't see (v64h, Nov 26). Celestial (Nov 26, voice): "they connect, but they don't
// necessarily connect"; "it's like a shadow side... you can see one side but the other side you don't see"; "So the function
// side is that side that you don't see."
//
// My reading, built on tiling.js:
//   * the PICTURE swarm is a shell seen by the leading dimension; the FUNCTION swarm is its shadow, a shell of the paired
//     dimension (Being <-> Movement, Evolution <-> Design, Space <-> Space), so one side is read as triangles and the other as
//     the dual solid: an icosahedron's face is a dodecahedron's corner.
//   * each seen agent has exactly one shadow partner: the agent in the same place of the dual shell (the two shells grow by the
//     same rule, so the places line up; the test checks that neighbours stay neighbours). They share no edge, no port, no
//     contact: neither shell has a link into the other.
//   * they are coupled through the two faces that "only face themselves" (lines 2 and 5): an agent's self faces face its own
//     shadow. Ports carry exchange with neighbours on the same side; self faces carry state between the two sides.
//   * COUPLING.rate (0.5, mine) is how much of the partner's self-face state crosses per tick; 0 cuts the shadow off.
import { tile, seat, exchange, FORM, AGENT } from "./tiling.js";
import { diamondFrom } from "./crystals.js";   // v64n: optional perspective-bound pairing (the diamond's rows as the reader sees them)

export const COUPLING = { rate: 0.5 };
export const PAIR = { Being: "Movement", Movement: "Being", Evolution: "Design", Design: "Evolution", Space: "Space" };

/** Grow both sides from the swarm's units: the seen shell for `dimension`, the shadow on its paired dimension. */
export function twoSides(units, { dimension = "Being", perspective = null } = {}) {
  const shadowDim = perspective ? diamondFrom(perspective).pair[dimension] : PAIR[dimension], half = Math.ceil((units?.length ?? 0) / 2);
  const seen = seat(tile(units.slice(0, half), { dimension })), shadow = seat(tile(units.slice(half), { dimension: shadowDim }));
  const partner = seen.agents.map(g => g.id < shadow.agents.length ? g.id : null);
  return { dimension, perspective, shadowDim, seen, shadow, partner, views: { seen: FORM[dimension].view, shadow: FORM[shadowDim].view } };
}

/** One tick: each side exchanges through its own ports, then every agent and its shadow trade self-face state. */
export function tick(D) {
  exchange(D.seen); exchange(D.shadow);
  const r = COUPLING.rate; if (!r) return;
  D.partner.forEach((j, i) => { if (j == null) return; const a = D.seen.agents[i], b = D.shadow.agents[j];
    for (const l of AGENT.self) { const x = a.value[l], y = b.value[l]; a.value[l] = (1 - r) * x + r * y; b.value[l] = (1 - r) * y + r * x; } });
}

/** How a seen agent looks: its brightness from all six faces, its hue from its self faces (what its shadow is doing). */
export function look(g) {
  const all = Object.values(g.value).reduce((a, b) => a + b, 0) / 6, self = (g.value[2] + g.value[5]) / 2;
  return { light: +(20 + 60 * all).toFixed(3), hue: +(360 * self).toFixed(3) };
}
