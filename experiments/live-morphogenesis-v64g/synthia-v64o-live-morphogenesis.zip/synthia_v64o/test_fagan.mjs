// test_fagan.mjs — Evolution on Fagan-Bradley (v64h, Nov 26), Lahiri kept as a switch: what moves.
import { fourCharts, AYANAMSA, fagan, lahiri } from "./charts.js"; import * as A from "./vendor/astronomy-engine/astronomy.js";
let pass = 0, fail = 0; const ok = (n, c) => { c ? pass++ : fail++; console.log((c ? "  PASS " : "  FAIL ") + n); };
const j2000 = A.MakeTime(new Date(Date.UTC(2000, 0, 1, 12)));
ok(`Fagan-Bradley at J2000 = ${fagan(j2000).toFixed(4)}° (expected about 24.740°)`, Math.abs(fagan(j2000) - 24.7403) < 0.01);
ok(`Lahiri at J2000 = ${lahiri(j2000).toFixed(4)}° (unchanged)`, Math.abs(lahiri(j2000) - 23.853) < 1e-6);
const gap = fagan(j2000) - lahiri(j2000); ok(`Fagan minus Lahiri = ${gap.toFixed(4)}° = ${(gap * 60).toFixed(1)}' (a line is 56.25')`, gap > 0.8 && gap < 0.95);
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const N = 200, moved = { gate: 0, line: 0, color: 0, tone: 0, base: 0 }; let total = 0, othersSame = true;
for (let i = 0; i < N; i++) {
  const d = new Date(Date.UTC(1950, 0, 1) + rnd() * 60 * 365.25 * 864e5), date = d.toISOString().slice(0, 10), time = d.toISOString().slice(11, 16);
  AYANAMSA.use = "lahiri"; const L = fourCharts({ date, time }); AYANAMSA.use = "fagan"; const F = fourCharts({ date, time });
  for (const dim of ["Being", "Movement", "Design"]) if (JSON.stringify(L.charts[dim].lons) !== JSON.stringify(F.charts[dim].lons)) othersSame = false;
  L.charts.Evolution.addresses.forEach((a, k) => { const b = F.charts.Evolution.addresses[k]; total++;
    for (const key of Object.keys(moved)) if (a[key] !== b[key]) moved[key]++; });
}
const pct = k => (100 * moved[k] / total).toFixed(1) + "%";
console.log(`     over ${N} random births 1950-2010 (${total} Evolution activations): gate changed ${pct("gate")}, line ${pct("line")}, color ${pct("color")}, tone ${pct("tone")}, base ${pct("base")}`);
ok("Being, Movement and Design are untouched by the switch", othersSame);
ok("about one activation in six changes gate (0.89° of a 5.625° gate)", moved.gate / total > 0.1 && moved.gate / total < 0.22);
ok("most activations change line", moved.line / total > 0.8);
AYANAMSA.use = "lahiri"; const sysL = fourCharts({ date: "1990-06-15" }).charts.Evolution.system; AYANAMSA.use = "fagan";
ok(`default is Fagan; the switch still gives Lahiri ("${sysL}")`, fourCharts({ date: "1990-06-15" }).charts.Evolution.system === "Sidereal (Fagan-Bradley)" && sysL === "Sidereal (Lahiri)");
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
