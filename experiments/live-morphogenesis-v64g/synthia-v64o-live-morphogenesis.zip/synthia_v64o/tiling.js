// tiling.js — agents are tiny triangles; the solids are what they tile into (v64h, Nov 26). A swarm condition, not a shape.
// Celestial (Nov 26, voice): "the triangles are tiny, tiny triangles that make up the other spaces... they overlap... to make
// pentagons and hexagons and squares... And they go inside of the icosahedrons and dodecahedrons. That's what they make up."
// And: "If you're looking at movement, it's a dodecahedron. If it's being, it's icosahedron."
//
// The rule (mine, from geometry; nothing below stores a solid):
//   * each agent is a tiny SOLID, a triangular bipyramid (Celestial: "Who said it was flat?"): two tetrahedra on one triangle.
//     The shared triangle is its tile in the shell; its six triangular faces are the hexagram's six lines, lower half 1-2-3
//     (toward the shell's inside), upper half 4-5-6 (outside). Faces over the same tile edge are mirrors: 1-4, 2-5, 3-6, the
//     I Ching's corresponding lines. Its five corners are the five dimensions (see AGENT below).
//   * four faces are ports, two face only the agent itself: lines 2 and 5 (my pick: the middle line of each trigram, and the
//     mirror pair the coordinator described). The tile edge under them is a SEAM: the agent across it also faces itself
//     there, so two agents meet on the seam without exchanging, and the two tiny triangles make a quad (a "square").
//     Seams are paired by a perfect matching of the shell, so every agent of a closed shell has a partner across its seam.
//   * the swarm grows at its open edge: the open corner with the most triangles around it is served first. When a corner already
//     has k-1 triangles, the next triangle closes it (its two open neighbours are joined); otherwise a triangle is added on one of
//     its open edges with a new corner. That is all. k, how many triangles close a corner, is the only thing a dimension sets:
//        k = 3 closes into a tetrahedron (4 triangles), k = 4 an octahedron (8), k = 5 an icosahedron (20); k = 6 never closes,
//        it stays a flat sheet of hexagons.
//   * the triangles around one corner make a polygon: 3 a triangle, 4 a square, 5 a pentagon, 6 a hexagon. Read by those polygons
//     (the "fan" view) the same tiling is the dual solid: the icosahedron's 12 pentagons are the dodecahedron's 12 faces, the
//     octahedron's 6 squares the cube's, the tetrahedron's 4 triangles a tetrahedron again.
//   * which unit takes a new triangle: the free unit that bonds best with the triangles it will touch, by kernel/bond.js's own
//     harmonics (line, colour, tone 1-4 / 2-5 / 3-6; base 1-5 / 2-4 / 3-3), plus being of the dimension that leads.
// Dimension -> (k, view). Celestial's words: Movement = dodecahedron, Being = icosahedron: one k = 5 tiling seen two ways.
// My picks, pending Celestial: Evolution = octahedron and Design = cube (one k = 4 tiling seen two ways: the zodiac-based
// dimensions read triangles, the draconic ones read the polygons, as Being/Movement do), Space = tetrahedron (self-dual, k = 3).
import { isHarmonic6, isHarmonicBase } from "./kernel/bond.js";

export const FORM = {
  Being: { k: 5, view: "triangles" }, Movement: { k: 5, view: "fans" },
  Evolution: { k: 4, view: "triangles" }, Design: { k: 4, view: "fans" },
  Space: { k: 3, view: "triangles" },
};
const key = (a, b) => a < b ? `${a}-${b}` : `${b}-${a}`;

/** Grow a tiling from the swarm's units. units: LivingSwarm units (or anything with an address). */
export function tile(units, { dimension = "Being", k = FORM[dimension]?.k ?? 5, cap = 200 } = {}) {
  const T = { dimension, k, faces: [], edges: new Map(), fans: new Map(), nextV: 3, closed: false, log: [] };
  const free = (units ?? []).filter(u => u && !u.broken && u.address).slice();
  const bondScore = (u, nbrs) => nbrs.reduce((s, n) => { const a = u.address, b = n?.address; if (!b) return s;
    return s + isHarmonic6(a.line, b.line) + isHarmonic6(a.color, b.color) + isHarmonic6(a.tone, b.tone) + isHarmonicBase(a.base, b.base); }, 0)
    + (u.address.dimension === dimension ? 0.5 : 0);
  const take = nbrFaces => { if (!free.length) return null; const nbrs = nbrFaces.map(f => T.faces[f]?.unit).filter(Boolean);
    let best = 0; for (let i = 1; i < free.length; i++) if (bondScore(free[i], nbrs) > bondScore(free[best], nbrs)) best = i;
    return free.splice(best, 1)[0]; };
  const add = (a, b, c, why) => { const id = T.faces.length, nbr = [key(a, b), key(b, c), key(c, a)].flatMap(e => T.edges.get(e) ?? []);
    const u = take(nbr); T.faces.push({ id, v: [a, b, c], unit: u ?? null });
    for (const e of [key(a, b), key(b, c), key(c, a)]) T.edges.set(e, [...(T.edges.get(e) ?? []), id]);
    for (const v of [a, b, c]) T.fans.set(v, [...(T.fans.get(v) ?? []), id]); T.log.push(why); return id; };
  const open = () => [...T.edges].filter(([, fs]) => fs.length === 1).map(([e]) => e.split("-").map(Number));
  add(0, 1, 2, "seed");
  while (T.faces.length < cap) {
    const bd = open(); if (!bd.length) { T.closed = true; break; }
    const at = new Map(); for (const [a, b] of bd) { at.set(a, [...(at.get(a) ?? []), b]); at.set(b, [...(at.get(b) ?? []), a]); }
    const v = [...at.keys()].sort((x, y) => T.fans.get(y).length - T.fans.get(x).length || x - y)[0], [u, w] = at.get(v);
    if (T.fans.get(v).length >= k - 1 && u !== w) add(u, v, w, `close corner ${v}`);
    else add(v, u, T.nextV++, `open edge at ${v}`);
  }
  return T;
}

/** Read a tiling: counts, whether every corner closed at k, and its two views. */
export function read(T) {
  const V = T.fans.size, E = T.edges.size, F = T.faces.length, degrees = [...T.fans.values()].map(f => f.length);
  const regular = T.closed && degrees.every(d => d === T.k);
  const NAMES = { 4: "tetrahedron", 8: "octahedron", 20: "icosahedron" }, DUAL = { 4: "tetrahedron", 8: "cube", 20: "dodecahedron" };
  const polygon = { 3: "triangle", 4: "square", 5: "pentagon", 6: "hexagon" }[T.k] ?? `${T.k}-gon`;
  return { triangles: F, corners: V, edges: E, euler: V - E + F, closed: T.closed, regular,
    asTriangles: regular ? NAMES[F] ?? `${F}-face solid` : T.closed ? "closed, irregular" : "open sheet",
    asFans: regular ? DUAL[F] ?? `dual of ${F}` : T.closed ? "closed, irregular" : `open sheet of ${polygon}s`,
    fans: { polygon, count: V, sides: T.k }, seen: FORM[T.dimension]?.view === "fans" ? (regular ? DUAL[F] : null) : (regular ? NAMES[F] : null) };
}

// ---------- the agent: a triangular bipyramid ----------
// Corners: B (inner apex), T (outer apex), and the tile's three corners E1, E2, E3, with the seam on E2-E3.
// My picks: E1 = Space (it touches exactly the four port faces and neither self face: the meeting ground of exchange);
// T = Design, B = Movement (the two draconic charts at the poles), E2 = Being, E3 = Evolution (the two zodiac charts on the seam).
export const AGENT = {
  corners: { B: "Movement", T: "Design", E1: "Space", E2: "Being", E3: "Evolution" },
  faces: { 1: ["B", "E1", "E2"], 2: ["B", "E2", "E3"], 3: ["B", "E3", "E1"], 4: ["T", "E1", "E2"], 5: ["T", "E2", "E3"], 6: ["T", "E3", "E1"] },
  self: [2, 5], ports: [1, 3, 4, 6],
};
export function agentShape() {
  const F = AGENT.faces, edges = new Set();
  for (const f of Object.values(F)) for (let i = 0; i < 3; i++) edges.add([f[i], f[(i + 1) % 3]].sort().join("-"));
  const shares = (a, b) => F[a].filter(x => F[b].includes(x)).length === 2;
  const mirror = l => +Object.keys(F).find(m => +m !== l && shares(l, +m) && !F[m].includes(F[l][0]));
  return { faces: 6, corners: Object.keys(AGENT.corners).length, edges: edges.size, mirror: Object.fromEntries([1, 2, 3, 4, 5, 6].map(l => [l, mirror(l)])),
    touches: Object.fromEntries(Object.keys(AGENT.corners).map(c => [AGENT.corners[c], [1, 2, 3, 4, 5, 6].filter(l => F[l].includes(c))])),
    neighbours: Object.fromEntries([1, 2, 3, 4, 5, 6].map(l => [l, [1, 2, 3, 4, 5, 6].filter(m => m !== l && shares(l, m))])) };
}

/** Seat a bipyramid agent on every tile: pair tiles across seams (perfect matching where one exists), then wire ports. */
export function seat(T) {
  const adj = T.faces.map(f => [[f.v[0], f.v[1]], [f.v[1], f.v[2]], [f.v[2], f.v[0]]].map(([x, y]) => ({ e: [x, y], to: (T.edges.get(key(x, y)) ?? []).find(id => id !== f.id) ?? null })));
  const mate = new Array(T.faces.length).fill(null);
  const match = i => { if (i === T.faces.length) return true; if (mate[i] != null) return match(i + 1);
    for (const { to } of adj[i]) if (to != null && mate[to] == null) { mate[i] = to; mate[to] = i; if (match(i + 1)) return true; mate[i] = mate[to] = null; }
    return T.closed ? false : match(i + 1); };
  if (!match(0)) for (let i = 0; i < mate.length; i++) if (mate[i] == null) for (const { to } of adj[i]) if (to != null && mate[to] == null) { mate[i] = to; mate[to] = i; break; }
  const agents = T.faces.map(f => { const seamTo = mate[f.id], s = seamTo != null ? adj[f.id].find(a => a.to === seamTo).e : adj[f.id].find(a => a.to == null)?.e ?? adj[f.id][0].e;
    const E1 = f.v.find(v => !s.includes(v)), [E2, E3] = s, a = f.unit?.address, lines = a?.gate ? bitsOfGate(a.gate) : [0, 0, 0, 0, 0, 0];
    const value = Object.fromEntries([1, 2, 3, 4, 5, 6].map(l => [l, lines[l - 1]]));
    return { id: f.id, unit: f.unit?.id ?? null, E1, E2, E3, seam: seamTo, value, links: {} }; });
  // ports: over tile edge E1-E2 lie faces 1 (inner) and 4 (outer); over E3-E1 faces 3 (inner) and 6 (outer). The neighbour across that
  // edge has the same edge as its E1-E2 or E3-E1; inner meets inner, outer meets outer.
  const over = (g, x, y) => { const e = key(x, y); return e === key(g.E1, g.E2) ? [1, 4] : e === key(g.E3, g.E1) ? [3, 6] : null; };
  for (const g of agents) for (const [x, y] of [[g.E1, g.E2], [g.E3, g.E1]]) {
    const n = (T.edges.get(key(x, y)) ?? []).find(id => id !== g.id); if (n == null) continue; const h = agents[n], mine = over(g, x, y), theirs = over(h, x, y);
    if (!theirs) continue; g.links[mine[0]] = { agent: n, face: theirs[0] }; g.links[mine[1]] = { agent: n, face: theirs[1] }; }
  return { agents, pairs: agents.filter(g => g.seam != null && g.id < g.seam).map(g => [g.id, g.seam]) };
}
import { maskFromKingWen } from "./kingwen.js";
const bitsOfGate = g => Array.from({ length: 6 }, (_, i) => (maskFromKingWen(g) >>> i) & 1);

/** One tick of exchange. Self faces (2, 5) read only their own agent's faces: they carry its state forward. Port faces read their
 *  own agent and the neighbour face they are joined to. The bond between two port faces carries NAND of their bits (kept).
 *  Returns the reads made, so a test can see that no agent ever reads another agent's self face. */
export function exchange(S, { rate = 0.5 } = {}) {
  const N = AGENT_NBR, reads = [], next = S.agents.map(g => ({ ...g.value }));
  for (const g of S.agents) for (const l of [1, 2, 3, 4, 5, 6]) {
    const inside = N[l].map(m => g.value[m]), own = inside.reduce((a, b) => a + b, 0) / inside.length;
    if (AGENT.self.includes(l)) { next[g.id][l] = (1 - rate) * g.value[l] + rate * own; continue; }
    const link = g.links[l]; if (!link) { next[g.id][l] = (1 - rate) * g.value[l] + rate * own; continue; }
    const other = S.agents[link.agent].value[link.face]; reads.push({ from: link.agent, face: link.face, by: g.id });
    next[g.id][l] = (1 - rate) * g.value[l] + rate * (own + other) / 2;
    (g.bonds ??= {})[l] = (g.value[l] >= 0.5 && other >= 0.5) ? 0 : 1;   // NAND on the bond
  }
  S.agents.forEach((g, i) => g.value = next[i]); return reads;
}
const AGENT_NBR = agentShape().neighbours;
/** Space at an agent: the meeting of its four port faces (corner E1). */
export const spaceOf = g => AGENT.ports.reduce((s, l) => s + g.value[l], 0) / AGENT.ports.length;

// ---------- v64k (Nov 26): the agent turned ----------
// Celestial (Nov 26) said yes to turning the agent so Movement and Being sit on the vertical axis, as both of their docs show:
// "being moves across and counts up moving down movement moves upward and reads across but everything is in line even the duals".
// So Being takes the top tip (it reads downward), Movement keeps the bottom tip (it reads upward), and Design moves onto the
// seam beside Evolution. The agent has two lines of its own: the vertical axis (tip to tip, its symmetry axis) and the seam (the
// edge the two self faces share). After the turn each holds one dual pair: Movement-Being the axis, Evolution-Design the seam;
// Space, its own dual, stays at the corner where the four ports meet. Before it, each line held half of two different pairs
// (axis Movement-Design, seam Being-Evolution). The v64h orientation is kept, by name.
export const ORIENTATIONS = {
  v64h: { B: "Movement", T: "Design", E1: "Space", E2: "Being", E3: "Evolution" },
  turned: { B: "Movement", T: "Being", E1: "Space", E2: "Design", E3: "Evolution" },
};
export function setOrientation(name = "turned") { if (!ORIENTATIONS[name]) throw new Error(`no orientation ${name}`);
  Object.assign(AGENT.corners, ORIENTATIONS[name]); AGENT.orientation = name; return AGENT; }
setOrientation("turned");
