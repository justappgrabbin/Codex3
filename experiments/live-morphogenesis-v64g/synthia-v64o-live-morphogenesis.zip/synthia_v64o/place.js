// place.js — how the swarm finds its way in a place it was not told about (Celestial's list, item 1, Nov 26).
// A place shows only what is there, what can be done, and its health (places.js). Nothing here knows any place.
// These are CONDITIONS the swarm works under, not features built for one task:
//   1 PERCEIVE  each item of the place sits somewhere in the swarm's space (from its id); a unit perceives the items
//               within its reach. That is added to the unit's own OPP (opp.js, unchanged) as `place`.
//   2 ORIENT    the POP over the place = what share of the place is seen, which items nobody sees (blind), which
//               references nothing seen answers (gaps), and its health. While items are blind, the unit nearest each
//               blind item moves toward it (its heading changes, so its OPP orientation changes) and the swarm reads
//               again. The swarm only decides once it sees the whole place or stops gaining sight.
//   3 DISCOVER  two rules, in this order, read off the POP:
//               a) a GAP: an item refers to a name that no item there provides. The units that perceive that item are
//                  the ones that noticed it; the gap's shape is what the reference shows (name, where, arity, kind).
//               b) a LACK (v64h, from the phone file hypothesisLife: absence counted against a known whole): the whole is
//                  every seen item the place's own operations could take in; an item the place shows as present nowhere
//                  is absent. Blind is not absent: an item nobody saw is not counted at all. When health is below
//                  full and some, not all, of that whole is absent, the swarm holds a hypothesis: what is there isn't
//                  enough, so what is missing is likely among what is absent. Absent things are offered first; nothing
//                  is ruled out. After the build the hypothesis is marked supported or not (did the change use an absent thing).
//               c) no gap, no usable lack, health below full: what can be done is tried, and what raises health is kept.
//               Health full and no gap: nothing is needed; the swarm rests.
//   4 AIM       the swarm sets its own aim from health alone: at least halfway from where health is now to full
//               (AIM.share; a working value, mine). It is never given a goal.
//   5 BUILD     the swarm's own lifecycle (morphogenesis.enter: units construct, act, evaluate, clone, integrate,
//               extract, learn, cluster) runs on a host the swarm assembles from what it found. The place's own
//               operations are the only way to change it; apply() is called only by integrate, after a formation met the aim.
import { oppOf, popOf } from "./opp.js";
import { enter, enterLive } from "./morphogenesis.js";

export const AIM = { share: 0.5 };                     // aim = now + share x (1 - now)
export const ORIENT = { reach: 0.08, rounds: 6, step: 0.5 };
export const LACK = { on: true };                     // switch, so a test can compare with and without
const fnv = s => { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; } return h; };

/** where an item sits in the swarm's space: spread over the space the swarm's units cover, widened by half */
function placeItems(units, items) {
  const xs = units.map(u => u.x), ys = units.map(u => u.y), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const wx = (x1 - x0) || 0.1, wy = (y1 - y0) || 0.1;
  return items.map(it => { const h = fnv(it.id); return { ...it, x: x0 - wx / 4 + ((h & 0xffff) / 0xffff) * wx * 1.5, y: y0 - wy / 4 + ((h >>> 16) / 0xffff) * wy * 1.5 }; });
}

/** 1+2: perceive and orient; returns the POP over the place */
export function orient(O, place, { log = [] } = {}) {
  const units = O.S.units.filter(u => !u.broken && !u.latent), items = placeItems(units, place.there());
  const read = () => { for (const u of units) { oppOf(u, units, { reach: ORIENT.reach });
      u.opp.place = items.filter(it => Math.hypot(it.x - u.x, it.y - u.y) < ORIENT.reach).map(it => it.id); }
    const seen = new Set(units.flatMap(u => u.opp.place)); return { seen, blind: items.filter(it => !seen.has(it.id)) }; };
  let r = read(), round = 0; log.push({ round: 0, blind: r.blind.length, seenBefore: r.seen.size });
  while (r.blind.length && round < ORIENT.rounds) { round++;
    for (const it of r.blind) { const u = units.reduce((b, v) => Math.hypot(v.x - it.x, v.y - it.y) < Math.hypot(b.x - it.x, b.y - it.y) ? v : b);
      u.x += (it.x - u.x) * ORIENT.step; u.y += (it.y - u.y) * ORIENT.step; }
    r = read(); log.push({ round, blind: r.blind.length }); }
  const seenItems = items.filter(it => r.seen.has(it.id)), provided = new Set(seenItems.flatMap(it => it.provides ?? []));
  const gaps = seenItems.flatMap(it => (it.refers ?? []).filter(ref => !provided.has(ref.name)).map(ref => ({ ...ref, in: it.id,
    noticedBy: units.filter(u => u.opp.place.includes(it.id)).map(u => u.id) })));
  const unique = [...new Map(gaps.map(g => [g.name + "@" + g.from, g])).values()];
  const intake = new Set((place.can?.() ?? []).flatMap(op => Object.values(op.inputs))), whole = seenItems.filter(it => intake.has(it.type) && it.present !== undefined);
  const absent = whole.filter(it => !it.present).map(it => it.id);
  const swarmPOP = popOf(units);
  return { ...swarmPOP, place: { items: items.length, seen: seenItems.length, seenShare: +(seenItems.length / Math.max(1, items.length)).toFixed(3),
    blind: r.blind.map(b => b.id), gaps: unique, health: place.health(), orientRounds: round,
    lack: { whole: whole.length, absent, pressure: +(absent.length / Math.max(1, whole.length)).toFixed(3) } }, items: seenItems };
}

/** 3: what is missing, read off the POP */
export function discover(pop) {
  if (pop.place.gaps.length) return { kind: "gap", gap: pop.place.gaps[0], others: pop.place.gaps.length - 1 };
  const L = pop.place.lack;
  if (pop.place.health < 1 && LACK.on && L && L.absent.length && L.absent.length < L.whole) return { kind: "lack", health: pop.place.health, absent: L.absent, of: L.whole };
  if (pop.place.health < 1) return { kind: "low-health", health: pop.place.health, ...(L && L.whole ? { lack: L.absent.length === L.whole ? "everything this place could take in is absent, so absence can't narrow anything" : "nothing absent" } : {}) };
  return { kind: "nothing" };
}

/** probes for a gap: for a reference whose arguments are bits, every row of inputs (the swarm's own way to ask a hole
 *  what it should be). Other kinds of argument: no probe yet (stated, not hidden). */
function probesFor(gap) {
  if (gap.argType !== "bits" || !(gap.arity >= 1 && gap.arity <= 4)) return null;
  const rows = 2 ** gap.arity; return Array.from({ length: gap.arity }, (_, k) => ({ id: "probe" + k, type: "bits", value: Array.from({ length: rows }, (_, r) => (r >> (gap.arity - 1 - k)) & 1) }));
}

/** 4+5: aim, and build through the swarm's own lifecycle. Returns what happened, step by step. */
export function settle(O, place, { budget = 4000 } = {}) {
  const cycle = settlement(O, place);
  const step = cycle.next();
  return step.done ? step.value : cycle.next(enter(O, step.value, { budget })).value;
}

export async function settleLive(O, place, options = {}) {
  const cycle = settlement(O, place);
  const step = cycle.next();
  return step.done ? step.value : cycle.next(await enterLive(O, step.value, options)).value;
}

function* settlement(O, place) {
  const log = [], pop = orient(O, place, { log }), found = discover(pop), steps = [{ step: "orient", ...pop.place, swarm: { alignment: pop.orientation.alignment, lead: pop.position.lead, blindUnits: pop.perception.blind }, rounds: log }, { step: "discover", ...found }];
  if (found.kind === "nothing") return { ok: true, rested: true, steps };
  const now = pop.place.health, aim = +(now + AIM.share * (1 - now)).toFixed(3);
  const can = place.can();
  let observations;
  if (found.kind === "gap") { const pr = probesFor(found.gap);
    if (!pr) { steps.push({ step: "fail", reason: `a gap (${found.gap.name}) whose arguments the swarm has no way to probe yet` }); return { ok: false, steps }; }
    observations = [{ id: "gapname", type: "name", value: found.gap.name }, { id: "gappath", type: "path", value: found.gap.from }, ...pr]; }
  else { const absentSet = new Set(found.absent ?? []), usable = pop.items.filter(it => can.some(op => Object.values(op.inputs).includes(it.type)));
    observations = [...usable.filter(it => absentSet.has(it.id)), ...usable.filter(it => !absentSet.has(it.id))].map(it => ({ id: it.id.replace(/[^\w]/g, "_"), type: it.type, value: it.value })); }
  steps.push({ step: "aim", healthNow: now, aim, from: found.kind === "gap" ? `gap ${found.gap.name} in ${found.gap.from}, noticed by units ${found.gap.noticedBy.join(",")}` : found.kind === "lack" ? `${found.absent.length} of ${found.of} things this place could take in are absent here` : "health below full" });
  const types = { name: x => typeof x === "string", path: x => typeof x === "string", bits: x => Array.isArray(x) && x.every(v => v === 0 || v === 1), fit: x => !!x && typeof x.score === "number", ...(place.types ?? {}) };
  let applied = null;
  const host = { name: place.name, kind: place.kind, enough: aim, address: place.address,
    check: () => place.health(), checkAlone: () => place.health(),
    materials: () => ({ types, observations, primitives: can, need: found.kind === "gap" ? `${found.gap.name} (${found.gap.arity} bits) in ${found.gap.from}` : `health ${now} → ${aim}`,
      goal: { type: "fit", constraints: [{ path: ["score"], minimum: aim }] } }),
    descend: ({ result }) => ({ label: "a change made through the place's own operation", standalone: true, change: result.change }),
    integrate: d => { place.apply(d.change); applied = d.change; } };
  const r = yield host;
  if (found.kind === "lack") { const absentVals = pop.items.filter(it => found.absent.includes(it.id)).map(it => JSON.stringify(it.value));
    const used = applied ? Object.values(applied).map(v => JSON.stringify(v)).filter(v => absentVals.includes(v)) : [];
    steps.push({ step: "lack-hypothesis", held: "what is missing is among what is absent", supported: r.ok && used.length > 0, usedAbsent: used.length }); }
  return { ok: r.ok, steps: [...steps, ...r.steps], applied, healthAfter: place.health() };
}
